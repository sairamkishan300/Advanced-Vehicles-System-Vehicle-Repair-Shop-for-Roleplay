--------------------------------------
-- Vehicle Repair Shop - Client
--------------------------------------

local browser
local browserGUI
local isPanelVisible = false
local lastHealthText = nil
local lastPriceText = nil
local lastUpgrades = nil

local uiURL = "ui/index.html"

-- local copy for descriptive upgrade names and prices (must match server.lua)
local TUNING_SLOT_NAMES = {
	[0] = "Spoiler",
	[1] = "Hood",
	[2] = "Roof",
	[3] = "Sideskirt",
	[4] = "Lamps",
	[5] = "Nitro",
	[6] = "Exhaust",
	[7] = "Wheels",
	[8] = "Stereo",
	[9] = "Hydraulics",
	[10] = "Front bumper",
	[11] = "Rear bumper",
	[12] = "Vents",
	[13] = "Bullbars",
	[14] = "Extra",
}

local TUNING_UPGRADE_PRICES = {
	[0] = 500,
	[1] = 400,
	[2] = 400,
	[3] = 600,
	[4] = 800,
	[5] = 700,
	[6] = 500,
	[7] = 500,
	[8] = 300,
	[9] = 450,
	[10] = 350,
	[11] = 350,
	[12] = 500,
	[13] = 300,
	[14] = 300,
}

-- simple stats / upgrades window (MTA GUI)
local statsWindow
local statsGrid
local tuningWindow
local tuningGrid
local paintWindow
local paintList

local function closeStatsWindow()
	if isElement(statsWindow) then
		destroyElement(statsWindow)
	end
	statsWindow = nil
	statsGrid = nil
	showCursor(false)
	guiSetInputEnabled(false)
end

local function openStatsWindow()
    if isElement(statsWindow) then
        closeStatsWindow()
    end

    local veh = getPedOccupiedVehicle(localPlayer)
    if not isElement(veh) then
        return
    end

    local sw, sh = guiGetScreenSize()
    local w, h = 420, 360
    local x, y = (sw - w) / 2, (sh - h) / 2

    statsWindow = guiCreateWindow(x, y, w, h, "Vehicle upgrades & stats", false)
    guiWindowSetSizable(statsWindow, false)

    local model = getElementModel(veh)
    local name = getVehicleNameFromModel(model) or ("Model " .. tostring(model))
    local health = math.floor(getElementHealth(veh) or 0)
    local handling = getVehicleHandling(veh) or {}
    local maxVel = tostring(handling["maxVelocity"] or "-")
    local dmgMul = tostring(handling["collisionDamageMultiplier"] or "-")

    local infoLabel = guiCreateLabel(10, 24, w - 20, 40,
        string.format("%s (ID %d)\nHealth: %d  |  Max speed: %s  |  Damage mul: %s",
            name, model, health, maxVel, dmgMul), false, statsWindow)
    guiLabelSetHorizontalAlign(infoLabel, "left", true)

    statsGrid = guiCreateGridList(10, 70, w - 20, h - 120, false, statsWindow)
    guiGridListAddColumn(statsGrid, "Upgrade", 0.6)
    guiGridListAddColumn(statsGrid, "Installed", 0.3)

    local installed = {}
    for _, upg in ipairs(getVehicleUpgrades(veh) or {}) do
        installed[upg] = true
    end

    -- list all compatible upgrades by slot
    for slot = 0, 16 do
        local compat = getVehicleCompatibleUpgrades(veh, slot) or {}
        for _, upg in ipairs(compat) do
            local row = guiGridListAddRow(statsGrid)
            guiGridListSetItemText(statsGrid, row, 1, tostring(upg), false, false)
            guiGridListSetItemText(statsGrid, row, 2, installed[upg] and "X" or "", false, false)
        end
    end

    local closeBtn = guiCreateButton(10, h - 40, w - 20, 28, "Close", false, statsWindow)
    addEventHandler("onClientGUIClick", closeBtn, function()
        closeStatsWindow()
    end, false)

    showCursor(true)
    guiSetInputEnabled(true)
end

local function closeTuningWindow(doCancel)
	if doCancel then
		triggerServerEvent("vehiclerepair:cancelTrial", resourceRoot)
	end
	if isElement(tuningWindow) then
		destroyElement(tuningWindow)
	end
	tuningWindow = nil
	tuningGrid = nil
	showCursor(false)
	guiSetInputEnabled(false)
end

local function openTuningWindow()
	if isElement(tuningWindow) then
		closeTuningWindow(true)
	end

    local veh = getPedOccupiedVehicle(localPlayer)
    if not isElement(veh) then
        return
    end

    local sw, sh = guiGetScreenSize()
    local w, h = 360, 340
    local x, y = (sw - w) / 2, (sh - h) / 2

    tuningWindow = guiCreateWindow(x, y, w, h, "Advanced tuning - upgrades", false)
    guiWindowSetSizable(tuningWindow, false)

    tuningGrid = guiCreateGridList(10, 24, w - 20, h - 100, false, tuningWindow)
    guiGridListAddColumn(tuningGrid, "Upgrade", 0.7)
    guiGridListAddColumn(tuningGrid, "Installed", 0.2)

    local installed = {}
    for _, upg in ipairs(getVehicleUpgrades(veh) or {}) do
        installed[upg] = true
    end

    for slot = 0, 16 do
        local compat = getVehicleCompatibleUpgrades(veh, slot) or {}
        if #compat > 0 then
			local slotName = TUNING_SLOT_NAMES[slot] or ("Slot " .. tostring(slot))
			local price = TUNING_UPGRADE_PRICES[slot] or 500
			-- header row for this slot
			local headerRow = guiGridListAddRow(tuningGrid)
			guiGridListSetItemText(tuningGrid, headerRow, 1, string.format("%s ($%d)", slotName, price), false, false)
			guiGridListSetItemText(tuningGrid, headerRow, 2, "", false, false)
			guiGridListSetItemData(tuningGrid, headerRow, 1, { header = true, slot = slot })
			-- individual upgrade IDs under this slot
			for _, upg in ipairs(compat) do
				local row = guiGridListAddRow(tuningGrid)
				local label = string.format("%s %d ($%d)", slotName, upg, price)
				guiGridListSetItemText(tuningGrid, row, 1, label, false, false)
				guiGridListSetItemText(tuningGrid, row, 2, installed[upg] and "X" or "", false, false)
				guiGridListSetItemData(tuningGrid, row, 1, { id = upg, slot = slot, header = false })
			end
        end
    end

    local addBtn = guiCreateButton(10, h - 68, 80, 24, "Try add", false, tuningWindow)
    local removeBtn = guiCreateButton(100, h - 68, 80, 24, "Remove", false, tuningWindow)
    local colorBtn = guiCreateButton(190, h - 68, 80, 24, "Colour", false, tuningWindow)
    local paintBtn = guiCreateButton(w - 90, h - 68, 80, 24, "Paintjob", false, tuningWindow)
    local applyBtn = guiCreateButton(10, h - 36, w/2 - 15, 24, "Apply all", false, tuningWindow)
    local closeBtn = guiCreateButton(w - 90, 24, 80, 24, "Close", false, tuningWindow)
    local closeBtn2 = guiCreateButton(w - 90, h - 36, 80, 24, "Close", false, tuningWindow)

    addEventHandler("onClientGUIClick", addBtn, function()
        if source ~= addBtn then return end
        if not isElement(tuningGrid) then return end
        local row = guiGridListGetSelectedItem(tuningGrid)
        if not row or row < 0 then return end
        local data = guiGridListGetItemData(tuningGrid, row, 1)
        if type(data) ~= "table" or data.header then return end
        local id = tonumber(data.id)
        local slot = tonumber(data.slot)
        if not id or not slot then return end
        triggerServerEvent("vehiclerepair:trialUpgrade", resourceRoot, slot, id)
    end, false)

    addEventHandler("onClientGUIClick", removeBtn, function()
        if source ~= removeBtn then return end
        if not isElement(tuningGrid) then return end
        local row = guiGridListGetSelectedItem(tuningGrid)
        if not row or row < 0 then return end
        local data = guiGridListGetItemData(tuningGrid, row, 1)
        if type(data) ~= "table" then return end
        local slot = tonumber(data.slot)
        if not slot then return end
        triggerServerEvent("vehiclerepair:trialRemoveUpgrade", resourceRoot, slot)
    end, false)

    addEventHandler("onClientGUIClick", colorBtn, function()
        if source ~= colorBtn then return end
        if not colorPicker or type(colorPicker) ~= "table" then
            return
        end
        		editingVehicle = getPedOccupiedVehicle(localPlayer)
		if not isElement(editingVehicle) then
			return
		end
        local colors = { getVehicleColor(editingVehicle) }
        local r1, g1, b1 = getVehicleColor(editingVehicle, true)
        colorPicker.setValue({ r1 or 255, g1 or 255, b1 or 255 })
        colorPicker.openSelect(colors)
    end, false)

    addEventHandler("onClientGUIClick", paintBtn, function()
        if source ~= paintBtn then return end
        		if not isElement(getPedOccupiedVehicle(localPlayer)) then
			return
		end
        if isElement(paintWindow) then
            destroyElement(paintWindow)
            paintWindow = nil
            paintList = nil
        end

        local sw, sh = guiGetScreenSize()
        local pw, ph = 220, 200
        local px, py = (sw - pw) / 2, (sh - ph) / 2
        paintWindow = guiCreateWindow(px, py, pw, ph, "Car paintjob", false)
        guiWindowSetSizable(paintWindow, false)

        paintList = guiCreateGridList(10, 24, pw - 20, ph - 70, false, paintWindow)
        guiGridListAddColumn(paintList, "Paintjob ID", 0.8)
        for id = 0, 3 do
            local row = guiGridListAddRow(paintList)
            guiGridListSetItemText(paintList, row, 1, tostring(id), false, false)
            guiGridListSetItemData(paintList, row, 1, id)
        end

        local applyBtn = guiCreateButton(10, ph - 38, 80, 28, "Try", false, paintWindow)
        local closePaintBtn = guiCreateButton(pw - 90, ph - 38, 80, 28, "Close", false, paintWindow)

        addEventHandler("onClientGUIClick", applyBtn, function()
            if source ~= applyBtn then return end
            if not isElement(paintList) then return end
            local row = guiGridListGetSelectedItem(paintList)
            if not row or row < 0 then return end
            local id = guiGridListGetItemData(paintList, row, 1)
            id = tonumber(id)
            if not id then return end
            triggerServerEvent("vehiclerepair:trialPaintjob", resourceRoot, id)
        end, false)

        addEventHandler("onClientGUIClick", closePaintBtn, function()
            if source ~= closePaintBtn then return end
            if isElement(paintWindow) then
                destroyElement(paintWindow)
            end
            paintWindow = nil
            paintList = nil
        end, false)
    end, false)

    addEventHandler("onClientGUIClick", applyBtn, function()
		if source ~= applyBtn then return end
		triggerServerEvent("vehiclerepair:confirmTrial", resourceRoot)
		closeTuningWindow(false)
	end, false)

    local function handleCloseClick()
		if source ~= closeBtn and source ~= closeBtn2 then return end
		closeTuningWindow(true)
	end
	addEventHandler("onClientGUIClick", closeBtn, handleCloseClick, false)
	addEventHandler("onClientGUIClick", closeBtn2, handleCloseClick, false)

    showCursor(true)
    guiSetInputEnabled(true)
end

local function applyInfoToBrowser()
    if not isElement(browser) then return end
    if not lastHealthText or not lastPriceText or not lastUpgrades then return end

    local js = string.format([[ (function(){
        var healthText = %q;
        var priceText  = %q;
        var upgradesData = %s;

        var hLabel = document.getElementById('healthLabel');
        if (hLabel) hLabel.textContent = healthText;

        var rLabel = document.getElementById('repairPrice');
        if (rLabel) rLabel.textContent = priceText;

        var list = document.getElementById('upgradesList');
        if (list) {
            list.innerHTML = '';
            if (!upgradesData || !upgradesData.length) {
                var empty = document.createElement('div');
                empty.className = 'muted';
                empty.textContent = 'No compatible upgrades for this vehicle.';
                list.appendChild(empty);
            } else {
                for (var i = 0; i < upgradesData.length; i++) {
                    var group = upgradesData[i];
                    var slot = group.slot;
                    var price = group.price || 0;
                    var priceText = group.priceText || ('$' + price);
                    var upgs = group.upgrades || [];

                    if (!upgs.length) continue;

                    var header = document.createElement('div');
                    header.className = 'muted';
                    header.textContent = 'Slot ' + slot + ' (' + priceText + ' each)';
                    list.appendChild(header);

                    for (var j = 0; j < upgs.length; j++) {
                        var upgId = upgs[j];
                        var item = document.createElement('div');
                        item.className = 'upgrade-item';

                        var left = document.createElement('div');
                        left.className = 'upgrade-left';
                        var name = document.createElement('div');
                        name.className = 'upgrade-name';
                        name.textContent = 'Upgrade #' + upgId;
                        var slotLabel = document.createElement('div');
                        slotLabel.className = 'upgrade-slot';
                        slotLabel.textContent = 'Slot ' + slot;
                        left.appendChild(name);
                        left.appendChild(slotLabel);

                        var button = document.createElement('button');
                        button.className = 'btn-main';
                        button.style.padding = '6px 10px';
                        button.style.fontSize = '11px';
                        button.textContent = 'Install';

                        button.onclick = (function(s, u){
                            return function(){
                                if (window.mta) {
                                    window.mta.triggerEvent('vehiclerepair:uiEvent', 'upgrade', { slot: s, upgradeID: u });
                                }
                            };
                        })(slot, upgId);

                        item.appendChild(left);
                        item.appendChild(button);

                        list.appendChild(item);
                    }
                }
            }
        }

        var valuePart = String(healthText).split(' / ')[0];
        var healthVal = parseFloat(valuePart);
        if (isNaN(healthVal)) healthVal = 1000;
        var ratio = Math.max(0, Math.min(1, healthVal / 1000));
        var bar = document.getElementById('healthFill');
        if (bar) bar.style.transform = 'scaleX(' + ratio + ')';

        var status = document.getElementById('statusLabel');
        if (status) status.textContent = 'Idle';
    })(); ]],
        tostring(lastHealthText),
        tostring(lastPriceText),
        toJSON(lastUpgrades or {})
    )

    executeBrowserJavascript(browser, js)
end

local function createBrowser()
    if isElement(browserGUI) then return end

    local screenW, screenH = guiGetScreenSize()
    local width, height = math.floor(screenW * 0.55), math.floor(screenH * 0.6)
    local x, y = (screenW - width) / 2, (screenH - height) / 2

    browserGUI = guiCreateBrowser(x, y, width, height, true, true, false)
    browser = guiGetBrowser(browserGUI)

    addEventHandler("onClientBrowserCreated", browser, function()
        loadBrowserURL(browser, "http://mta/local/" .. uiURL)
    end)

    addEventHandler("onClientBrowserDocumentReady", browser, function(url)
        if not isPanelVisible then return end
        if not string.find(url, uiURL, 1, true) then return end

        applyInfoToBrowser()
    end)
end

local function destroyBrowser()
    if isElement(browserGUI) then
        destroyElement(browserGUI)
    end
    browserGUI = nil
    browser = nil
end

local function showPanel(state)
    if state then
        createBrowser()
        showCursor(true)
        guiSetInputEnabled(true)
        isPanelVisible = true
    else
        isPanelVisible = false
        showCursor(false)
        guiSetInputEnabled(false)
        destroyBrowser()
    end
end

-- Communication with HTML/JS
--------------------------------------

function sendJSONToUI() end -- no-op, kept only to avoid errors if called elsewhere

addEvent("vehiclerepair:openPanel", true)
addEventHandler("vehiclerepair:openPanel", resourceRoot, function(healthText, priceText, upgrades)
	lastHealthText = tostring(healthText or "1000 / 1000")
	lastPriceText = tostring(priceText or "$0")
	lastUpgrades = upgrades or {}
	showPanel(true)
	if isElement(browser) then
		applyInfoToBrowser()
    end
end)

-- Simple feedback events from server to update status text

addEvent("vehiclerepair:repairCompleted", true)
addEventHandler("vehiclerepair:repairCompleted", resourceRoot, function()
    if not isElement(browser) then return end
    local js = [[ if (window.setIdle) { setIdle('Repair complete', true); } ]] ..
               [[ var h=document.getElementById('healthLabel'); if(h) h.textContent='1000 / 1000'; ]] ..
               [[ var bar=document.getElementById('healthFill'); if(bar) bar.style.transform='scaleX(1)'; ]] ..
               [[ var p=document.getElementById('repairPrice'); if(p) p.textContent='$0'; ]]
    executeBrowserJavascript(browser, js)
end)

addEvent("vehiclerepair:upgradeCompleted", true)
addEventHandler("vehiclerepair:upgradeCompleted", resourceRoot, function(slot, upgradeID)
    if not isElement(browser) then return end
    local js = [[ if (window.setIdle) { setIdle('Upgrade installed', true); } ]]
    executeBrowserJavascript(browser, js)
end)

addEvent("vehiclerepair:actionFailed", true)
addEventHandler("vehiclerepair:actionFailed", resourceRoot, function(message)
    if not isElement(browser) then return end
    local msg = tostring(message or "Action failed")
    local js = string.format([[ if (window.setIdle) { setIdle(%q, false); } ]], msg)
    executeBrowserJavascript(browser, js)
end)

addEvent("vehiclerepair:playEffect", true)
addEventHandler("vehiclerepair:playEffect", resourceRoot, function()
    local player = localPlayer
    if not isElement(player) then return end
    local veh = getPedOccupiedVehicle(player)
    if not isElement(veh) then return end
    local x, y, z = getElementPosition(veh)
    local effect = createEffect("petrolsmall", x, y, z + 1)
    if effect then
        setTimer(function(e)
            if isElement(e) then destroyElement(e) end
        end, 1500, 1, effect)
    end
end)

-- Called from JS using mta.triggerEvent('vehiclerepair:uiEvent', action, ...)
addEvent("vehiclerepair:uiEvent", true)
addEventHandler("vehiclerepair:uiEvent", root, function(action, data, extra, extra2)
	if action == "close" then
		showPanel(false)
    elseif action == "open_stats" then
        showPanel(false)
        openStatsWindow()
    elseif action == "open_tuning" then
        showPanel(false)
        openTuningWindow()
    elseif action == "repair" then
        triggerServerEvent("vehiclerepair:requestRepair", resourceRoot)
    elseif action == "upgrade" and type(data) == "table" then
        if type(data.slot) == "number" and type(data.upgradeID) == "number" then
            triggerServerEvent("vehiclerepair:requestUpgrade", resourceRoot, data.slot, data.upgradeID)
        end
    	elseif action == "storage_trunk_confirm" then
		local percent = tonumber(data) or 0
		triggerServerEvent("vehiclerepair:requestStorageUpgrade", resourceRoot, "trunk", percent)
	elseif action == "storage_glovebox_confirm" then
		local percent = tonumber(data) or 0
		triggerServerEvent("vehiclerepair:requestStorageUpgrade", resourceRoot, "glovebox", percent)
	elseif action == "handling_custom" then
		local maxSpeed = tonumber(data) or 0
		local damageMul = tonumber(extra) or 0
		local accelMul = tonumber(extra2) or 0
		triggerServerEvent("vehiclerepair:requestHandlingCustom", resourceRoot, maxSpeed, damageMul, accelMul)
	elseif action == "jsError" and type(data) == "table" then
		local msg = tostring(data.message or "")
		local src = tostring(data.src or "")
		local line = tostring(data.line or "")
		local col = tostring(data.col or "")
	end
end)

-- Color picker integration (reuses freeroam-style behavior)
function closedColorPicker(r, g, b)
    if not editingVehicle or not isElement(editingVehicle) then return end

    local r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4 = getVehicleColor(editingVehicle, true)
    local hr, hg, hb = getVehicleHeadLightColor(editingVehicle)

    if guiCheckBoxGetSelected(checkColor1) then
        r1, g1, b1 = r, g, b
    end
    if guiCheckBoxGetSelected(checkColor2) then
        r2, g2, b2 = r, g, b
    end
    if guiCheckBoxGetSelected(checkColor3) then
        r3, g3, b3 = r, g, b
    end
    if guiCheckBoxGetSelected(checkColor4) then
        r4, g4, b4 = r, g, b
    end
    if guiCheckBoxGetSelected(checkColor5) then
        hr, hg, hb = r, g, b
    end

    triggerServerEvent("vehiclerepair:trialColor", resourceRoot,
        r1, g1, b1,
        r2, g2, b2,
        r3, g3, b3,
        r4, g4, b4,
        hr, hg, hb
    )
end

local function updateColor()
    if not colorPicker or type(colorPicker) ~= "table" then return end
    if not colorPicker.isSelectOpen then return end
    if not editingVehicle or not isElement(editingVehicle) then return end

    local r, g, b = colorPicker.updateTempColors()
    local r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4 = getVehicleColor(editingVehicle, true)

    if guiCheckBoxGetSelected(checkColor1) then
        r1, g1, b1 = r, g, b
    end
    if guiCheckBoxGetSelected(checkColor2) then
        r2, g2, b2 = r, g, b
    end
    if guiCheckBoxGetSelected(checkColor3) then
        r3, g3, b3 = r, g, b
    end
    if guiCheckBoxGetSelected(checkColor4) then
        r4, g4, b4 = r, g, b
    end
    if guiCheckBoxGetSelected(checkColor5) then
        setVehicleHeadLightColor(editingVehicle, r, g, b)
    end

    setVehicleColor(editingVehicle,
        r1, g1, b1,
        r2, g2, b2,
        r3, g3, b3,
        r4, g4, b4
    )
end
addEventHandler("onClientRender", root, updateColor)

bindKey("escape", "down", function()
    if isElement(tuningWindow) then
        closeTuningWindow(true)
    elseif isPanelVisible then
        showPanel(false)
    end
end)
