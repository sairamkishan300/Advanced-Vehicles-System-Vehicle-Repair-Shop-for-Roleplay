--------------------------------------
-- Vehicle Repair Shop - Server
--------------------------------------

local mechanicPermissionGroup = "Admin" -- ACL group name required to use the shop

-- Messages (English, change text here if needed)
local MSG_NEED_VEHICLE = "You must be in a vehicle to use the mechanic shop."
local MSG_NEED_DRIVER = "You must be driving the vehicle to use the mechanic shop."
local MSG_NO_PERMISSION_SHOP = "You do not have permission to use this shop."
local MSG_NO_PERMISSION_REPAIR = "You do not have permission to repair vehicles here."
local MSG_NO_PERMISSION_UPGRADE = "You do not have permission to upgrade vehicles here."
local MSG_NO_MONEY_REPAIR = "Not enough money for repair."
local MSG_NO_MONEY_UPGRADE = "Not enough money for this upgrade."
local MSG_UPGRADE_NOT_COMPATIBLE = "This upgrade is not compatible with your vehicle."

-- Mechanic shop marker positions (add more tables to this list)
local mechanicShopPositions = {
    { x = 1512.772, y = -1658.429, z = 13.285 }, -- main shop (from screenshot)
}

-- Handling packages (max speed / damage resistance)
local handlingPackages = {
    stock = {
        price = 0,
        maxVelocity = false,           -- false = reset to default
        collisionDamageMultiplier = false
    },
    sport = {
        price = 2500,
        maxVelocity = 220,
        collisionDamageMultiplier = 0.6
    },
    race = {
        price = 5000,
        maxVelocity = 260,
        collisionDamageMultiplier = 0.4
    }
}

local mechanicShopMarkers = {}

-- Base vehicle storage capacities (from Vehicles config)
local baseStorageByModel = {
    [400] = { trunk = 1500, glovebox = 300 }, -- Landstalker
    [401] = { trunk = 1300, glovebox = 280 }, -- Bravura
    [402] = { trunk = 1000, glovebox = 250 }, -- Buffalo
    [411] = { trunk = 800,  glovebox = 200 }, -- Infernus
    [415] = { trunk = 700,  glovebox = 200 }, -- Cheetah
    [429] = { trunk = 600,  glovebox = 180 }, -- Banshee
    [451] = { trunk = 900,  glovebox = 220 }, -- Turismo
    [561] = { trunk = 1100, glovebox = 250 }, -- Stratum
    [579] = { trunk = 1600, glovebox = 320 }, -- Huntley
    [580] = { trunk = 1400, glovebox = 290 }, -- Stafford
}

local defaultStorage = { trunk = 1000, glovebox = 250 }

local REPAIR_BASE_PRICE = 1000          -- base price for full repair
local REPAIR_HEALTH_FACTOR = 0.5        -- multiplied by missing health (1000 - currentHealth)

-- Simple upgrade price list by slot; you can tune these
local upgradePrices = {
    [0] = 500,   -- spoilers
    [1] = 400,   -- hood
    [2] = 400,   -- roof
    [3] = 600,   -- sideskirt
    [4] = 800,   -- lamps
    [5] = 700,   -- nitro
    [6] = 500,   -- exhaust
    [7] = 500,   -- wheels
    [8] = 300,   -- stereo
    [9] = 450,   -- hydraulics
    [10] = 350,  -- front bumper
    [11] = 350,  -- rear bumper
    [12] = 500,  -- vents
    [13] = 300,  -- bullbars
    [14] = 300   -- misc
}

--------------------------------------
-- Utility
--------------------------------------

local function playerHasMechanicPermission(player)
    local account = getPlayerAccount(player)
    if not account or isGuestAccount(account) then
        return false
    end
    local group = aclGetGroup(mechanicPermissionGroup)
    if not group then
        return false
    end
    local accountName = getAccountName(account)
    return isObjectInACLGroup("user." .. accountName, group)
end

local function getRepairPriceForVehicle(vehicle)
    if not isElement(vehicle) then return 0 end
    local health = getElementHealth(vehicle) or 1000
    if health > 1000 then
        health = 1000
    end
    local missing = 1000 - health
    if missing < 0 then
        missing = 0
    end
    local price = REPAIR_BASE_PRICE + math.floor(missing * REPAIR_HEALTH_FACTOR)
    return price
end

local function getUpgradePrice(slot)
    return upgradePrices[slot] or 500
end

local function getCompatibleUpgradesForVehicle(vehicle)
    if not isElement(vehicle) then return {} end
    local data = {}
    for slot, price in pairs(upgradePrices) do
        local compatible = getVehicleCompatibleUpgrades(vehicle, slot) or {}
        if #compatible > 0 then
            table.insert(data, {
                slot = slot,
                price = price,
                priceText = string.format("$%d", price),
                upgrades = compatible
            })
        end
    end
    return data
end

local function removeAllVehicleUpgrades(vehicle)
	if not isElement(vehicle) then return end
	local current = getVehicleUpgrades(vehicle) or {}
	for _, id in ipairs(current) do
		removeVehicleUpgrade(vehicle, id)
	end
end

local slotNames = {
    [0] = "Spoiler",
    [1] = "Hood",
    [2] = "Roof",
    [3] = "Sideskirt",
    [4] = "Lamps",
    [5] = "Nitro",
    [6] = "Exhaust",
    [7] = "Wheels",
    [8] = "Stereo",
    [9] = "Hydraulics",
    [10] = "Front bumper",
    [11] = "Rear bumper",
    [12] = "Vents",
    [13] = "Bullbars",
    [14] = "Extra"
}

local function buildUpgradesText(upgrades)
    if type(upgrades) ~= "table" or #upgrades == 0 then
        return "No compatible upgrades for this vehicle."
    end

    local lines = {}
    for _, group in ipairs(upgrades) do
        local slotName = slotNames[group.slot] or ("Slot " .. tostring(group.slot))
        local ids = {}
        for _, id in ipairs(group.upgrades or {}) do
            table.insert(ids, tostring(id))
        end
        local list = table.concat(ids, ", ")
        table.insert(lines, string.format("%s: %s ($%d)", slotName, list, group.price or 0))
    end

    return table.concat(lines, "\n")
end

-- Marker setup
--------------------------------------

addEventHandler("onResourceStart", resourceRoot, function()
    for _, pos in ipairs(mechanicShopPositions) do
        local marker = createMarker(
            pos.x,
            pos.y,
            pos.z - 1,
            "cylinder",
            2,
            0, 150, 255, 150
        )
        if marker then
            setElementData(marker, "vehiclerepair:isMechanicShop", true)
            table.insert(mechanicShopMarkers, marker)
        end
    end
end)

--------------------------------------
-- Open panel request
--------------------------------------

local function canUseShop(player, hitElement)
    if player ~= hitElement then return false, "" end

    if not isPedInVehicle(player) then
        return false, MSG_NEED_VEHICLE
    end

    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle then
        return false, MSG_NEED_VEHICLE
    end

    if getVehicleOccupant(vehicle, 0) ~= player then
        return false, MSG_NEED_DRIVER
    end

    if not playerHasMechanicPermission(player) then
        return false, MSG_NO_PERMISSION_SHOP
    end

    return true, ""
end

addEventHandler("onMarkerHit", root, function(hitElement, matchingDimension)
    if getElementType(source) ~= "marker" then return end
    if getElementData(source, "vehiclerepair:isMechanicShop") ~= true then return end
    if not matchingDimension then return end
    if getElementType(hitElement) ~= "player" then return end

    local allowed, reason = canUseShop(hitElement, hitElement)
    if not allowed then
        if reason and reason ~= "" then
        end
        return
    end

    local vehicle = getPedOccupiedVehicle(hitElement)
    if not vehicle then return end

    local vehicleHealth = getElementHealth(vehicle) or 1000
    if vehicleHealth > 1000 then vehicleHealth = 1000 end
    if vehicleHealth < 0 then vehicleHealth = 0 end

    local repairPrice = getRepairPriceForVehicle(vehicle)
    local upgrades = getCompatibleUpgradesForVehicle(vehicle)

    triggerClientEvent(hitElement, "vehiclerepair:openPanel", resourceRoot, string.format("%d / 1000", math.floor(vehicleHealth)), string.format("$%d", repairPrice), upgrades)
end)

local function playVehicleEffectForPlayer(player)
    if not isElement(player) then return end
    triggerClientEvent(player, "vehiclerepair:playEffect", resourceRoot)
end

--------------------------------------
-- Repair handling
--------------------------------------

addEvent("vehiclerepair:requestRepair", true)
addEventHandler("vehiclerepair:requestRepair", resourceRoot, function()
    local player = client
    if not isElement(player) then return end

    if not isPedInVehicle(player) then return end
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

    if not playerHasMechanicPermission(player) then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_PERMISSION_REPAIR)
        return
    end

    local price = getRepairPriceForVehicle(vehicle)

    if getPlayerMoney(player) < price then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_MONEY_REPAIR)
        return
    end

    -- Take money up front
    takePlayerMoney(player, price)

    -- Ensure vehicle can be repaired (remove frozen and damage proof)
    setElementFrozen(vehicle, false)
    setVehicleDamageProof(vehicle, false)

    -- Simulate repair delay on server side as well
    setTimer(function(p, v)
        if not isElement(p) or not isElement(v) then return end
        fixVehicle(v)
        setElementHealth(v, 1000)
        playVehicleEffectForPlayer(p)
        triggerClientEvent(p, "vehiclerepair:repairCompleted", resourceRoot)
    end, 4000, 1, player, vehicle)
end)

--------------------------------------
-- Upgrade handling
--------------------------------------

addEvent("vehiclerepair:requestUpgrade", true)
addEventHandler("vehiclerepair:requestUpgrade", resourceRoot, function(slot, upgradeID)
    local player = client
    if not isElement(player) then return end

    if type(slot) ~= "number" or type(upgradeID) ~= "number" then return end

    if not isPedInVehicle(player) then return end
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

    local price = getUpgradePrice(slot)

    if getPlayerMoney(player) < price then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_MONEY_UPGRADE)
        return
    end

    -- Check if upgrade is compatible
    local compatible = getVehicleCompatibleUpgrades(vehicle, slot) or {}
    local ok = false
    for _, id in ipairs(compatible) do
        if id == upgradeID then
            ok = true
            break
        end
    end

    if not ok then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_UPGRADE_NOT_COMPATIBLE)
        return
    end

    takePlayerMoney(player, price)

    setElementFrozen(vehicle, false)
    setVehicleDamageProof(vehicle, false)

    -- apply upgrade immediately (no delay)
    addVehicleUpgrade(vehicle, upgradeID)
    playVehicleEffectForPlayer(player)
    triggerClientEvent(player, "vehiclerepair:upgradeCompleted", resourceRoot, slot, upgradeID)
end)

-- Simple slot-based upgrade (pick first compatible for that slot)

addEvent("vehiclerepair:requestUpgradeSlot", true)
addEventHandler("vehiclerepair:requestUpgradeSlot", resourceRoot, function(slot)
    local player = client
    if not isElement(player) then return end
    if type(slot) ~= "number" then return end

    if not isPedInVehicle(player) then return end
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

    local price = getUpgradePrice(slot)
    if getPlayerMoney(player) < price then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_MONEY_UPGRADE)
        return
    end

    local compatible = getVehicleCompatibleUpgrades(vehicle, slot) or {}
    if #compatible == 0 then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_UPGRADE_NOT_COMPATIBLE)
        return
    end

    local targetUpgrade = compatible[1]

    takePlayerMoney(player, price)

    setElementFrozen(vehicle, false)
    setVehicleDamageProof(vehicle, false)

    -- apply upgrade immediately (no delay)
    addVehicleUpgrade(vehicle, targetUpgrade)
    playVehicleEffectForPlayer(player)
    triggerClientEvent(player, "vehiclerepair:upgradeCompleted", resourceRoot, slot, targetUpgrade)
end)

--------------------------------------
-- Storage upgrades (trunk / glovebox)
--------------------------------------

local STORAGE_MAX_MULTIPLIER = 1.3
local STORAGE_BASE_PRICE = 2000      -- price for full 30% upgrade

local HANDLING_CUSTOM_PRICE = 2500   -- flat price for applying custom slider handling
local COLOR_CHANGE_PRICE   = 1500    -- price for applying custom colour
local PAINTJOB_PRICE       = 2000    -- price for changing paintjob

-- trial state for advanced tuning panel
local tuningTrials = {} -- [vehicle] = { player=element, origUpgrades={}, origColor={}, origPaint=nil, costUpgrades=0, costColor=0, costPaint=0 }

local function snapshotVehicleStateForTrial(vehicle, player)
	local state = tuningTrials[vehicle]
	if state then return state end

	local upgrades = getVehicleUpgrades(vehicle) or {}
	local r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4 = getVehicleColor(vehicle, true)
	local hr, hg, hb = getVehicleHeadLightColor(vehicle)
	local paint = getVehiclePaintjob(vehicle)

	state = {
		player = player,
		origUpgrades = upgrades,
		origColor = { r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4 },
		origHeadlights = { hr, hg, hb },
		origPaint = paint,
		costUpgrades = 0,
		costColor = 0,
		costPaint = 0,
	}
	tuningTrials[vehicle] = state
	return state
end

addEvent("vehiclerepair:requestStorageUpgrade", true)
addEventHandler("vehiclerepair:requestStorageUpgrade", resourceRoot, function(kind, percent)
    local player = client
    if not isElement(player) then return end
    if kind ~= "trunk" and kind ~= "glovebox" then return end

    if not isPedInVehicle(player) then return end
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

    local key = kind

    local model = getElementModel(vehicle)
    local base = baseStorageByModel[model] or defaultStorage
    local baseValue = tonumber(base[key] or defaultStorage[key] or 0) or 0
    if baseValue <= 0 then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, "No base storage configured for this vehicle.")
        return
    end

    -- current value comes from your existing system; if missing, start from base
    local current = tonumber(getElementData(vehicle, key) or 0) or 0
    if current <= 0 then
        current = baseValue
    end

    -- desired level as percent of base (0-30, where 30 means base*1.3)
    local pct = tonumber(percent) or STORAGE_MAX_MULTIPLIER * 100 - 100 -- default: full 30%
    if pct < 0 then pct = 0 end
    local maxPct = STORAGE_MAX_MULTIPLIER * 100 - 100 -- 30
    if pct > maxPct then pct = maxPct end

    local target = math.floor(baseValue * (1 + pct / 100))
    local hardMax = math.floor(baseValue * STORAGE_MAX_MULTIPLIER)
    if target > hardMax then
        target = hardMax
    end

    if current >= target then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, key .. " is already at or above this level.")
        return
    end

    local newValue = target

    -- price scales with chosen percent, so smaller upgrades are cheaper
    local price = math.floor(STORAGE_BASE_PRICE * (pct / maxPct))
    if price < 1 then price = 1 end

    if getPlayerMoney(player) < price then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_MONEY_UPGRADE)
        return
    end

    takePlayerMoney(player, price)
    setElementData(vehicle, key, newValue)
    playVehicleEffectForPlayer(player)
    triggerClientEvent(player, "vehiclerepair:upgradeCompleted", resourceRoot, -2, -2)
end)

--------------------------------------
-- Handling upgrades
--------------------------------------

addEvent("vehiclerepair:requestHandling", true)
addEventHandler("vehiclerepair:requestHandling", resourceRoot, function(packageName)
    local player = client
    if not isElement(player) then return end

    if type(packageName) ~= "string" then return end
    local pkg = handlingPackages[packageName]
    if not pkg then return end

    if not isPedInVehicle(player) then return end
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

    if not playerHasMechanicPermission(player) then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_PERMISSION_UPGRADE)
        return
    end

    if HANDLING_CUSTOM_PRICE > 0 and getPlayerMoney(player) < HANDLING_CUSTOM_PRICE then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_MONEY_UPGRADE)
        return
    end

    local price = pkg.price or 0
    if price > 0 and getPlayerMoney(player) < price then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_MONEY_UPGRADE)
        return
    end

    if price > 0 then
        takePlayerMoney(player, price)
    end

    -- Apply handling; false values mean reset to default
    if pkg.maxVelocity then
        setVehicleHandling(vehicle, "maxVelocity", pkg.maxVelocity)
    else
        setVehicleHandling(vehicle, "maxVelocity", nil)
    end

    if pkg.collisionDamageMultiplier then
        setVehicleHandling(vehicle, "collisionDamageMultiplier", pkg.collisionDamageMultiplier)
    else
        setVehicleHandling(vehicle, "collisionDamageMultiplier", nil)
    end

    playVehicleEffectForPlayer(player)
    triggerClientEvent(player, "vehiclerepair:upgradeCompleted", resourceRoot, -1, -1)
end)

-- Custom handling from sliders (absolute values)

addEvent("vehiclerepair:requestHandlingCustom", true)
addEventHandler("vehiclerepair:requestHandlingCustom", resourceRoot, function(maxSpeed, damageMul, accelMul)
    local player = client
    if not isElement(player) then return end

    if not isPedInVehicle(player) then return end
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

    if not playerHasMechanicPermission(player) then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_PERMISSION_UPGRADE)
        return
    end

    maxSpeed = tonumber(maxSpeed)
    damageMul = tonumber(damageMul)
    accelMul = tonumber(accelMul)

    if maxSpeed then
        if maxSpeed < 80 then maxSpeed = 80 end
        if maxSpeed > 300 then maxSpeed = 300 end
        setVehicleHandling(vehicle, "maxVelocity", maxSpeed)
    end

    if damageMul then
        if damageMul < 0.2 then damageMul = 0.2 end
        if damageMul > 2.0 then damageMul = 2.0 end
        setVehicleHandling(vehicle, "collisionDamageMultiplier", damageMul)
    end

    if accelMul then
        if accelMul < 0.5 then accelMul = 0.5 end
        if accelMul > 1.5 then accelMul = 1.5 end
        local handling = getVehicleHandling(vehicle)
        local baseAccel = handling and handling["engineAcceleration"] or nil
        if baseAccel then
            setVehicleHandling(vehicle, "engineAcceleration", baseAccel * accelMul)
        end
    end

    if HANDLING_CUSTOM_PRICE > 0 then
        takePlayerMoney(player, HANDLING_CUSTOM_PRICE)
    end

    playVehicleEffectForPlayer(player)
    triggerClientEvent(player, "vehiclerepair:upgradeCompleted", resourceRoot, -3, -3)
end)

--------------------------------------
-- Colour & paintjob from tuning panel
--------------------------------------

addEvent("vehiclerepair:requestColor", true)
addEventHandler("vehiclerepair:requestColor", resourceRoot, function(
    r1, g1, b1,
    r2, g2, b2,
    r3, g3, b3,
    r4, g4, b4,
    hr, hg, hb
)
    local player = client
    if not isElement(player) then return end

    if not isPedInVehicle(player) then return end
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

    if COLOR_CHANGE_PRICE > 0 and getPlayerMoney(player) < COLOR_CHANGE_PRICE then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_MONEY_UPGRADE)
        return
    end

    local function clamp255(v)
        v = tonumber(v) or 0
        if v < 0 then v = 0 end
        if v > 255 then v = 255 end
        return v
    end

    r1, g1, b1 = clamp255(r1), clamp255(g1), clamp255(b1)
    r2, g2, b2 = clamp255(r2), clamp255(g2), clamp255(b2)
    r3, g3, b3 = clamp255(r3), clamp255(g3), clamp255(b3)
    r4, g4, b4 = clamp255(r4), clamp255(g4), clamp255(b4)
    hr, hg, hb = clamp255(hr), clamp255(hg), clamp255(hb)

    if COLOR_CHANGE_PRICE > 0 then
        takePlayerMoney(player, COLOR_CHANGE_PRICE)
    end

    setVehicleColor(vehicle, r1, g1, b1,
                             r2, g2, b2,
                             r3, g3, b3,
                             r4, g4, b4)
    setVehicleHeadLightColor(vehicle, hr, hg, hb)

    playVehicleEffectForPlayer(player)
    triggerClientEvent(player, "vehiclerepair:upgradeCompleted", resourceRoot, -4, -4)
end)

addEvent("vehiclerepair:requestPaintjob", true)
addEventHandler("vehiclerepair:requestPaintjob", resourceRoot, function(paintID)
    local player = client
    if not isElement(player) then return end

    if not isPedInVehicle(player) then return end
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

    paintID = tonumber(paintID)
    if not paintID or paintID < 0 or paintID > 3 then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, "Invalid paintjob ID.")
        return
    end

    if PAINTJOB_PRICE > 0 and getPlayerMoney(player) < PAINTJOB_PRICE then
        triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_MONEY_UPGRADE)
        return
    end

    if PAINTJOB_PRICE > 0 then
        takePlayerMoney(player, PAINTJOB_PRICE)
    end

    setVehiclePaintjob(vehicle, paintID)

    playVehicleEffectForPlayer(player)
    triggerClientEvent(player, "vehiclerepair:upgradeCompleted", resourceRoot, -5, -5)
end)

--------------------------------------
-- Trial API for advanced tuning panel
--------------------------------------

-- trial upgrade (apply immediately, no charge yet)
addEvent("vehiclerepair:trialUpgrade", true)
addEventHandler("vehiclerepair:trialUpgrade", resourceRoot, function(slot, upgradeID)
	local player = client
	if not isElement(player) then return end
	if type(slot) ~= "number" or type(upgradeID) ~= "number" then return end
	if not isPedInVehicle(player) then return end
	local vehicle = getPedOccupiedVehicle(player)
	if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end
	if not playerHasMechanicPermission(player) then return end

	-- ensure upgrade is compatible
	local compatible = getVehicleCompatibleUpgrades(vehicle, slot) or {}
	local ok = false
	for _, id in ipairs(compatible) do
		if id == upgradeID then ok = true break end
	end
	if not ok then return end

	local state = snapshotVehicleStateForTrial(vehicle, player)
	local price = getUpgradePrice(slot)
	state.costUpgrades = (state.costUpgrades or 0) + price

	addVehicleUpgrade(vehicle, upgradeID)
end)

-- remove upgrade for a slot in trial (free)
addEvent("vehiclerepair:trialRemoveUpgrade", true)
addEventHandler("vehiclerepair:trialRemoveUpgrade", resourceRoot, function(slot)
	local player = client
	if not isElement(player) then return end
	if type(slot) ~= "number" then return end
	if not isPedInVehicle(player) then return end
	local vehicle = getPedOccupiedVehicle(player)
	if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end
	if not playerHasMechanicPermission(player) then return end

	snapshotVehicleStateForTrial(vehicle, player)

	local current = getVehicleUpgrades(vehicle) or {}
	for _, id in ipairs(current) do
		if getVehicleUpgradeSlotName and getVehicleUpgradeSlotName(id) then end
	end
	-- simplest: remove all upgrades in this slot using compat list
	local compat = getVehicleCompatibleUpgrades(vehicle, slot) or {}
	for _, id in ipairs(compat) do
		removeVehicleUpgrade(vehicle, id)
	end
end)

-- trial paintjob: apply visually, charge later
addEvent("vehiclerepair:trialPaintjob", true)
addEventHandler("vehiclerepair:trialPaintjob", resourceRoot, function(paintID)
	local player = client
	if not isElement(player) then return end
	if not isPedInVehicle(player) then return end
	local vehicle = getPedOccupiedVehicle(player)
	if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

	paintID = tonumber(paintID)
	if not paintID or paintID < 0 or paintID > 3 then return end

	local state = snapshotVehicleStateForTrial(vehicle, player)
	if (state.costPaint or 0) <= 0 then
		state.costPaint = PAINTJOB_PRICE
	end
	setVehiclePaintjob(vehicle, paintID)
end)

-- trial colour: apply visually, charge later
addEvent("vehiclerepair:trialColor", true)
addEventHandler("vehiclerepair:trialColor", resourceRoot, function(
	r1, g1, b1,
	r2, g2, b2,
	r3, g3, b3,
	r4, g4, b4,
	hr, hg, hb
)
	local player = client
	if not isElement(player) then return end
	if not isPedInVehicle(player) then return end
	local vehicle = getPedOccupiedVehicle(player)
	if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

	local function clamp255(v)
		v = tonumber(v) or 0
		if v < 0 then v = 0 end
		if v > 255 then v = 255 end
		return v
	end

	local state = snapshotVehicleStateForTrial(vehicle, player)
	if (state.costColor or 0) <= 0 then
		state.costColor = COLOR_CHANGE_PRICE
	end

	setVehicleColor(vehicle,
		clamp255(r1), clamp255(g1), clamp255(b1),
		clamp255(r2), clamp255(g2), clamp255(b2),
		clamp255(r3), clamp255(g3), clamp255(b3),
		clamp255(r4), clamp255(g4), clamp255(b4)
	)
	setVehicleHeadLightColor(vehicle, clamp255(hr), clamp255(hg), clamp255(hb))
end)

-- confirm: charge once, keep current state
addEvent("vehiclerepair:confirmTrial", true)
addEventHandler("vehiclerepair:confirmTrial", resourceRoot, function()
	local player = client
	if not isElement(player) then return end
	if not isPedInVehicle(player) then return end
	local vehicle = getPedOccupiedVehicle(player)
	if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

	local state = tuningTrials[vehicle]
	if not state or state.player ~= player then return end

	local total = (state.costUpgrades or 0) + (state.costColor or 0) + (state.costPaint or 0)
	if total <= 0 then
		-- nothing to pay, just clear state
		tuningTrials[vehicle] = nil
		return
	end

	if getPlayerMoney(player) < total then
		triggerClientEvent(player, "vehiclerepair:actionFailed", resourceRoot, MSG_NO_MONEY_UPGRADE)
		-- also revert to original state to avoid free trials
		local r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4 = unpack(state.origColor or {})
		local hr, hg, hb = unpack(state.origHeadlights or {})
		if state.origPaint then
			setVehiclePaintjob(vehicle, state.origPaint)
		end
		if r1 then
			setVehicleColor(vehicle, r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4)
		end
		if hr then
			setVehicleHeadLightColor(vehicle, hr, hg, hb)
		end
		-- restore upgrades
		removeAllVehicleUpgrades(vehicle)
		for _, id in ipairs(state.origUpgrades or {}) do
			addVehicleUpgrade(vehicle, id)
		end
		tuningTrials[vehicle] = nil
		return
	end

	takePlayerMoney(player, total)
	playVehicleEffectForPlayer(player)
	tuningTrials[vehicle] = nil
end)

-- cancel: revert to original state, no charge
addEvent("vehiclerepair:cancelTrial", true)
addEventHandler("vehiclerepair:cancelTrial", resourceRoot, function()
	local player = client
	if not isElement(player) then return end
	if not isPedInVehicle(player) then return end
	local vehicle = getPedOccupiedVehicle(player)
	if not vehicle or getVehicleOccupant(vehicle, 0) ~= player then return end

	local state = tuningTrials[vehicle]
	if not state or state.player ~= player then return end

	local r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4 = unpack(state.origColor or {})
	local hr, hg, hb = unpack(state.origHeadlights or {})
	if state.origPaint then
		setVehiclePaintjob(vehicle, state.origPaint)
	end
	if r1 then
		setVehicleColor(vehicle, r1, g1, b1, r2, g2, b2, r3, g3, b3, r4, g4, b4)
	end
	if hr then
		setVehicleHeadLightColor(vehicle, hr, hg, hb)
	end
	removeAllVehicleUpgrades(vehicle)
	for _, id in ipairs(state.origUpgrades or {}) do
		addVehicleUpgrade(vehicle, id)
	end
	tuningTrials[vehicle] = nil
end)
