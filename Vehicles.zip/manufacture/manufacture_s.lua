-- Car Manufacture - Server Side

local manufactureConfig = {
    shop = {
        x = 315,
        y = -1771,
        z = 4.7,
        interior = 0,
        dimension = 0,
        radius = 1.5,
    },
    assembly = {
        x = 364.8,
        y = -1784.3,
        z = 5.4,
        interior = 0,
        dimension = 0,
        radius = 2,
    },
    vehicles = {
        {
            model = 415,
            price = 30000,
            brandname = "Benz",
            displayName = "Mercedes Benz",
            assemblyTime = 8000,
            partsPrice = 5000,
        },
        {
            model = 411,
            price = 30000,
            brandname = "Grotti",
            displayName = "inferiuz",
            assemblyTime = 10000,
            partsPrice = 10000,
        },
    },
}

local playerState = {}

local function getState(player)
    if not playerState[player] then
        playerState[player] = {
            hasParts = false,
            isAssembling = false,
            selectedVehicleIndex = nil,
        }
    end
    return playerState[player]
end

local function manufactureHasPermission(player)
    if not isElement(player) then return false end
    if not getPlayerAccount then return false end
    local account = getPlayerAccount(player)
    if not account or isGuestAccount(account) then return false end

    -- Use PermissionGroup from config.lua (default: "Admin")
    local groupName = dealerPermissionGroup
    local group = aclGetGroup(groupName)
    if not group then return false end
    return isObjectInACLGroup("user." .. getAccountName(account), group)
end

local function createMarkers()
    local shopCfg = manufactureConfig.shop
    local asmCfg = manufactureConfig.assembly

    local shopMarker = createMarker(shopCfg.x, shopCfg.y, shopCfg.z - 1, "cylinder", shopCfg.radius, 50, 150, 250, 150)
    setElementInterior(shopMarker, shopCfg.interior)
    setElementDimension(shopMarker, shopCfg.dimension)
    setElementData(shopMarker, "vehicles:manufacture:type", "shop")

    local asmMarker = createMarker(asmCfg.x, asmCfg.y, asmCfg.z - 1, "cylinder", asmCfg.radius, 137, 40, 212, 150)
    setElementInterior(asmMarker, asmCfg.interior)
    setElementDimension(asmMarker, asmCfg.dimension)
    setElementData(asmMarker, "vehicles:manufacture:type", "assembly")
end

addEventHandler("onResourceStart", resourceRoot, function()
    createMarkers()
end)

addEventHandler("onMarkerHit", resourceRoot, function(player, matchingDimension)
    if getElementType(player) ~= "player" or not matchingDimension then return end
    local kind = getElementData(source, "vehicles:manufacture:type")
    if not kind then return end

    if not manufactureHasPermission(player) then
        triggerClientEvent(player, "add:notification", player, "You do not have permission to use manufacture", "error", true)
        return
    end

    if kind == "shop" then
        triggerClientEvent(player, "vehicles:manufacture:openShop", resourceRoot, manufactureConfig.vehicles)
    elseif kind == "assembly" then
        local st = getState(player)
        if not st.hasParts then
            triggerClientEvent(player, "add:notification", player, "You need to buy the parts first", "warn", true)
            return
        end
        local idx = st.selectedVehicleIndex or 1
        local vcfg = manufactureConfig.vehicles[idx] or manufactureConfig.vehicles[1]
        triggerClientEvent(player, "vehicles:manufacture:openAssembly", resourceRoot, vcfg)
    end
end)

addEvent("vehicles:manufacture:buyParts", true)
addEventHandler("vehicles:manufacture:buyParts", resourceRoot, function(selectedIndex)
    local player = client
    if not isElement(player) then return end
    if not manufactureHasPermission(player) then
        triggerClientEvent(player, "add:notification", player, "You do not have permission", "error", true)
        return
    end

    local st = getState(player)
    if st.hasParts then
        triggerClientEvent(player, "add:notification", player, "You already have parts", "warn", true)
        return
    end

    local idx = tonumber(selectedIndex) or 1
    local vcfg = manufactureConfig.vehicles[idx] or manufactureConfig.vehicles[1]
    local price = vcfg.partsPrice or 0
    if price > 0 and exports and exports.money and exports.money.getMoney then
        local account = getPlayerAccount(player)
        if not account then return end
        local balance = exports.money:getMoney(account)
        if balance < price then
            triggerClientEvent(player, "add:notification", player, "You don't have enough money for parts", "error", true)
            return
        end
        exports.money:takeMoney(account, price)
    end

    st.hasParts = true
    st.selectedVehicleIndex = idx
    triggerClientEvent(player, "add:notification", player, "Parts purchased successfully", "success", true)
end)

addEvent("vehicles:manufacture:startAssembly", true)
addEventHandler("vehicles:manufacture:startAssembly", resourceRoot, function()
    local player = client
    if not isElement(player) then return end
    if not manufactureHasPermission(player) then
        triggerClientEvent(player, "add:notification", player, "You do not have permission", "error", true)
        return
    end

    local st = getState(player)
    if not st.hasParts or st.isAssembling then
        triggerClientEvent(player, "add:notification", player, "You need parts and must not already be assembling", "warn", true)
        return
    end

    st.isAssembling = true
    local idx = st.selectedVehicleIndex or 1
    local vcfg = manufactureConfig.vehicles[idx] or manufactureConfig.vehicles[1]
    local duration = vcfg.assemblyTime or 8000
    triggerClientEvent(player, "vehicles:manufacture:assemblyProgress", resourceRoot, duration)
    setPedAnimation(player, "BD_FIRE", "wash_up", -1, true, false, false, false)

    local asmCfg = manufactureConfig.assembly
    local parts = {}
    for i = 1, 4 do
        local offsetX = (i <= 2) and -1 or 1
        local offsetY = (i % 2 == 0) and 1.5 or -1.5
        local obj = createObject(1008, asmCfg.x + offsetX, asmCfg.y + offsetY, asmCfg.z)
        setElementInterior(obj, asmCfg.interior)
        setElementDimension(obj, asmCfg.dimension)
        parts[#parts + 1] = obj
    end

    setTimer(function()
        if not isElement(player) then return end
        setPedAnimation(player, false)
        for _, obj in ipairs(parts) do
            if isElement(obj) then destroyElement(obj) end
        end
        st.hasParts = false
        st.isAssembling = false

        if type(PlayerVehicleBuy) == "function" then
            PlayerVehicleBuy(player, nil, vcfg.model, vcfg.price, vcfg.brandname, vcfg.displayName)
            setTimer(function()
                if not isElement(player) then return end
                local veh = getPedOccupiedVehicle(player)
                if veh and getElementType(veh) == "vehicle" then
                    setElementData(veh, "owner", "kkrp3000")
                    if VehicleSavetoDB then
                        VehicleSavetoDB(veh)
                    end
                end
            end, 1000, 1)
        else
            triggerClientEvent(player, "add:notification", player, "Manufacture error: vehicle system not ready", "error", true)
        end
    end, duration, 1)
end)
