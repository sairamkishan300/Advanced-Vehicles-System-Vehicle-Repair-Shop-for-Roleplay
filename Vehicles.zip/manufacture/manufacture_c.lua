-- Car Manufacture - Client Side

local uiBrowserElement
local uiBrowser
local uiVisible = false
local currentMode = nil
local currentVehicleCfg = nil

local screenW, screenH = guiGetScreenSize()

local function destroyUI()
	if uiBrowserElement and isElement(uiBrowserElement) then
		destroyElement(uiBrowserElement)
	end
	uiBrowserElement = nil
	uiBrowser = nil
	uiVisible = false
	currentMode = nil
	showCursor(false)
	guiSetInputMode("allow_binds")
end

local function ensureBrowserLoaded(onReady)
	if uiBrowser and isElement(uiBrowserElement) then
		if onReady then onReady() end
		return
	end

	uiBrowserElement = guiCreateBrowser(0, 0, screenW, screenH, true, true, false)
	uiBrowser = guiGetBrowser(uiBrowserElement)
	addEventHandler("onClientBrowserCreated", uiBrowser, function()
		loadBrowserURL(uiBrowser, "http://mta/local/manufacture/html/index.html")
	end, false)
	addEventHandler("onClientBrowserDocumentReady", uiBrowser, function()
		if onReady then onReady() end
	end, false)
end

local function showUI(mode, vehicleCfg)
	currentMode = mode
	currentVehicleCfg = vehicleCfg
	ensureBrowserLoaded(function()
		if mode == "shop" then
			-- vehicleCfg is the list of manufacture vehicles here
			local jsArray = "["
			if type(vehicleCfg) == "table" then
				for i, v in ipairs(vehicleCfg) do
					if i > 1 then jsArray = jsArray .. "," end
					local model = tonumber(v.model) or 0
					local displayName = tostring(v.displayName or "")
					local brandname = tostring(v.brandname or "")
					local partsPrice = tonumber(v.partsPrice) or 0
					jsArray = jsArray .. string.format("{\"model\":%d,\"displayName\":%q,\"brandname\":%q,\"partsPrice\":%d}", model, displayName, brandname, partsPrice)
				end
			end
			jsArray = jsArray .. "]"
			executeBrowserJavascript(uiBrowser, string.format("window.setManufactureData('%s', %s);", mode, jsArray))
		else
			local price = 0
			if vehicleCfg and vehicleCfg.partsPrice then
				price = tonumber(vehicleCfg.partsPrice) or 0
			end
			executeBrowserJavascript(uiBrowser, string.format("window.setManufactureData('%s', %d);", mode, price))
		end
		showCursor(true)
		guiSetInputMode("no_binds")
		uiVisible = true
	end)
end

addEvent("vehicles:manufacture:openShop", true)
addEventHandler("vehicles:manufacture:openShop", root, function(vehicleList)
	showUI("shop", vehicleList)
end)

addEvent("vehicles:manufacture:openAssembly", true)
addEventHandler("vehicles:manufacture:openAssembly", root, function(vehicleCfg)
	showUI("assembly", vehicleCfg)
end)

addEvent("vehicles:manufacture:uiAction", true)
addEventHandler("vehicles:manufacture:uiAction", root, function(action, arg1)
	if action == "close" then
		destroyUI()
	elseif action == "buyParts" then
		local selectedIndex = tonumber(arg1) or 1
		triggerServerEvent("vehicles:manufacture:buyParts", resourceRoot, selectedIndex)
		destroyUI()
	elseif action == "startAssembly" then
		triggerServerEvent("vehicles:manufacture:startAssembly", resourceRoot)
		destroyUI()
	end
end)

addEvent("vehicles:manufacture:assemblyProgress", true)
addEventHandler("vehicles:manufacture:assemblyProgress", root, function(duration)
	ensureBrowserLoaded(function()
		executeBrowserJavascript(uiBrowser, string.format("window.startAssemblyProgress(%d);", duration))
		showCursor(false)
		guiSetInputMode("no_binds")
		uiVisible = true
	end)
end)

addEventHandler("onClientResourceStop", resourceRoot, function()
	destroyUI()
end)
