function setMode(mode) {
    document.querySelectorAll('.mode').forEach(m => m.classList.remove('active'));
    if (mode === 'shop') {
        document.getElementById('mode-shop').classList.add('active');
    } else if (mode === 'assembly') {
        document.getElementById('mode-assembly').classList.add('active');
    } else if (mode === 'progress') {
        document.getElementById('mode-progress').classList.add('active');
    }
}

window.MANUFACTURE_MODE = window.MANUFACTURE_MODE || 'shop';
window.MANUFACTURE_PRICE = window.MANUFACTURE_PRICE || 0;
window.MANUFACTURE_LIST = window.MANUFACTURE_LIST || [];
window.MANUFACTURE_SELECTED_INDEX = 0;

// Called from Lua to update panel state
window.setManufactureData = function(mode, payload) {
    if (typeof mode === 'string') {
        window.MANUFACTURE_MODE = mode;
    }

    // Lua may send raw JSON (array) or JSON string; handle both
    if (Array.isArray(payload)) {
        window.MANUFACTURE_LIST = payload;
    } else if (typeof payload === 'string') {
        try {
            const parsed = JSON.parse(payload);
            if (Array.isArray(parsed)) {
                window.MANUFACTURE_LIST = parsed;
            }
        } catch (e) {
            // ignore parse errors, keep previous list
        }
    } else if (typeof payload === 'number') {
        // Used when mode is 'assembly' and payload is just a price
        window.MANUFACTURE_PRICE = payload;
    }

    const listContainer = document.getElementById('carList');
    if (listContainer && Array.isArray(window.MANUFACTURE_LIST) && window.MANUFACTURE_LIST.length) {
        listContainer.innerHTML = '';
        window.MANUFACTURE_LIST.forEach((car, index) => {
            const item = document.createElement('div');
            item.className = 'car-item' + (index === window.MANUFACTURE_SELECTED_INDEX ? ' selected' : '');
            const modelLabel = (typeof car.model !== 'undefined' && car.model !== null) ? car.model : '';
            const name = car.displayName || car.brandname || ('Model ' + modelLabel);
            const price = (typeof car.partsPrice === 'number' && car.partsPrice > 0)
                ? car.partsPrice
                : (typeof car.price === 'number' ? car.price : 0);
            item.innerHTML = `<span>${name}</span><span>$${price}</span>`;
            item.onclick = function() {
                window.MANUFACTURE_SELECTED_INDEX = index;
                if (typeof mta !== 'undefined') {
                    mta.triggerEvent('vehicles:manufacture:uiAction', 'selectIndex', index + 1);
                }
                document.querySelectorAll('.car-item').forEach((el, i) => {
                    el.classList.toggle('selected', i === window.MANUFACTURE_SELECTED_INDEX);
                });
            };
            listContainer.appendChild(item);
        });
        const first = window.MANUFACTURE_LIST[window.MANUFACTURE_SELECTED_INDEX] || window.MANUFACTURE_LIST[0];
        if (first) {
            if (typeof first.partsPrice === 'number' && first.partsPrice > 0) {
                window.MANUFACTURE_PRICE = first.partsPrice;
            } else if (typeof first.price === 'number') {
                window.MANUFACTURE_PRICE = first.price;
            } else {
                window.MANUFACTURE_PRICE = 0;
            }
        }
    }

    const priceEl = document.getElementById('partsPrice');
    if (priceEl) priceEl.textContent = '$' + (window.MANUFACTURE_PRICE || 0);

    setMode(window.MANUFACTURE_MODE || 'shop');
};

window.setManufactureModeAndPrice = function(mode, price) {
    window.setManufactureData(mode, price);
    setMode(window.MANUFACTURE_MODE || 'shop');
    const priceEl = document.getElementById('partsPrice');
    if (priceEl) priceEl.textContent = '$' + (window.MANUFACTURE_PRICE || 0);
};

window.addEventListener('load', () => {
    // Initialize with whatever Lua set before load (if anything)
    window.setManufactureData(window.MANUFACTURE_MODE, window.MANUFACTURE_LIST);

    document.getElementById('closeBtn').addEventListener('click', () => {
        if (window.mta) mta.triggerEvent('vehicles:manufacture:uiAction', 'close');
    });

    const buyBtn = document.getElementById('buyPartsBtn');
    if (buyBtn) {
        buyBtn.addEventListener('click', () => {
            if (window.mta) {
                var idx = (typeof window.MANUFACTURE_SELECTED_INDEX === 'number' ? window.MANUFACTURE_SELECTED_INDEX : 0) + 1;
                mta.triggerEvent('vehicles:manufacture:uiAction', 'buyParts', idx);
            }
        });
    }

    const asmBtn = document.getElementById('startAssemblyBtn');
    if (asmBtn) {
        asmBtn.addEventListener('click', () => {
            if (window.mta) mta.triggerEvent('vehicles:manufacture:uiAction', 'startAssembly');
        });
    }
});

window.startAssemblyProgress = function(durationMs) {
    setMode('progress');
    const bar = document.getElementById('progressInner');
    const label = document.getElementById('progressLabel');
    const start = performance.now();

    function step(now) {
        const elapsed = now - start;
        const pct = Math.min(1, elapsed / durationMs);
        const pct100 = Math.round(pct * 100);
        if (bar) bar.style.width = pct100 + '%';
        if (label) label.textContent = pct100 + '%';
        if (pct < 1) {
            requestAnimationFrame(step);
        }
    }

    requestAnimationFrame(step);
};
