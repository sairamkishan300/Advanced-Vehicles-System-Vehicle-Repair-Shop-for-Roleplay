local db = dbConnect("sqlite", "vehicles.db")

-- SQL statement to create or update the 'vehicles' table
local createTableQuery = [[
    CREATE TABLE IF NOT EXISTS vehicles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        model INTEGER NOT NULL,
        x REAL NOT NULL,
        y REAL NOT NULL,
        z REAL NOT NULL,
        rx REAL NOT NULL,
        ry REAL NOT NULL,
        rz REAL NOT NULL,
        owner TEXT NOT NULL,
        color TEXT NOT NULL,
        paintjob INTEGER NOT NULL,
        upgrades TEXT NOT NULL,
        varient1 INTEGER NOT NULL,
        varient2 INTEGER NOT NULL,
        fuel INTEGER DEFAULT 100 NOT NULL, 
        health REAL DEFAULT 1000 NOT NULL, 
        headlightColor TEXT NOT NULL,
        vehiclestored INTEGER DEFAULT 0 NOT NULL,
        displayName TEXT,
        price INTEGER,
        brandname TEXT,
        numberPlate TEXT,
        haveNeon INTEGER DEFAULT 0 NOT NULL,
        neon TEXT,
        handling TEXT NOT NULL,
        trunk INTEGER NOT NULL,
        glovebox INTEGER NOT NULL,
        interior INTEGER DEFAULT 0 NOT NULL, 
        dimension INTEGER DEFAULT 0 NOT NULL,
        damage_states TEXT NOT NULL -- Store full vehicle damage states as JSON
    )
]]
dbExec(db, createTableQuery)

function PlayerVehicleBuy(player, command, model, price, brandname, displayName)
    if not isObjectInACLGroup("user." .. getAccountName(getPlayerAccount(player)), aclGetGroup("Admin")) then return end    
    if not model or not price or not brandname or not displayName then
        outputChatBox("Usage: /buyVehicle [model] [price] [brandname] [displayName]", player, 255, 0, 0, true)
        return
    end

    local x, y, z = getElementPosition(player)
    local rx, ry, rz = getElementRotation(player)
    y = y + 3
    local interior = getElementInterior(player)
    local dimension = getElementDimension(player)

    dbQuery(function(queryHandle)
        local account = getPlayerAccount(player)
        local AccountName = tostring(getAccountName(account))
        local numberPlate = brandname

        local vehicleObject = createVehicle(model, x, y, z, rx, ry, rz)

        if not vehicleObject then
            outputChatBox("Failed to create vehicle.", player, 255, 0, 0, true)
            return
        end

        warpPedIntoVehicle(player, vehicleObject)
        setElementInterior(vehicleObject, interior)
        setElementDimension(vehicleObject, dimension)
        setVehicleEngineState(vehicleObject, false)

        -- Get vehicle color
        local colors = {getVehicleColor(vehicleObject, true)}
        colors = {
            color1 = {r = colors[1], g = colors[2], b = colors[3]},
            color2 = {r = colors[4], g = colors[5], b = colors[6]},
            color3 = {r = colors[7], g = colors[8], b = colors[9]},
            color4 = {r = colors[10], g = colors[11], b = colors[12]},
        }

        -- Get paint job
        local paintJob = getVehiclePaintjob(vehicleObject)

        -- Vehicle upgrades
        local upgrades = getVehicleUpgrades(vehicleObject)

        -- Vehicle variant
        local varient1, varient2 = getVehicleVariant(vehicleObject)

        -- Vehicle handling
        local handling = getVehicleHandling(vehicleObject)

        -- Vehicle storage
        local storage = vehicleStorage[tonumber(model)] or defaultStorage
        local trunkCapacity = storage.trunk
        local gloveboxCapacity = storage.glovebox

        -- Get damage states (doors, panels)
        local damageStates = {
            doors = {},
            panels = {}
        }

        -- Get damaged doors (0-5)
        for i = 0, 5 do
            damageStates.doors[tostring(i)] = getVehicleDoorState(vehicleObject, i) or 0
        end

        -- Get damaged panels (0-6)
        for i = 0, 6 do
            damageStates.panels[tostring(i)] = getVehiclePanelState(vehicleObject, i) or 0
        end

        local insertQuery = [[
            INSERT INTO vehicles (model, x, y, z, rx, ry, rz, owner, color, paintjob, upgrades, varient1, varient2, headlightColor, numberPlate, displayName, price, brandname, handling, trunk, glovebox, interior, dimension, damage_states)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ]]
        dbExec(db, insertQuery, model, x, y, z, rx, ry, rz, AccountName, toJSON(colors), paintJob, toJSON(upgrades), varient1, varient2, toJSON({r = 255, g = 255, b = 255}), numberPlate, displayName, price, brandname, toJSON(handling), trunkCapacity, gloveboxCapacity, interior, dimension, toJSON(damageStates))

        -- Get latest vehicle ID
        local results = dbPoll(queryHandle, 0)
        local latestVehicleID = (results[1] and results[1].id or 0) + 1

        -- Set number plate
        local numberPlate = getElementData(player, "id") .. "KK-" .. (1000 + latestVehicleID)
        setVehiclePlateText(vehicleObject, numberPlate)

        -- Set element data
        setElementData(vehicleObject, 'id', latestVehicleID)
        setElementData(vehicleObject, "owner", AccountName)
        setElementData(vehicleObject, "numberPlate", numberPlate)
        setElementData(vehicleObject, "displayName", displayName)
        setElementData(vehicleObject, "price", price)
        setElementData(vehicleObject, "brandname", brandname)
        setElementData(vehicleObject, "trunk", trunkCapacity)
        setElementData(vehicleObject, "glovebox", gloveboxCapacity)
        setElementData(vehicleObject, "interior", interior)
        setElementData(vehicleObject, "dimension", dimension)
        setElementData(vehicleObject, "damageStates", damageStates)

        outputChatBox("VEHICLE UNIQUE ID: " .. latestVehicleID .. ".", player, 0, 152, 152, true)
        outputChatBox("Created Vehicle Successfully. You're inside the vehicle!", player, 0, 255, 0, true)
    end, db, 'SELECT id FROM vehicles ORDER BY id DESC LIMIT 1')
end

addCommandHandler('buyVehicle', PlayerVehicleBuy, false, false)
addCommandHandler('bv', PlayerVehicleBuy, false, false)



---------------------------------------------------------
-- Load vehicles on restart
---------------------------------------------------------

function loadAllVehicles(queryHandle)
    local results = dbPoll(queryHandle, 0)
    for _, vehicle in pairs(results) do
        if vehicle.vehiclestored == 0 then 
            local colors = fromJSON(vehicle.color)
            local paintJob = vehicle.paintjob
            local upgrades = fromJSON(vehicle.upgrades) 
            local headlightColor = fromJSON(vehicle.headlightColor)
            local handling = fromJSON(vehicle.handling)
            local damageStates = fromJSON(vehicle.damage_states) -- Retrieve damage states

            local vehicleObject = createVehicle(vehicle.model, vehicle.x, vehicle.y, vehicle.z, vehicle.rx, vehicle.ry, vehicle.rz, vehicle.numberPlate)

            local fuel = vehicle.fuel
            local health = vehicle.health
            local trunkCapacity = vehicle.trunk
            local gloveboxCapacity = vehicle.glovebox
            local interior = vehicle.interior
            local dimension = vehicle.dimension

            if not vehicleObject then
                return
            else
                if colors then
                    setVehicleColor(vehicleObject, colors.color1.r, colors.color1.g, colors.color1.b, colors.color2.r, colors.color2.g, colors.color2.b, colors.color3.r, colors.color3.g, colors.color3.b, colors.color4.r, colors.color4.g, colors.color4.b)
                end
                setVehicleLocked(vehicleObject, true)
                setVehicleEngineState(vehicleObject, false)
                setVehiclePaintjob(vehicleObject, paintJob)
                setVehicleVariant(vehicleObject, vehicle.varient1, vehicle.varient2)
                setElementData(vehicleObject, "fuel", fuel)
                setElementHealth(vehicleObject, health)
                setElementInterior(vehicleObject, interior)
                setElementDimension(vehicleObject, dimension)

                if headlightColor then 
                    setVehicleHeadLightColor(vehicleObject, headlightColor.r, headlightColor.g, headlightColor.b)
                end

                setVehicleHandling(vehicleObject, handling)

                if upgrades then
                    for _, upgradeID in ipairs(upgrades) do
                        addVehicleUpgrade(vehicleObject, upgradeID)
                    end
                end

                -- Apply stored damage states
                if damageStates then
                    -- Restore damaged doors (0-5)
                    if damageStates.doors then
                        for i = 0, 5 do
                            if damageStates.doors[tostring(i)] then
                                setVehicleDoorState(vehicleObject, i, damageStates.doors[tostring(i)])
                            end
                        end
                    end

                    -- Restore damaged panels (0-6)
                    if damageStates.panels then
                        for i = 0, 6 do
                            if damageStates.panels[tostring(i)] then
                                setVehiclePanelState(vehicleObject, i, damageStates.panels[tostring(i)])
                            end
                        end
                    end
                end
                
                -- Set vehicle data
                setElementData(vehicleObject, 'id', vehicle.id)
                setElementData(vehicleObject, "owner", vehicle.owner)
                setElementData(vehicleObject, "numberPlate", vehicle.numberPlate)
                setElementData(vehicleObject, "displayName", vehicle.displayName)
                setElementData(vehicleObject, "price", vehicle.price)
                setElementData(vehicleObject, "brandname", vehicle.brandname)
                setElementData(vehicleObject, "trunk", trunkCapacity)
                setElementData(vehicleObject, "glovebox", gloveboxCapacity)
                setElementData(vehicleObject, "interior", interior)
                setElementData(vehicleObject, "dimension", dimension)
                setElementData(vehicleObject, "damageStates", damageStates) -- Store damage states in element data
            end 
        end
    end
end

addEventHandler('onResourceStart', resourceRoot, function()
    dbQuery(loadAllVehicles, db, 'SELECT * FROM vehicles')
    outputServerLog("[VEHICLES] Vehicles Resource started successfully")
end)


---------------------------------------------------------
-- Update vehicle position to database
---------------------------------------------------------
-- Event for resource stop
addEventHandler('onResourceStop', resourceRoot, function()
    local vehicles = getElementsByType('vehicle')
    
    for _, vehicle in pairs(vehicles) do
        local id = getElementData(vehicle, 'id')
        if id then
            local x, y, z = getElementPosition(vehicle)
            local rx, ry, rz = getElementRotation(vehicle)
            
            -- Get the vehicle color
            local colors = {getVehicleColor(vehicle, true)}
            local vehicleColors = toJSON({
                color1 = {r = colors[1], g = colors[2], b = colors[3]},
                color2 = {r = colors[4], g = colors[5], b = colors[6]},
                color3 = {r = colors[7], g = colors[8], b = colors[9]},
                color4 = {r = colors[10], g = colors[11], b = colors[12]}
            })
            
            -- Get the vehicle fuel
            local currentFuel = getElementData(vehicle, "fuel")

            -- Get vehicle health
            local vehicleHealth = getElementHealth(vehicle)

            -- Vehicle headlight color
            local hr, hg, hb = getVehicleHeadLightColor(vehicle)
            local headlightColor = toJSON({ r = hr, g = hg, b = hb })

            -- Get the paint job and vehicle upgrades
            local paintJob = getVehiclePaintjob(vehicle)
            local upgrades = toJSON(getVehicleUpgrades(vehicle))

            -- Get vehicle handling
            local handling = toJSON(getVehicleHandling(vehicle))

            local numberPlate = getElementData(vehicle, "numberPlate")
            local owner = getElementData(vehicle, "owner")

            -- Vehicle storage data 
            local trunkCapacity = getElementData(vehicle, "trunk")
            local gloveboxCapacity = getElementData(vehicle, "glovebox")
            local interior = getElementData(vehicle, "interior")
            local dimension = getElementData(vehicle, "dimension")

            -- Get damaged doors, hood, trunk, and panels
            local damageStates = {
                doors = {},
                panels = {}
            }

            -- Check doors (0-5)
            for i = 0, 5 do
                damageStates.doors[tostring(i)] = getVehicleDoorState(vehicle, i)
            end

            -- Check panels (0-6)
            for i = 0, 6 do
                damageStates.panels[tostring(i)] = getVehiclePanelState(vehicle, i)
            end

            local damageJSON = toJSON(damageStates)

            -- Prepare the SQL query to update the vehicle's position, rotation, color, paint job, upgrades, handling, and damage states in the database
            local updateQuery = 'UPDATE vehicles SET x = ?, y = ?, z = ?, rx = ?, ry = ?, rz = ?, color = ?, paintjob = ?, fuel = ?, health = ?, headlightColor = ?, upgrades = ?, handling = ?, numberPlate = ?, owner = ?, trunk = ?, glovebox = ?, interior = ?, dimension = ?, damage_states = ? WHERE id = ?'
            
            -- Update the database with the current vehicle data
            dbExec(db, updateQuery, x, y, z, rx, ry, rz, vehicleColors, paintJob, currentFuel, vehicleHealth, headlightColor, upgrades, handling, numberPlate, owner, trunkCapacity, gloveboxCapacity, interior, dimension, damageJSON, id)
        end
    end
end)



---------------------------------------------------------

function VehicleSavetoDB(vehicle)
    local id = getElementData(vehicle, 'id')
    if id then
        local x, y, z = getElementPosition(vehicle)
        local rx, ry, rz = getElementRotation(vehicle)
        
        -- Get the vehicle color
        local colors = {getVehicleColor(vehicle, true)}
        local vehicleColors = toJSON({
            color1 = {r = colors[1], g = colors[2], b = colors[3]},
            color2 = {r = colors[4], g = colors[5], b = colors[6]},
            color3 = {r = colors[7], g = colors[8], b = colors[9]},
            color4 = {r = colors[10], g = colors[11], b = colors[12]}
        })
        
        -- Get the vehicle fuel
        local currentFuel = getElementData(vehicle, "fuel")

        -- Get vehicle health
        local vehicleHealth = getElementHealth(vehicle)

        -- Get vehicle owner
        local owner = getElementData(vehicle, "owner")

        -- Vehicle headlight color
        local hr, hg, hb = getVehicleHeadLightColor(vehicle)
        local headlightColor = toJSON({ r = hr, g = hg, b = hb })

        -- Get the paint job and vehicle upgrades
        local paintJob = getVehiclePaintjob(vehicle)
        local upgrades = toJSON(getVehicleUpgrades(vehicle))

        -- Get vehicle handling
        local handling = toJSON(getVehicleHandling(vehicle))

        -- Vehicle storage data 
        local trunkCapacity = getElementData(vehicle, "trunk")
        local gloveboxCapacity = getElementData(vehicle, "glovebox")
        local interior = getElementData(vehicle, "interior")
        local dimension = getElementData(vehicle, "dimension")

        -- Get damaged parts (doors, hood, trunk, and panels)
        local damagedParts = {
            doors = {},
            panels = {}
        }

        -- Check all doors (0-5: Hood, Trunk, and 4 car doors)
        for i = 0, 5 do
            damagedParts.doors[tostring(i)] = getVehicleDoorState(vehicle, i)
        end

        -- Check all panels (0-6)
        for i = 0, 6 do
            damagedParts.panels[tostring(i)] = getVehiclePanelState(vehicle, i)
        end

        local damagedPartsJSON = toJSON(damagedParts)

        -- Prepare the SQL query to update the vehicle's data including damaged parts
        local updateQuery = 'UPDATE vehicles SET x = ?, y = ?, z = ?, rx = ?, ry = ?, rz = ?, color = ?, paintjob = ?, fuel = ?, health = ?, headlightColor = ?, upgrades = ?, handling = ?, owner = ?, trunk = ?, glovebox = ?, interior = ?, dimension = ?, damage_states = ? WHERE id = ?'
        
        -- Update the database with the current vehicle data
        dbExec(db, updateQuery, x, y, z, rx, ry, rz, vehicleColors, paintJob, currentFuel, vehicleHealth, headlightColor, upgrades, handling, owner, trunkCapacity, gloveboxCapacity, interior, dimension, damagedPartsJSON, id)
    end
end 

addEventHandler('onPlayerVehicleExit', root, function(vehicle, seat)
    if vehicle then
        VehicleSavetoDB(vehicle)
    end
end)


---------------------------------------------------------
-- Delete a vehicle from the database
---------------------------------------------------------

function deleteVehicleFromDB(vehicle)
    local id = getElementData(vehicle, 'id')

    -- Delete the vehicle from the world
    destroyElement(vehicle)

    -- Delete the vehicle from the database
    dbExec(db, 'DELETE FROM vehicles WHERE id = ?', id)
    outputServerLog("[DELETED] Vehicle with ID: " .. tostring(id) .. " has been deleted from the database.")
end

function onDeleteVehicleCommand(player, command)
    if not isObjectInACLGroup("user." .. getAccountName(getPlayerAccount(player)), aclGetGroup("Admin")) then return end    
    local vehicle = getPedOccupiedVehicle(player)
    if vehicle and getElementType(vehicle) == "vehicle" then
        deleteVehicleFromDB(vehicle)
        outputChatBox("Vehicle deleted.", player, 0, 255, 0, true)
    else
        outputChatBox("You are not inside a vehicle.", player, 255, 0, 0, true)
    end
end

addCommandHandler('deleteVehicle', onDeleteVehicleCommand, false, false)

---------------------------------------------------------
-- Get the vehicle ID
---------------------------------------------------------

function GetVehicleID(player, command)
    if not isObjectInACLGroup("user." .. getAccountName(getPlayerAccount(player)), aclGetGroup("Admin")) then return end    
    local vehicle = getPedOccupiedVehicle(player)
    if vehicle and getElementType(vehicle) == 'vehicle' then
        local id = getElementData(vehicle, 'id')
        outputChatBox("VEHICLE UNIQUE ID :" .. tostring(id) .. ".", player, 152, 152, 152, true)
    else
        outputChatBox("You are not inside a vehicle.", player, 255, 0, 0, true)
    end 
end 

addCommandHandler('GetVehicleId', GetVehicleID, false, false)
addCommandHandler('vid', GetVehicleID, false, false)
