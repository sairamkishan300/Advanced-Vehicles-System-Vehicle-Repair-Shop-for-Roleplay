
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- CAR SHOP ADMIN PANEL
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
local db = dbConnect("sqlite", "vehicles.db")

function hasDealerPermission(player)
    local accName = getAccountName(getPlayerAccount(player)) -- get the player's account name
    return isObjectInACLGroup("user." .. accName, aclGetGroup(dealerPermissionGroup))
end

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- SET VEHICLE OWNER
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

-- Default new owner
local defaultNewOwner = "kkrp3000"

-- Function to get player account name from player ID
function getPlayerAccountNameFromID(playerID)
    for _, player in ipairs(getElementsByType("player")) do
        if getElementData(player, "id") == tonumber(playerID) then
            local account = getPlayerAccount(player)
            if account and not isGuestAccount(account) then
                return getAccountName(account)
            end
        end
    end
    return nil
end

-- Function to change the owner of the vehicle the player is sitting in
function changeVehicleOwner(player, newOwnerID)
    if not hasDealerPermission(player) then
        triggerClientEvent(player, "add:notification", player, "You do not have permission to use this command", "error",true)
        return
    end

    -- Get the new owner's account name from their ID
    local newOwner = defaultNewOwner -- Default to defaultNewOwner if no new owner ID provided
    if newOwnerID then
        newOwner = getPlayerAccountNameFromID(newOwnerID)
        if not newOwner then
            triggerClientEvent(player, "add:notification", player, "Invalid player ID or player not online", "error",true)
            return
        end
    end

    -- Get the vehicle the player is sitting in
    local vehicle = getPedOccupiedVehicle(player)
    if not vehicle then
        triggerClientEvent(player, "add:notification", player, "You are not in a vehicle", "error",true)
        return
    end

    -- Get the vehicle ID from the element data
    local vehicleID = getElementData(vehicle, "id")
    if not vehicleID then
        triggerClientEvent(player, "add:notification", player, "This vehicle does not have a valid ID", "error",true)
        return
    end

    setElementData(vehicle, "owner", newOwner)
    triggerClientEvent(player, "add:notification", player, "Vehicle owner updated successfully to " .. newOwner, "success",true)
end

-- Command to set the owner of the vehicle the player is sitting in using player ID
addCommandHandler("setowner", function(player, command, newOwnerID)
    changeVehicleOwner(player, newOwnerID)
end)

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- SELL VEHICLE BETWEEN PLAYERS
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

-- Helper to get occupants (excluding driver) with id and account
local function getVehicleOccupantsData(vehicle, driver)
	local occupants = {}
	for seat = 0, getVehicleMaxPassengers(vehicle) do
		local p = getVehicleOccupant(vehicle, seat)
		if p and p ~= driver then
			local acc = getPlayerAccount(p)
			if acc and not isGuestAccount(acc) then
				local accName = getAccountName(acc)
				local id = getElementData(p, "id") or 0
				local name = getPlayerName(p)
				table.insert(occupants, {
					id = id,
					name = name,
					accountName = accName,
					displayLabel = string.format("%s (ID: %s)", name, tostring(id))
				})
			end
		end
	end
	return occupants
end

addEvent("vehicle:sell:requestData", true)
addEventHandler("vehicle:sell:requestData", root, function()
	local player = source
	local vehicle = getPedOccupiedVehicle(player)
	if not vehicle then
		triggerClientEvent(player, "add:notification", player, "You are not in a vehicle", "error", true)
		return
	end

	-- Only the driver can sell
	if getVehicleController(vehicle) ~= player then
		triggerClientEvent(player, "add:notification", player, "Only the driver can sell this vehicle", "error", true)
		return
	end

	-- Only the owner can sell
	local ownerAccount = getElementData(vehicle, "owner")
	local acc = getPlayerAccount(player)
	if not acc or isGuestAccount(acc) then return end
	local playerAccountName = getAccountName(acc)
	if ownerAccount ~= playerAccountName then
		triggerClientEvent(player, "add:notification", player, "You are not the owner of this vehicle", "error", true)
		return
	end

	local occupants = getVehicleOccupantsData(vehicle, player)
	if #occupants == 0 then
		triggerClientEvent(player, "add:notification", player, "No other players in the vehicle to sell to", "error", true)
		return
	end

	triggerClientEvent(player, "vehicle:sell:openPanel", player, occupants)
end)

addEvent("vehicle:sell:perform", true)
addEventHandler("vehicle:sell:perform", root, function(buyerAccount, buyerId)
	local player = source
	local vehicle = getPedOccupiedVehicle(player)
	if not vehicle then
		triggerClientEvent(player, "add:notification", player, "You are not in a vehicle", "error", true)
		return
	end

	-- Only driver & owner can confirm sale
	if getVehicleController(vehicle) ~= player then
		triggerClientEvent(player, "add:notification", player, "Only the driver can sell this vehicle", "error", true)
		return
	end

	local ownerAccount = getElementData(vehicle, "owner")
	local acc = getPlayerAccount(player)
	if not acc or isGuestAccount(acc) then return end
	local playerAccountName = getAccountName(acc)
	if ownerAccount ~= playerAccountName then
		triggerClientEvent(player, "add:notification", player, "You are not the owner of this vehicle", "error", true)
		return
	end

	if not buyerAccount or buyerAccount == "" then
		triggerClientEvent(player, "add:notification", player, "Invalid buyer selected", "error", true)
		return
	end

	-- Validate buyer is still in the vehicle and matches account
	local buyerFound = nil
	for seat = 0, getVehicleMaxPassengers(vehicle) do
		local p = getVehicleOccupant(vehicle, seat)
		if p and p ~= player then
			local accP = getPlayerAccount(p)
			if accP and not isGuestAccount(accP) then
				local accNameP = getAccountName(accP)
				if accNameP == buyerAccount then
					buyerFound = p
					break
				end
			end
		end
	end

	if not buyerFound then
		triggerClientEvent(player, "add:notification", player, "Selected player is no longer in the vehicle", "error", true)
		return
	end

	local vehicleID = getElementData(vehicle, "id")
	if not vehicleID then
		triggerClientEvent(player, "add:notification", player, "This vehicle does not have a valid ID", "error", true)
		return
	end

	-- Update database owner
	dbExec(db, "UPDATE vehicles SET owner = ? WHERE id = ?", buyerAccount, vehicleID)
	setElementData(vehicle, "owner", buyerAccount)

	triggerClientEvent(player, "add:notification", player, "Vehicle sold to " .. tostring(buyerAccount), "success", true)
	triggerClientEvent(buyerFound, "add:notification", buyerFound, "You received ownership of this vehicle", "success", true)
end)


-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- CHECK PLAYER NAME AND ID
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

-- Function to get player account name from player element
function getPlayerAccountName(player)
    local account = getPlayerAccount(player)
    if account and not isGuestAccount(account) then
        return getAccountName(account)
    end
    return nil
end

-- Function to get player ID from player element
function getPlayerID(player)
    return getElementData(player, "id")
end

-- Command to check player's account name, ID, and name
addCommandHandler("checkmyid", function(player)
    local playerName = getPlayerName(player)
    local playerID = getPlayerID(player)
    local accountName = getPlayerAccountName(player)

    if playerName and playerID and accountName then
        outputChatBox("Your account name: " .. accountName, player, 0, 255, 0)
        outputChatBox("Your name: " .. playerName, player, 0, 255, 0)
        outputChatBox("Your ID: " .. playerID, player, 0, 255, 0)
    else
        outputChatBox("Failed to retrieve your account name, name, or ID.", player, 255, 0, 0)
    end
end)

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- DISPLAYED CAR CANCEL RIDE
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

-- Function to handle setting engine state and freezing based on vehicle owner
function checkVehicleOwnerAndStart(player, vehicle)
    local owner = getElementData(vehicle, "owner")
    if owner == "kkrp3000" then
        if not hasDealerPermission(player) then
            setVehicleEngineState(vehicle, false) -- Turn off the engine
            setElementFrozen(vehicle, true) -- Freeze the vehicle
            triggerClientEvent(player, "add:notification", player, "You cannot start this vehicle as it belongs to the Government", "error",true)
            setElementData(vehicle, "blockedEngine", true) -- Set flag to indicate blocked engine
        else
            triggerClientEvent(player, "add:notification", player, "You can ride this vehicle as you are an admin", "success",true)
            setElementFrozen(vehicle, false) -- Freeze the vehicle
            setElementData(vehicle, "blockedEngine", false) -- Set flag to indicate blocked engine
        end
    end
end

-- Event handler for onPlayerVehicleEnter
addEventHandler("onPlayerVehicleEnter", root, function(vehicle, seat)
    local player = source
    if seat == 0 then -- Only check for the driver
        if not getElementData(vehicle, "blockedEngine") then -- Check if engine is not blocked
            checkVehicleOwnerAndStart(player, vehicle)
        end
    end
end)

-- Event handler for onVehicleStartEnter
addEventHandler("onVehicleStartEnter", root, function(player, seat, jacked)
    if seat == 0 then -- Only check for the driver
        local vehicle = source
        if not hasDealerPermission(player) then
            if getElementData(vehicle, "blockedEngine") then -- Check if engine is blocked
                triggerClientEvent(player, "add:notification", player, "You cannot start this vehicle as its engine is blocked", "error",true)
            end
        end
    end
end)


-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- TEST DRIVE
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

local spawnLocation = { x = 1966, y = -2450, z = 15 } -- Coordinates of the airport
local countdownTime = 30
local originalX, originalY, originalZ, originalSkin
local playerVehicleMap = {} -- To keep track of player's vehicle and timer

function spawnCarAndTeleport(player)
    -- Get the vehicle model of the vehicle the player is currently occupying
    local currentVehicle = getPedOccupiedVehicle(player)
    if not currentVehicle then
        triggerClientEvent(player, "add:notification", player, "You need to be in a vehicle to start the test drive", "error",true)
        return
    end

    local vehicleModel = getElementModel(currentVehicle)

    -- Save the player's current location and skin
    originalX, originalY, originalZ = getElementPosition(player)
    originalZ = originalZ + 2
    originalSkin = getElementModel(player) or 0

    -- Create the vehicle
    local spawnedVehicle = createVehicle(vehicleModel, spawnLocation.x, spawnLocation.y, spawnLocation.z)
    
    -- Warp the player into the vehicle
    if spawnedVehicle then
        warpPedIntoVehicle(player, spawnedVehicle)
    end

    -- Trigger the client-side event to start the countdown
    triggerClientEvent(player, "startCountdown", resourceRoot, countdownTime)
    
    -- Store the timer and vehicle in the map
    playerVehicleMap[player] = { vehicle = spawnedVehicle }

    -- Set a timer to destroy the vehicle and teleport the player back
    playerVehicleMap[player].timer = setTimer(function()
        teleportBackAndDestroyVehicle(player, originalX, originalY, originalZ, originalSkin)
    end, countdownTime * 1000, 1)
end

function teleportBackAndDestroyVehicle(player, originalX, originalY, originalZ, originalSkin)
    if playerVehicleMap[player] then
        local vehicle = playerVehicleMap[player].vehicle
        if isElement(player) then
            spawnPlayer(player, originalX, originalY, originalZ, 0, originalSkin or getElementModel(player) or 0)
            triggerClientEvent(player, "stopCountdown", resourceRoot, countdownTime)
        end
        if isElement(vehicle) then
            destroyElement(vehicle)
        end
        if isTimer(playerVehicleMap[player].timer) then
            killTimer(playerVehicleMap[player].timer)
        end
        playerVehicleMap[player] = nil
    end
end

-- Event handler when player exits the vehicle
addEventHandler("onVehicleExit", root, function(player)
    if playerVehicleMap[player] and source == playerVehicleMap[player].vehicle then
        teleportBackAndDestroyVehicle(player, originalX, originalY, originalZ, originalSkin)
    end
end)

addEvent("spawnCarAndTeleport", true)
addEventHandler("spawnCarAndTeleport", root, function()
    spawnCarAndTeleport(source)
end)

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- BUY VEHICLE 
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
-- Function to find the nearest vehicle spawn location
function getNearestSpawnLocation(player)
    local px, py, pz = getElementPosition(player)
    local nearestLocation = nil
    local nearestDistance = math.huge
    
    for _, loc in ipairs(vehicleSpawnLocations) do
        local distance = getDistanceBetweenPoints3D(px, py, pz, loc.x, loc.y, loc.z)
        if distance < nearestDistance then
            nearestDistance = distance
            nearestLocation = loc
        end
    end
    
    return nearestLocation
end

-- Function to handle vehicle purchase
function handleVehiclePurchase(player, vehicleData)
    local model = vehicleData.model
    local brandname = vehicleData.brandname
    local displayName = vehicleData.displayName
    local price = vehicleData.price

    -- Money check
    local account = getPlayerAccount(player)
    local accountName = getAccountName(account)
    local playerMoney = exports.money:getMoney(account)

    if playerMoney < price then
        triggerClientEvent(player, "add:notification", player, "You don't have enough money !!!", "error", true)
        return 
    end

    local nearestLocation = getNearestSpawnLocation(player)
    if not nearestLocation then
        triggerClientEvent(player, "add:notification", player, "No spawn locations available", "error", true)
        return
    end

    local x, y, z = nearestLocation.x, nearestLocation.y, nearestLocation.z
    local rx, ry, rz = nearestLocation.rx, nearestLocation.ry, nearestLocation.rz

    -- Deduct money
    exports.money:takeMoney(account, price)
    --DESTROY PLAYER VEHICLE 
    if not destroyPedVehicle(player) then return end

    -- Query latest vehicle ID (for plate seed only) and then insert vehicle
    dbQuery(function(queryHandle)
        local results = dbPoll(queryHandle, 0)
        local latestVehicleID = (results and results[1] and results[1].id or 0) + 1

        -- Generate a unique number plate (used to fetch the correct DB row later)
        local numberPlate = getElementData(player, "id") .. "KK-" .. (1000 + latestVehicleID)

        -- Create vehicle
        local vehicleObject = createVehicle(model, x, y, z, rx, ry, rz)
        if not vehicleObject then
            triggerClientEvent(player, "add:notification", player, "Failed to create vehicle", "error", true)
            return
        end

        -- Get vehicle colors
        local colors = {getVehicleColor(vehicleObject, true)}
        colors = {
            color1 = {r = colors[1], g = colors[2], b = colors[3]},
            color2 = {r = colors[4], g = colors[5], b = colors[6]},
            color3 = {r = colors[7], g = colors[8], b = colors[9]},
            color4 = {r = colors[10], g = colors[11], b = colors[12]},
        }

        -- Vehicle properties
        local interior = getElementInterior(player)
        local dimension = getElementDimension(player)
        local paintJob = getVehiclePaintjob(vehicleObject)
        local upgrades = getVehicleUpgrades(vehicleObject)
        local varient1, varient2 = getVehicleVariant(vehicleObject)
        local handling = getVehicleHandling(vehicleObject)

        -- Storage capacities
        local storage = vehicleStorage[tonumber(model)] or defaultStorage
        local trunkCapacity = storage.trunk
        local gloveboxCapacity = storage.glovebox

        -- Default damage states for a brand new vehicle
        local damageStates = {
            doors = {},
            panels = {}
        }
        for i = 0, 5 do
            damageStates.doors[tostring(i)] = getVehicleDoorState(vehicleObject, i) or 0
        end
        for i = 0, 6 do
            damageStates.panels[tostring(i)] = getVehiclePanelState(vehicleObject, i) or 0
        end

        -- Insert into database (schema must match manager.lua)
        local insertQuery = [[
            INSERT INTO vehicles (model, x, y, z, rx, ry, rz, owner, color, paintjob, upgrades, varient1, varient2, headlightColor, numberPlate, displayName, price, brandname, handling, trunk, glovebox, interior, dimension, damage_states)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ]]
        dbExec(db, insertQuery, model, x, y, z, rx, ry, rz, accountName, toJSON(colors), paintJob, toJSON(upgrades), varient1, varient2, toJSON({r = 255, g = 255, b = 255}), numberPlate, displayName, price, brandname, toJSON(handling), trunkCapacity, gloveboxCapacity, interior, dimension, toJSON(damageStates))

        -- Set basic vehicle properties that do not depend on DB id
        setVehiclePlateText(vehicleObject, numberPlate)
        setElementData(vehicleObject, "owner", accountName)
        setElementData(vehicleObject, "numberPlate", numberPlate)
        setElementData(vehicleObject, "displayName", displayName)
        setElementData(vehicleObject, "price", price)
        setElementData(vehicleObject, "brandname", brandname)
        setElementData(vehicleObject, "trunk", trunkCapacity)
        setElementData(vehicleObject, "glovebox", gloveboxCapacity)
        setElementData(vehicleObject, "interior", interior)
        setElementData(vehicleObject, "dimension", dimension)

        -- Place player inside vehicle and set state immediately
        warpPedIntoVehicle(player, vehicleObject)
        setVehicleEngineState(vehicleObject, false)
        setElementInterior(vehicleObject, interior)
        setElementDimension(vehicleObject, dimension)

        -- Fetch the actual DB id using the unique numberPlate and update element data + notifications
        dbQuery(function(idHandle)
            local idResults = dbPoll(idHandle, 0)
            if idResults and idResults[1] and idResults[1].id then
                local realID = idResults[1].id
                setElementData(vehicleObject, 'id', realID)
                triggerClientEvent(player, "add:notification", player, "VEHICLE UNIQUE ID: " .. realID, "success", true)
                triggerClientEvent(player, "add:notification", player, "Created Vehicle Successfully. You're inside the vehicle!", "success", true)
            else
                -- Fallback notification if ID lookup fails for some reason
                triggerClientEvent(player, "add:notification", player, "Vehicle created but ID lookup failed", "warn", true)
            end
        end, db, 'SELECT id FROM vehicles WHERE numberPlate = ? ORDER BY id DESC LIMIT 1', numberPlate)
    end, db, 'SELECT id FROM vehicles ORDER BY id DESC LIMIT 1')
end

-- Event to handle vehicle purchase from client-side
addEvent("csBuyVehicle", true)
addEventHandler("csBuyVehicle", root, function(vehicleData)
    handleVehiclePurchase(source, vehicleData)
end)


function destroyPedVehicle(ped)
    if not isElement(ped) or not isPedInVehicle(ped) then return false end
    local vehicle = getPedOccupiedVehicle(ped)
    if isElement(vehicle) then
        deleteVehicleFromDB(vehicle)
        --destroyElement(vehicle)
        return true
    end
    return false
end


-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
