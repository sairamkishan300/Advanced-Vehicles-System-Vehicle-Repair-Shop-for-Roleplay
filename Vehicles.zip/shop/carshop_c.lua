shopPanel = {
    button = {},
    staticimage = {},
    label = {}
}

-- Function to create the GUI
function createShopPanel(vehicleData)
    if isElement(shopPanel.staticimage[1]) then
        destroyElement(shopPanel.staticimage[1])
        showCursor(false)
        guiSetInputMode('allow_binds')
        shopPanel.staticimage[1] = nil
        return
    end

    showCursor(true)
    local sw, sh = guiGetScreenSize()

    local vehicleName = vehicleData.displayName
    local vehiclePrice = "PRICE : " .. tostring(vehicleData.price)
    local brand = "BRAND : " .. vehicleData.brandname
    local vehicletype = "VEHICLE TYPE : " .. vehicleData.vehicleType
    local carImage = vehicleData.image


    -- MAIN PANEL
    shopPanel.staticimage[1] = guiCreateStaticImage(0.00009 * sw, 0.00014 * sh, 0.00031 * sw, 0.00057 * sh, ":Vehicles/[saiui]/panel.png", true)
    guiSetAlpha(shopPanel.staticimage[1], 0.85)

    -- TEST DRIVE BUTTON 
    shopPanel.button[1] = guiCreateButton(0.00033041 * sw, 0.0007365 * sh, 0.00012070 * sw, 0.00009888 * sh, "TEST DRIVE", true, shopPanel.staticimage[1])
    guiSetAlpha(shopPanel.button[1], 0.00)
    addEventHandler('onClientGUIClick', shopPanel.button[1], function()
        triggerServerEvent('spawnCarAndTeleport', localPlayer)
        destroyElement(shopPanel.staticimage[1])
        showCursor(false)
        guiSetInputMode('allow_binds')
        shopPanel.staticimage[1] = nil
    end, false)

    -- BUY BUTTON
    shopPanel.button[3] = guiCreateButton(0.00007741 * sw, 0.0007365 * sh, 0.00012070 * sw, 0.00009888 * sh, "BUY", true, shopPanel.staticimage[1])
    guiSetAlpha(shopPanel.button[3], 0.00)
    addEventHandler('onClientGUIClick', shopPanel.button[3], function()
        -- Trigger server-side event to buy the vehicle
        triggerServerEvent("csBuyVehicle", localPlayer, vehicleData)
    
        -- Close the shop panel
        destroyElement(shopPanel.staticimage[1])
        showCursor(false)
        guiSetInputMode('allow_binds')
        shopPanel.staticimage[1] = nil
    end, false)

    -- CAR IMAGE    
    shopPanel.staticimage[3] = guiCreateStaticImage(0.00003504 * sw, 0.0002592 * sh, 0.00020833 * sw, 0.00037962 * sh, carImage, true, shopPanel.staticimage[1])

    -- CLOSE BUTTON     
    shopPanel.button[2] = guiCreateButton(0.00001041 * sw, 0.0000277 * sh, 0.0000395 * sw, 0.000037037 * sh, "", true, shopPanel.staticimage[1])
    guiSetAlpha(shopPanel.button[2], 0.00)
    addEventHandler('onClientGUIClick', shopPanel.button[2], function()
        destroyElement(shopPanel.staticimage[1])
        showCursor(false)
        guiSetInputMode('allow_binds')
        shopPanel.staticimage[1] = nil
        return
    end, false)

    -- NAME TAG
    shopPanel.label[2] = guiCreateLabel(0.0002552 * sw, 0.00003703 * sh, 0.00026041 * sw, 0.00010185 * sh, vehicleName, true, shopPanel.staticimage[1])
    local titleFont = guiCreateFont("[saiui]/saifont.otf", 50)
    guiSetFont(shopPanel.label[2], titleFont)
    guiLabelSetHorizontalAlign(shopPanel.label[2], "center", false)
    guiLabelSetVerticalAlign(shopPanel.label[2], "center")

    -- COMMON FONT
    local normFont = guiCreateFont("[saiui]/saifont.otf", 15)

    -- PRICE TAG
    shopPanel.label[3] = guiCreateLabel(0.00031 * sw, 0.0001762 * sh, 0.000156 * sw, 0.000120370 * sh, vehiclePrice, true, shopPanel.staticimage[1])
    guiSetFont(shopPanel.label[3], normFont)
    guiLabelSetHorizontalAlign(shopPanel.label[3], "center", false)
    guiLabelSetVerticalAlign(shopPanel.label[3], "center")

    -- SPEED TAG
    shopPanel.label[4] = guiCreateLabel(0.00031 * sw, 0.0003452 * sh, 0.000156 * sw, 0.000120370 * sh, brand, true, shopPanel.staticimage[1])
    guiSetFont(shopPanel.label[4], normFont)
    guiLabelSetHorizontalAlign(shopPanel.label[4], "center", false)
    guiLabelSetVerticalAlign(shopPanel.label[4], "center")

    -- NUMBER OF SEATS
    shopPanel.label[5] = guiCreateLabel(0.00031 * sw, 0.0005262 * sh, 0.000156 * sw, 0.000120370 * sh, vehicletype, true, shopPanel.staticimage[1])
    guiSetFont(shopPanel.label[5], normFont)
    guiLabelSetHorizontalAlign(shopPanel.label[5], "center", false)
    guiLabelSetVerticalAlign(shopPanel.label[5], "center")
end

-- Event handler for entering a vehicle
function onVehicleEnter(player, seat)
    if player == localPlayer and seat == 0 then -- Check if the local player is entering as the driver
        local vehicle = source
        local owner = getElementData(vehicle, "owner")
        if owner == "kkrp3000" then
            local vehicleModel = getElementModel(vehicle)
            for _, vehicle in ipairs(CarShopData) do
                if vehicle.model == tonumber(vehicleModel) then
                    createShopPanel(vehicle)
                end
            end
        end
    end
end

-- Add event handlers
addEventHandler("onClientVehicleEnter", root, onVehicleEnter)



-------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------
-- COUNT DOWNN FOR TEST DRIVE
-------------------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------------------
local countdown = 0
local timer = nil

function startCountdown(duration)
    countdown = duration
    if timer then
        killTimer(timer)
    end
    timer = setTimer(updateCountdown, 1000, duration)
    addEventHandler("onClientRender", root, renderCountdown)
end
addEvent("startCountdown", true)
addEventHandler("startCountdown", resourceRoot, startCountdown)

function updateCountdown()
    countdown = countdown - 1
    if countdown <= 0 then
        removeEventHandler("onClientRender", root, renderCountdown)
        killTimer(timer)
    end
end

function renderCountdown()
    local screenWidth, screenHeight = guiGetScreenSize()
    dxDrawText("Time left: " .. countdown .. " seconds", screenWidth - 200, 50, screenWidth - 20, 70, tocolor(255, 255, 255, 255), 1.5, "default-bold")
end

function triggerSpawnCarEvent()
    triggerServerEvent("spawnCarAndTeleport", resourceRoot)
end
addCommandHandler("spawncar", triggerSpawnCarEvent)




function stopCountdown(duration)
    if timer then
        killTimer(timer)
    end
    removeEventHandler("onClientRender", root, renderCountdown)
end
addEvent("stopCountdown", true)
addEventHandler("stopCountdown", resourceRoot, stopCountdown)