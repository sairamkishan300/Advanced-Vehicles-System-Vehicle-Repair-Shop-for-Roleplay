(function () {
    let buyers = [];
    let selectedIndex = -1;

    function renderBuyers() {
        const list = document.getElementById('buyerList');
        const emptyMsg = document.getElementById('emptyMsg');
        const confirmBtn = document.getElementById('confirmBtn');

        list.innerHTML = '';

        if (!buyers || buyers.length === 0) {
            emptyMsg.style.display = 'block';
            confirmBtn.disabled = true;
            return;
        }

        emptyMsg.style.display = 'none';

        buyers.forEach((b, idx) => {
            const li = document.createElement('li');
            li.className = 'buyer-item' + (idx === selectedIndex ? ' selected' : '');

            const nameSpan = document.createElement('span');
            nameSpan.className = 'name';
            nameSpan.textContent = b.displayLabel || b.name || 'Unknown';

            const metaSpan = document.createElement('span');
            metaSpan.className = 'meta';
            metaSpan.textContent = `ID: ${b.id ?? '-'}  |  Account: ${b.accountName ?? '-'}`;

            li.appendChild(nameSpan);
            li.appendChild(metaSpan);

            li.addEventListener('click', () => {
                selectedIndex = idx;
                renderBuyers();
            });

            list.appendChild(li);
        });

        confirmBtn.disabled = selectedIndex < 0;
    }

    window.setSellData = function (payload) {
        try {
            if (typeof payload === 'string') {
                buyers = JSON.parse(payload);
            } else if (Array.isArray(payload)) {
                buyers = payload;
            } else {
                buyers = [];
            }
        } catch (e) {
            buyers = [];
        }
        selectedIndex = -1;
        renderBuyers();
    };

    function send(action, extra) {
        if (typeof mta !== 'undefined' && typeof mta.triggerEvent === 'function') {
            mta.triggerEvent('sellPanelAction', JSON.stringify({ action, ...extra }));
        }
    }

    window.addEventListener('DOMContentLoaded', () => {
        const closeBtn = document.getElementById('closeBtn');
        const confirmBtn = document.getElementById('confirmBtn');

        closeBtn.addEventListener('click', () => {
            send('close', {});
        });

        confirmBtn.addEventListener('click', () => {
            if (selectedIndex < 0 || !buyers[selectedIndex]) return;
            const target = buyers[selectedIndex];
            send('confirm', { buyerAccount: target.accountName, buyerId: target.id });
        });
    });
})();
