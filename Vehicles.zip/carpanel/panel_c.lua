local GUIEditor = {
    button = {},
    staticimage = {}
}

-- Sell vehicle HTML panel
local sellBrowser = nil
local sellBrowserShowing = false

function CarPanelOpen()

    local vehicle = getPedOccupiedVehicle(localPlayer)
    local driver = getVehicleController(vehicle)

--check if panel already opened
    if vehicle then
        if isElement(GUIEditor.staticimage[1]) then
            destroyElement(GUIEditor.staticimage[1])
            showCursor(false)
            GUIEditor.staticimage[1] = nil
            if isElement(KeyPanel) then 
                destroyElement(KeyPanel)
            end
            return
        end
--CREATE THE PANEL
        local screenW, screenH = guiGetScreenSize()

        GUIEditor.staticimage[1] = guiCreateStaticImage(screenW*0.000209, screenH*0.000550, screenW * 0.00010 ,screenH* 0.00019, ":Vehicles/[images]/carpanel.png", true)
        showCursor(true)
    ------------------------------------------------------
    --ENGINE BUTTON
    ------------------------------------------------------

        GUIEditor.button[1] = guiCreateButton(0.08, 0.12,0.12, 0.23, "engine", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[1], 0)

        addEventHandler('onClientGUIClick', GUIEditor.button[1], function()
            if driver ~= localPlayer then 
                return
             end
            local engineState = getVehicleEngineState(vehicle) -- Get the current engine state
            local fuel = getElementData(vehicle, "fuel")
            local health = getElementHealth(vehicle)
            if fuel >= 2 and health >= 330 then 
                if engineState then
                    setVehicleEngineState(vehicle, false) -- Turn off the engine
                    setVehicleOverrideLights ( vehicle, 1 )
                    triggerEvent("add:notification", localPlayer, "Vehicle engine off", "success", true)
                else
                    setVehicleEngineState(vehicle, true) -- Turn on the engine
                    setVehicleOverrideLights ( vehicle, 2 )
    
                    triggerEvent("add:notification", localPlayer, "Vehicle engine on", "success", true)
                    updateFuel(vehicle)
                end
            else
                triggerEvent("add:notification", localPlayer, "Vehicle can't be start", "error", true)
            end
        end, false)
        ------------------------------------------------------
        --HOOD
        ------------------------------------------------------
        
        GUIEditor.button[2] = guiCreateButton(0.36, 0.12,0.12, 0.23, "hood", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[2], 0)

        addEventHandler('onClientGUIClick', GUIEditor.button[2], function()
            if driver ~= localPlayer then 
                return
             end
            local doorstate = getVehicleDoorOpenRatio(vehicle, 0)
            if doorstate < 1 then
                setVehicleDoorOpenRatio (vehicle, 0, 1)
            else
                setVehicleDoorOpenRatio(vehicle, 0, 0)
            end
        end, false)

        ------------------------------------------------------
        --TRUNK
        ------------------------------------------------------

        GUIEditor.button[3] = guiCreateButton(0.51, 0.12,0.12, 0.23, "TRUNK", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[3], 0)

        addEventHandler('onClientGUIClick', GUIEditor.button[3], function()
            if driver ~= localPlayer then 
                return
             end
            local doorstate = getVehicleDoorOpenRatio(vehicle, 1)
            if doorstate < 1 then
                setVehicleDoorOpenRatio (vehicle, 1, 1)
            else
                setVehicleDoorOpenRatio(vehicle, 1, 0)
            end
        end, false)

        ------------------------------------------------------
        --KEY PANEL (SELL VEHICLE)
        ------------------------------------------------------
        GUIEditor.button[4] = guiCreateButton(0.66, 0.12,0.12, 0.23, "smallhood", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[4], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[4], function()
            if driver ~= localPlayer then 
                return
            end

            -- Request server to open sell panel with current vehicle occupants
            triggerServerEvent("vehicle:sell:requestData", localPlayer)
        end, false)

        ------------------------------------------------------
        --head light
        ------------------------------------------------------
        GUIEditor.button[5] = guiCreateButton(0.80, 0.12,0.12, 0.23, "hLight", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[5], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[5], function()
            if driver ~= localPlayer then 
                return
             end
            if ( getVehicleOverrideLights ( vehicle ) ~= 2 ) then  
                setVehicleOverrideLights ( vehicle, 2 )   
            else
                setVehicleOverrideLights ( vehicle, 1 )   
            end
        end, false)
        ------------------------------------------------------
        --close window1
        ------------------------------------------------------
        GUIEditor.button[6] = guiCreateButton(0.07, 0.37,0.12, 0.23, "door1C", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[6], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[6], function()
            if driver ~= localPlayer then 
                return
             end
            setVehicleWindowOpen( vehicle, 4 , not isVehicleWindowOpen( vehicle, 4) )
        end, false)
        ------------------------------------------------------
        --open door 1
        ------------------------------------------------------
        GUIEditor.button[7] = guiCreateButton(0.22, 0.37,0.12, 0.23, "door1", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[7], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[7], function()
            if driver ~= localPlayer then 
                return
             end
            local doorstate = getVehicleDoorOpenRatio(vehicle, 2)
            if doorstate < 1 then
                setVehicleDoorOpenRatio (vehicle, 2, 1)
            else
                setVehicleDoorOpenRatio (vehicle, 2, 0)
            end
        end, false)
        ------------------------------------------------------
        --seat 1
        ------------------------------------------------------
        GUIEditor.button[8] = guiCreateButton(0.36, 0.37,0.12, 0.23, "seat1", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[8], 0)

        addEventHandler('onClientGUIClick', GUIEditor.button[8], function()
            local occupant = getVehicleOccupant(vehicle, 0)
            if occupant then
                notificationBar("Seat is occupied", "")
            else
                triggerServerEvent('changeSeat', localPlayer, 0)
            end
        end, false)
        ------------------------------------------------------
        --seat 2
        ------------------------------------------------------
        GUIEditor.button[9] = guiCreateButton(0.51, 0.37,0.12, 0.23, "seat2", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[9], 0)

        addEventHandler('onClientGUIClick', GUIEditor.button[9], function()
            local occupant = getVehicleOccupant(vehicle, 1)
            if occupant then
                notificationBar("Seat is occupied", "")
            else
                triggerServerEvent('changeSeat', localPlayer, 1)
            end
        end, false)
        ------------------------------------------------------
        --open door 2
        ------------------------------------------------------
        GUIEditor.button[10] = guiCreateButton(0.66, 0.37,0.12, 0.23, "door2", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[10], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[10], function()
            local doorstate = getVehicleDoorOpenRatio(vehicle, 3)
            if doorstate < 1 then
                setVehicleDoorOpenRatio (vehicle, 3, 1)
            else
                setVehicleDoorOpenRatio (vehicle, 3, 0)
            end
        end, false)
        ------------------------------------------------------
        --close window 2
        ------------------------------------------------------
        GUIEditor.button[11] = guiCreateButton(0.80, 0.37,0.12, 0.23, "door2C", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[11], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[11], function()
            setVehicleWindowOpen( vehicle, 2 , not isVehicleWindowOpen( vehicle, 2) )
        end, false)
        ------------------------------------------------------
        --close window 3
        ------------------------------------------------------
        GUIEditor.button[12] = guiCreateButton(0.07, 0.64,0.12, 0.23, "door3C", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[12], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[12], function()
            setVehicleWindowOpen( vehicle, 5 , not isVehicleWindowOpen( vehicle, 5) )
        end, false)
        ------------------------------------------------------
        --open door 3
        ------------------------------------------------------       
        GUIEditor.button[13] = guiCreateButton(0.22, 0.64,0.12, 0.23, "door3", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[13], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[13], function()
            local doorstate = getVehicleDoorOpenRatio(vehicle, 4)
            if doorstate < 1 then
                setVehicleDoorOpenRatio (vehicle, 4, 1)
            else
                setVehicleDoorOpenRatio (vehicle, 4, 0)
            end
        end, false)
        ------------------------------------------------------
        --seat 3
        ------------------------------------------------------  
        GUIEditor.button[14] = guiCreateButton(0.36, 0.64,0.12, 0.23, "seat3", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[14], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[14], function()
            local occupant = getVehicleOccupant(vehicle, 2)
            if occupant then
                notificationBar("Seat is occupied", "")
            else
                triggerServerEvent('changeSeat', localPlayer, 2)
            end
        end, false)
        ------------------------------------------------------
        --seat 4
        ------------------------------------------------------  
        GUIEditor.button[15] = guiCreateButton(0.51, 0.64,0.12, 0.23, "seat4", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[15], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[15], function()
            local occupant = getVehicleOccupant(vehicle, 3)
            if occupant then
                notificationBar("Seat is occupied", "")
            else
                triggerServerEvent('changeSeat', localPlayer, 3)
            end
        end, false)
        ------------------------------------------------------
        --open door 4
        ------------------------------------------------------  
        GUIEditor.button[16] = guiCreateButton(0.66, 0.64,0.12, 0.23, "door4", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[16], 0)
        addEventHandler('onClientGUIClick', GUIEditor.button[16], function()
            local doorstate = getVehicleDoorOpenRatio(vehicle, 5)
            if doorstate < 1 then
                setVehicleDoorOpenRatio (vehicle, 5, 1)
            else
                setVehicleDoorOpenRatio (vehicle, 5, 0)
            end
        end, false)
        ------------------------------------------------------
        --close window 4
        ------------------------------------------------------  
        GUIEditor.button[17] = guiCreateButton(0.80, 0.64,0.12, 0.23, "door4C", true, GUIEditor.staticimage[1])
        guiSetAlpha(GUIEditor.button[17], 0)  
        addEventHandler('onClientGUIClick', GUIEditor.button[17], function()
            setVehicleWindowOpen( vehicle, 3 , not isVehicleWindowOpen( vehicle, 3) )
        end, false)
        ------------------------------------------------------
        ------------------------------------------------------  
        addEventHandler('onClientGUIClick', GUIEditor.staticimage[1], function()
            -- Do nothing 
            return
        end, false)
    end
end

function playerPressedKey(button, press)
    if isChatBoxInputActive() then
        return 
    end
    if press then
        if button == "z" then
            CarPanelOpen()
        end
    end
end
addEventHandler("onClientKey", root, playerPressedKey)

-- Sell vehicle HTML integration
local function showSellHTML(data)
    if sellBrowserShowing then return end
    local screenW, screenH = guiGetScreenSize()
    sellBrowser = guiCreateBrowser(0, 0, screenW, screenH, true, true, false)
    local theBrowser = guiGetBrowser(sellBrowser)

    addEventHandler("onClientBrowserCreated", theBrowser, function()
        loadBrowserURL(theBrowser, "http://mta/local/carpanel/html/sell.html")
    end, false)

    addEventHandler("onClientBrowserDocumentReady", theBrowser, function()
        local jsArray = "["
        if type(data) == "table" then
            for i, v in ipairs(data) do
                if i > 1 then jsArray = jsArray .. "," end
                jsArray = jsArray .. string.format("{\"id\":%s,\"name\":\"%s\",\"accountName\":\"%s\",\"displayLabel\":\"%s\"}",
                    tostring(v.id or 0),
                    tostring(v.name or ""),
                    tostring(v.accountName or ""),
                    tostring(v.displayLabel or (v.name or ""))
                )
            end
        end
        jsArray = jsArray .. "]"
        executeBrowserJavascript(theBrowser, "window.setSellData(" .. jsArray .. ");")
    end, false)

    showCursor(true)
    guiSetInputMode("no_binds")
    sellBrowserShowing = true
end

local function hideSellHTML()
    if sellBrowser and isElement(sellBrowser) then
        destroyElement(sellBrowser)
        sellBrowser = nil
        sellBrowserShowing = false
        showCursor(false)
        guiSetInputMode("allow_binds")
    end
end

addEvent("vehicle:sell:openPanel", true)
addEventHandler("vehicle:sell:openPanel", root, function(data)
    showSellHTML(data)
end)

addEvent("sellPanelAction", true)
addEventHandler("sellPanelAction", root, function(payload)
    local decoded = {}
    if type(payload) == "string" then
        local ok, result = pcall(fromJSON, payload)
        if ok and type(result) == "table" then
            decoded = result
        end
    elseif type(payload) == "table" then
        decoded = payload
    end

    local action = decoded.action
    if action == "close" then
        hideSellHTML()
    elseif action == "confirm" then
        local buyerAccount = decoded.buyerAccount
        local buyerId = decoded.buyerId
        if buyerAccount and buyerId then
            triggerServerEvent("vehicle:sell:perform", localPlayer, tostring(buyerAccount), tonumber(buyerId))
        end
        hideSellHTML()
    end
end)