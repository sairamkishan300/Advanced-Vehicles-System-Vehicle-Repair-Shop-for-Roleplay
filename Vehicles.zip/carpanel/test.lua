-- Database connection (SQLite)
local db = dbConnect("sqlite", "inventory.db")

if not db then
    outputDebugString("Failed to connect to the database.")
    return
end

-- Create the inventory table if it doesn't exist
dbExec(db, [[
    CREATE TABLE IF NOT EXISTS inventory (
        player_id INTEGER NOT NULL,
        account_name TEXT NOT NULL,
        slot INTEGER NOT NULL,
        item_name TEXT NOT NULL,
        amount INTEGER NOT NULL,
        weight INTEGER NOT NULL,
        x INTEGER NOT NULL,
        y INTEGER NOT NULL
    )
]])

-- Create the inventory table if it doesn't exist
dbExec(db, [[
    CREATE TABLE IF NOT EXISTS altInventory (
        invID INTEGER NOT NULL,
        invTYPE TEXT NOT NULL,
        slot INTEGER NOT NULL,
        item_name TEXT NOT NULL,
        amount INTEGER NOT NULL,
        weight INTEGER NOT NULL,
        x INTEGER NOT NULL,
        y INTEGER NOT NULL
    )
]])

-- Function to load inventory from the database
function loadAltInventory(player)
    local account = getPlayerAccount(player)
    if isGuestAccount(account) then return end

-- CHECK AND OPEN VEHICLE TRUNK
    local player = source
    local x, y, z = getElementPosition(player) -- Get player's position
    local vehicles = getElementsByType("vehicle") -- Get all vehicle elements
    local nearestDist = 4 -- Set initial distance to a very high value
    local nearestVehicle = nil -- Variable to store the nearest vehicle
    
    for _, vehicle in ipairs(vehicles) do
        local vx, vy, vz = getElementPosition(vehicle) -- Get vehicle's position
        local distance = getDistanceBetweenPoints3D(x, y, z, vx, vy, vz) -- Calculate distance
        
        if distance < nearestDist then
            nearestDist = distance -- Update nearest distance
            nearestVehicle = vehicle -- Set nearest vehicle
        end
    end

    if nearestVehicle then
        local invID = getElementData(nearestVehicle, "id")
        if invID then
            if isVehicleLocked(nearestVehicle) then
                return
            else
                local result = dbPoll(dbQuery(db, "SELECT * FROM altInventory WHERE invID = ?", invID), -1)
                if result then
                    triggerClientEvent(player, "onAltInventoryLoad", player, result)
                end
            end
        else
            return
        end
    end
-- CHECK AND OPEN VEHICLE GLOWBOX

    local vehicle = getPedOccupiedVehicle(player)
    if vehicle then
        local invID = getElementData(vehicle, "id")
        if invID then
            local result = dbPoll(dbQuery(db, "SELECT * FROM altInventory WHERE invID = ?", invID), -1)
            if result then
                triggerClientEvent(player, "onAltInventoryLoad", player, result)
            end
        else
            return
        end
    end

end

-- Event handlers
addEvent("onInventoryOpen", true)
addEventHandler("onInventoryOpen", root, function()
    local player = client
    loadInventory(player)
end)

addEvent("onInventoryClose", true)
addEventHandler("onInventoryClose", root, function(clientBoxes)

    local player = client

    local account = getPlayerAccount(player)
    if isGuestAccount(account) then return end
    local accountName = getAccountName(account)
    local playerID = getElementData(player, "id")

    dbExec(db, "DELETE FROM inventory WHERE player_id = ?", playerID)

    for i, box in ipairs(clientBoxes) do
        dbExec(db, "INSERT INTO inventory (player_id, account_name, slot, item_name, amount, weight, x, y) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            playerID, accountName, i, box.name, box.amount, box.weight, box.x, box.y)
    end
end)

