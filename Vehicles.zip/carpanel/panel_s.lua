addEvent('changeSeat', true)
addEventHandler('changeSeat', root, function(seat)
    client = source
    local vehicle = getPedOccupiedVehicle(client)
    warpPedIntoVehicle(client, vehicle, seat)
end)