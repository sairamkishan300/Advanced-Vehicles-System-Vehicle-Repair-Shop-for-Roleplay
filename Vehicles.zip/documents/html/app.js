function parseVehiclesString(dataString) {
    if (!dataString) return [];
    return dataString.split(';;').filter(Boolean).map(function (entry) {
        var parts = entry.split('||');
        return {
            id: parts[0] || '',
            numberPlate: parts[1] || '',
            brandname: parts[2] || '',
            displayName: parts[3] || '',
            owner: parts[4] || '',
            insurance: parts[5] || 'Not Insured',
            raw: entry
        };
    });
}

function createCard(vehicle) {
    var card = document.createElement('div');
    card.className = 'card';

    var header = document.createElement('div');
    header.className = 'card-header';

    var title = document.createElement('div');
    title.className = 'card-title';
    title.textContent = vehicle.displayName || 'Vehicle #' + (vehicle.id || '?');

    var badge = document.createElement('div');
    badge.className = 'badge';
    badge.textContent = vehicle.insurance;

    header.appendChild(title);
    header.appendChild(badge);

    var body = document.createElement('div');
    body.className = 'card-body';

    function addRow(label, value) {
        var row = document.createElement('div');
        row.className = 'info-row';
        var l = document.createElement('span');
        l.className = 'info-label';
        l.textContent = label;
        var v = document.createElement('span');
        v.className = 'info-value';
        v.textContent = value;
        row.appendChild(l);
        row.appendChild(v);
        body.appendChild(row);
    }

    addRow('ID', vehicle.id);
    addRow('Number Plate', vehicle.numberPlate);
    addRow('Brand', vehicle.brandname);
    addRow('Owner', vehicle.owner);

    var footer = document.createElement('div');
    footer.className = 'card-footer';

    var btn = document.createElement('button');
    btn.className = 'button-share';
    btn.textContent = 'Share to nearby';
    btn.addEventListener('click', function () {
        if (window.mta && typeof window.mta.triggerEvent === 'function') {
            window.mta.triggerEvent('documents:shareVehicleFromUI', vehicle.raw);
        }
    });

    footer.appendChild(btn);

    card.appendChild(header);
    card.appendChild(body);
    card.appendChild(footer);

    return card;
}

window.receiveVehiclesData = function (dataString) {
    var container = document.getElementById('vehicles-container');
    container.innerHTML = '';
    var vehicles = parseVehiclesString(dataString);
    if (!vehicles.length) {
        var msg = document.createElement('div');
        msg.style.color = '#9ca3af';
        msg.style.fontSize = '13px';
        msg.textContent = 'No vehicles found for this account.';
        container.appendChild(msg);
        return;
    }
    vehicles.forEach(function (v) {
        container.appendChild(createCard(v));
    });
};

window.showSharedVehicle = function (vehicleString, fromPlayerName) {
    var vArr = parseVehiclesString(vehicleString);
    var v = vArr[0];
    if (!v) return;

    var sharedView = document.getElementById('shared-view');
    var fromEl = document.getElementById('shared-from');
    var cardHost = document.getElementById('shared-card');

    fromEl.textContent = fromPlayerName || 'Unknown';
    cardHost.innerHTML = '';
    cardHost.appendChild(createCard(v));
    sharedView.classList.remove('hidden');
};

// Called by close button in the header
window.closeDocumentsPanel = function () {
    if (window.mta && typeof window.mta.triggerEvent === 'function') {
        window.mta.triggerEvent('documents:closePanel');
    }
};
