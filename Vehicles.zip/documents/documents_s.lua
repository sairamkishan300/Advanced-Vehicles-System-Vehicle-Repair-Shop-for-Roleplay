local db = dbConnect("sqlite", "vehicles.db")

local function getPlayerAccountName(player)
    local acc = getPlayerAccount(player)
    if acc and not isGuestAccount(acc) then
        return getAccountName(acc)
    end
    return nil
end

local function buildVehicleString(row)
    -- Fields: id|numberPlate|brandname|displayName|owner|insuranceStatus
    local id = tostring(row.id or "")
    local plate = tostring(row.numberPlate or "")
    local brand = tostring(row.brandname or "")
    local name = tostring(row.displayName or "")
    local owner = tostring(row.owner or "")
    local insurance = "Insured"
    return table.concat({id, plate, brand, name, owner, insurance}, "||")
end

addEvent("documents:requestVehicles", true)
addEventHandler("documents:requestVehicles", root, function()
    local player = client or source
    local accName = getPlayerAccountName(player)
    if not accName then return end

    dbQuery(function(qh)
        local results = dbPoll(qh, 0) or {}
        -- If no vehicles owned, just notify and do not open the panel
        if #results == 0 then
            triggerClientEvent(player, "add:notification", player, "You don't own any vehicles", "error", true)
            -- Ensure any pending panel is closed/hidden on client
            triggerClientEvent(player, "documents:closePanel", player)
            return
        end

        local parts = {}
        for _, row in ipairs(results) do
            table.insert(parts, buildVehicleString(row))
        end
        local dataString = table.concat(parts, ";;")
        triggerClientEvent(player, "documents:openPanel", player, dataString)
    end, db, "SELECT id, numberPlate, brandname, displayName, owner FROM vehicles WHERE owner = ?", accName)
end)

local function findNearestPlayer(player, maxDist)
    local px, py, pz = getElementPosition(player)
    local nearest, bestDist
    for _, p in ipairs(getElementsByType("player")) do
        if p ~= player then
            local x, y, z = getElementPosition(p)
            local dist = getDistanceBetweenPoints3D(px, py, pz, x, y, z)
            if dist <= maxDist and (not bestDist or dist < bestDist) then
                bestDist = dist
                nearest = p
            end
        end
    end
    return nearest, bestDist
end

addEvent("documents:shareVehicle", true)
addEventHandler("documents:shareVehicle", root, function(vehicleString)
    local player = client or source
    if type(vehicleString) ~= "string" or vehicleString == "" then return end

    local target, dist = findNearestPlayer(player, 5)
    if not target then
        triggerClientEvent(player, "add:notification", player, "No nearby player to show document", "error", true)
        return
    end

    -- Forward the raw string to the nearby player; their UI can render it
    triggerClientEvent(target, "documents:showSharedVehicle", target, vehicleString, getPlayerName(player))
    triggerClientEvent(player, "add:notification", player, "Shared vehicle document with nearby player", "success", true)
end)
