local browser
local isVisible = false

local function toggleCursor(state)
    showCursor(state)
end

local function createBrowser()
    if isElement(browser) then return end
    local sw, sh = guiGetScreenSize()
    browser = guiCreateBrowser(0, 0, sw, sh, true, true, false)
    local theBrowser = guiGetBrowser(browser)
    addEventHandler("onClientBrowserCreated", theBrowser, function()
        loadBrowserURL(source, "http://mta/local/documents/html/index.html")
    end)
    addEventHandler("onClientBrowserDocumentReady", theBrowser, function()
        -- When ready, request data if we already have a pending string
        if isVisible then
            triggerServerEvent("documents:requestVehicles", localPlayer)
        end
    end)
end

addCommandHandler("vehicle", function()
    if not isVisible then
        isVisible = true
        createBrowser()
        if isElement(browser) then
            guiSetVisible(browser, true)
        end
        toggleCursor(true)
        triggerServerEvent("documents:requestVehicles", localPlayer)
    else
        isVisible = false
        if isElement(browser) then
            guiSetVisible(browser, false)
        end
        toggleCursor(false)
    end
end)

addEvent("documents:openPanel", true)
addEventHandler("documents:openPanel", root, function(dataString)
    if not isElement(browser) then
        createBrowser()
    end
    isVisible = true
    if isElement(browser) then
        guiSetVisible(browser, true)
    end
    toggleCursor(true)

    dataString = tostring(dataString or "")
    dataString = dataString:gsub("\\", "\\\\"):gsub("'", "\\'")
    local js = string.format("window.receiveVehiclesData('%s');", dataString)
    local theBrowser = guiGetBrowser(browser)
    executeBrowserJavascript(theBrowser, js)
end)

addEvent("documents:showSharedVehicle", true)
addEventHandler("documents:showSharedVehicle", root, function(vehicleString, fromPlayerName)
    if not isElement(browser) then
        createBrowser()
    end
    isVisible = true
    if isElement(browser) then
        guiSetVisible(browser, true)
    end
    toggleCursor(true)

    vehicleString = tostring(vehicleString or "")
    vehicleString = vehicleString:gsub("\\", "\\\\"):gsub("'", "\\'")
    fromPlayerName = tostring(fromPlayerName or "")
    fromPlayerName = fromPlayerName:gsub("\\", "\\\\"):gsub("'", "\\'")

    local js = string.format("window.showSharedVehicle('%s','%s');", vehicleString, fromPlayerName)
    local theBrowser = guiGetBrowser(browser)
    executeBrowserJavascript(theBrowser, js)
end)

-- Called from JS via mta.triggerEvent
addEvent("documents:shareVehicleFromUI", true)
addEventHandler("documents:shareVehicleFromUI", root, function(vehicleString)
    triggerServerEvent("documents:shareVehicle", localPlayer, tostring(vehicleString or ""))
end)

-- Close panel from HTML close button
addEvent("documents:closePanel", true)
addEventHandler("documents:closePanel", root, function()
    isVisible = false
    if isElement(browser) then
        guiSetVisible(browser, false)
    end
    toggleCursor(false)
end)
