--PERMISSION (default: Admin)
local PermissionGroup = "Admin"

-- Force spawn vehicle fine amount
local ForcespawnAmount = 2000


--IMPORATNT NOTE : Restart the resource using "/restart vehicles" after creating a garage to prevent dataloss
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

local db = dbConnect("sqlite", "vehicles.db")

local createTableQuery = [[
    CREATE TABLE IF NOT EXISTS Impounds (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        name TEXT NOT NULL,
        posX FLOAT NOT NULL,
        posY FLOAT NOT NULL,
        posZ FLOAT NOT NULL
    )
]]

-- Execute the SQL query to create the table
dbExec(db, createTableQuery)

local impoundLocations = {} 
local impoundBlips = {} 
local garageName

-- Function to check if the player has admin permissions
function hasAdminPermission(player)
    local accName = getAccountName(getPlayerAccount(player)) -- get his account name
    return isObjectInACLGroup("user."..accName, aclGetGroup(PermissionGroup))
end

-- Function to create a garage marker and save its location to the table
addCommandHandler("CreateImpound",
    function (player, command, name)
        if not hasAdminPermission(player) then
            outputChatBox("You don't have permission to use this command!", player, 255, 0, 0)
            return
        end
        impoundName = name 
        local posX, posY, posZ = getElementPosition(player)
        local marker = createMarker(posX, posY, posZ-1, "cylinder", markerSize, 10, 255, 10, 0)
        local blip = createBlip(posX, posY, posZ, 51, 2, 255, 0, 0, 255, 0, 200)

        --insert into table
        table.insert(impoundLocations, { marker = marker, posX = posX, posY = posY, posZ = posZ, name = impoundName })
        table.insert(impoundBlips, { blip = blip, posX = posX, posY = posY, posZ = posZ, name = impoundName })
        
        for _, player in ipairs(getElementsByType("player")) do
            sendImpoundLocationsToClient(player)
        end
        -- Save marker information to the database
        local insertQuery = "INSERT INTO Impounds (name, posX, posY, posZ) VALUES (?, ?, ?, ?)"
        dbExec(db, insertQuery, impoundName, posX, posY, posZ)
        outputChatBox(" Garage '" .. impoundName .. "' created along with its marker and blip!", player)
        outputChatBox("[DATABASE] : Data saved ", player)
end, false, false)

-- Function to check if the player is in a vehicle
function PlayerInVehicle(player)
    local vehicle = getPedOccupiedVehicle(player)
    return vehicle and isElement(vehicle)
end

function loadimpoundLocationsFromDB(queryHandle)
    local results = dbPoll(queryHandle, 0)
    for index, location in pairs(results) do
        local posX, posY, posZ = tonumber(location.posX), tonumber(location.posY), tonumber(location.posZ)
        local marker = createMarker(posX, posY, posZ-1, "cylinder", markerSize, 10, 255, 10, 0)
        local blip = createBlip(posX, posY, posZ, 51, 2, 255, 0, 0, 255, 0, 200)
        table.insert(impoundLocations, { marker = marker, posX = posX, posY = posY, posZ = posZ, name = location.name })
        table.insert(impoundBlips, { blip = blip, posX = posX, posY = posY, posZ = posZ, name = location.name })
        for _, player in ipairs(getElementsByType("player")) do
            sendImpoundLocationsToClient(player)
        end
    end
end

addEventHandler('onResourceStart', resourceRoot, function()
    dbQuery(loadimpoundLocationsFromDB, db, 'SELECT * FROM Impounds')
end)

--on markerhit function
function onPlayerHitMarker(hitElement, matchingDimension)
    if hitElement and matchingDimension and getElementType(hitElement) == "player" then
        local player = hitElement
        local posX, posY, posZ = getElementPosition(player)

        -- Check against locally stored garage locations
        for _, location in ipairs(impoundLocations) do
            local markerX, markerY, markerZ = location.posX, location.posY, location.posZ
            local distance = getDistanceBetweenPoints3D(markerX, markerY, markerZ, posX, posY, posZ)

            if distance <= markerSize then -- Adjust distance as needed
                if PlayerInVehicle(player) then
                    return
                else
                    triggerClientEvent(player, "add:notification", player, "[ Press E ] - To access IMPOUND garage", "info",true)
                end
                break -- Exit the loop once a marker is hit
            end
        end
    end
end
addEventHandler("onMarkerHit", root, onPlayerHitMarker)


-- Function to handle the command to delete the nearest marker
addCommandHandler("deleteImpound",
    function (player)
        if not hasAdminPermission(player) then
            outputChatBox("You don't have permission to use this command!", player, 255, 0, 0)
            return
        end

        local posX, posY, posZ = getElementPosition(player)
        local minDistance = markerSize
        local markerIndex = nil
        
        -- Find the nearest marker to the player
        for i, location in ipairs(impoundLocations) do
            local markerX, markerY, markerZ = location.posX, location.posY, location.posZ
            local distance = getDistanceBetweenPoints3D(markerX, markerY, markerZ, posX, posY, posZ)
            
            if distance < minDistance then
                markerIndex = i
                garageName = location.name -- for detecting the blip associated
            end
        end

        for i, Blip in ipairs(impoundBlips) do 
            if Blip.name == garageName then
                blipIndex = i
            end
        end
        -- Check if a marker within range was found
        if markerIndex then
            local markerName = impoundLocations[markerIndex].name
            -- Remove marker from the world
            destroyElement(impoundLocations[markerIndex].marker)
            destroyElement(impoundBlips[blipIndex].blip)

            outputChatBox("Nearest impound '" .. markerName .. "' deleted!", player)
            -- Remove marker from the table
            table.remove(impoundLocations, markerIndex)
            -- delete from database
            dbExec(db, "DELETE FROM Impounds WHERE name = ?", garageName)

            for _, player in ipairs(getElementsByType("player")) do
                sendImpoundLocationsToClient(player)
            end
        else
            outputChatBox("No Garage marker found within range to delete!", player)
        end
end, false, false)

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-- FETCHING DATA TO LOAD IN THE GARAGE MENU
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
local client

function ImpoundDataFetch(queryHandle)
    local data = dbPoll(queryHandle, 0)
    triggerClientEvent(client, "ImpoundOpenWithData", client, data)
    return result
end

addEvent('clientImpoundRequestData', true)
addEventHandler('clientImpoundRequestData', root, function()
    client = source

    -- Do not open impound panel if player is inside a vehicle
    if PlayerInVehicle(client) then
        return
    end

    local posX, posY, posZ = getElementPosition(client)
    local minDistance = markerSize -- Set initial high value for comparison
    local markerIndex = nil
    
    -- Find the nearest marker to the player
    for i, location in ipairs(impoundLocations) do
        local markerX, markerY, markerZ = location.posX, location.posY, location.posZ
        local distance = getDistanceBetweenPoints3D(markerX, markerY, markerZ, posX, posY, posZ)
        
        if distance < minDistance then
            local accName = getAccountName(getPlayerAccount(client))
            dbQuery(ImpoundDataFetch, db, "SELECT * FROM vehicles WHERE owner=? AND vehiclestored=?", accName, 2)
        end
    end
end)

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-- Vehicle impound
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
function triggerKeySound(player, message)
    triggerClientEvent(player, "Vehicle:keysound", resourceRoot, message)
end

-- Command handler for /impound
function impoundVehicleCommand(player, command)
    if not hasAdminPermission(player) then
        triggerClientEvent(player, "add:notification", player, "You Don't have the permission to perform this command", "error",true)
        return
    end

    local x, y, z = getElementPosition(player) -- Get player's position
    local vehicles = getElementsByType("vehicle") -- Get all vehicle elements
    local nearestDist = 4 -- Set initial distance to a very high value
    local nearestVehicle = nil -- Variable to store the nearest vehicle

    for _, vehicle in ipairs(vehicles) do
        local vx, vy, vz = getElementPosition(vehicle) -- Get vehicle's position
        local distance = getDistanceBetweenPoints3D(x, y, z, vx, vy, vz) -- Calculate distance

        if distance < nearestDist then
            nearestDist = distance -- Update nearest distance
            nearestVehicle = vehicle -- Set nearest vehicle
        end
    end

    if nearestVehicle then 
        local Owner = getElementData(nearestVehicle, "owner")
        local vehicleID = getElementData(nearestVehicle, "id")
        dbExec(db, 'UPDATE vehicles SET vehiclestored = ? WHERE id = ?', 2, vehicleID) -- Update vehiclestored to 2
        destroyElement(nearestVehicle)
        outputChatBox("Vehicle has been impounded.", player, 0, 255, 0)
        triggerClientEvent(player, "add:notification", player, "Vehicle with id " .. vehicleID .. " has been impounded", "success",true)
    else
        triggerClientEvent(player, "add:notification", player, "No vehicle nearby Found !", "error",true)
    end
end
addCommandHandler("impound", impoundVehicleCommand, false, false)

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------


function sendImpoundLocationsToClient(player)
    if isElement(player) then
        triggerClientEvent(player, "receiveImpoundLocations", player, impoundLocations)
    end
end

addEventHandler("onPlayerJoin", root, function()
    sendImpoundLocationsToClient(source)
end)
