-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
--AUTHOR : SAI RAM KISHAN K J, DISCORD ID : sairamkishan#9290 INSTA ID: sairamkishan30
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-- commands : /creategarage <name> - to crate a garage at your location
              --  (adds maps blip and marker and store to database)

--          : /deletegarage - deletes the nearest garage with data from db and blip

--PERMISSION (default: Admin)
local PermissionGroup = "Admin"

-- Force spawn vehicle fine amount
local ForcespawnAmount = 2000


--IMPORATNT NOTE : Restart the resource using "/restart vehicles" after creating a garage to prevent dataloss
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

local db = dbConnect("sqlite", "vehicles.db")

local createTableQuery = [[
    CREATE TABLE IF NOT EXISTS Garages (
        id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        name TEXT NOT NULL,
        posX FLOAT NOT NULL,
        posY FLOAT NOT NULL,
        posZ FLOAT NOT NULL
    )
]]

-- Execute the SQL query to create the table
dbExec(db, createTableQuery)

local GarageLocations = {} 
local Blips = {} 
local garageName

-- Function to check if the player has admin permissions
function hasAdminPermission(player)
    local accName = getAccountName(getPlayerAccount(player)) -- get his account name
    return isObjectInACLGroup("user."..accName, aclGetGroup(PermissionGroup))
end

-- Function to create a garage marker and save its location to the table
addCommandHandler("CreateGarage",
    function (player, command, name)
        if not hasAdminPermission(player) then
            outputChatBox("You don't have permission to use this command!", player, 255, 0, 0)
            return
        end
        garageName = name 
        local posX, posY, posZ = getElementPosition(player)
        local marker = createMarker(posX, posY, posZ-1, "cylinder", markerSize, 255, 10, 10, 0)
        local blip = createBlip(posX, posY, posZ, 55, 2, 255, 0, 0, 255, 0, 200)

        --insert into table
        table.insert(GarageLocations, { marker = marker, posX = posX, posY = posY, posZ = posZ, name = garageName })
        table.insert(Blips, { blip = blip, posX = posX, posY = posY, posZ = posZ, name = garageName })
        
        for _, player in ipairs(getElementsByType("player")) do
            sendGarageLocationsToClient(player)
        end
        -- Save marker information to the database
        local insertQuery = "INSERT INTO Garages (name, posX, posY, posZ) VALUES (?, ?, ?, ?)"
        dbExec(db, insertQuery, garageName, posX, posY, posZ)
        outputChatBox(" Garage '" .. garageName .. "' created along with its marker and blip!", player)
        outputChatBox("[DATABASE] : Data saved ", player)
end, false, false)

-- Function to check if the player is in a vehicle
function PlayerInVehicle(player)
    local vehicle = getPedOccupiedVehicle(player)
    return vehicle and isElement(vehicle)
end


function loadGarageLocationsFromDB(queryHandle)
    local results = dbPoll(queryHandle, 0)
    
    if results then
        for _, location in ipairs(results) do
            local posX, posY, posZ = tonumber(location.posX), tonumber(location.posY), tonumber(location.posZ)
            local marker = createMarker(posX, posY, posZ - 1, "cylinder", markerSize, 255, 10, 10, 0)
            local blip = createBlip(posX, posY, posZ, 55, 2, 255, 0, 0, 255, 0, 200)

            table.insert(GarageLocations, { marker = marker, posX = posX, posY = posY, posZ = posZ, name = location.name })
            table.insert(Blips, { blip = blip, posX = posX, posY = posY, posZ = posZ, name = location.name })
        end

        -- Send all locations to connected players after loading
        for _, player in ipairs(getElementsByType("player")) do
            sendGarageLocationsToClient(player)
        end
    else
        outputDebugString("GarageLocations DB query returned no results or failed!", 2)
    end
end



addEventHandler('onResourceStart', resourceRoot, function()
    dbQuery(loadGarageLocationsFromDB, db, 'SELECT * FROM Garages')
end)

--notification bar call
function showgarageNotification(player, message)
    triggerClientEvent(player, "garageNotification:show", resourceRoot, message)
end

function hidegarageNotification(player, message)
    triggerClientEvent(player, "garageNotification:hide", resourceRoot, message)
end

--on markerhit function
function onPlayerHitMarker(hitElement, matchingDimension)
    if hitElement and matchingDimension and getElementType(hitElement) == "player" then
        local player = hitElement
        local posX, posY, posZ = getElementPosition(player)

        -- Check against locally stored garage locations
        for _, location in ipairs(GarageLocations) do
            local markerX, markerY, markerZ = location.posX, location.posY, location.posZ
            local distance = getDistanceBetweenPoints3D(markerX, markerY, markerZ, posX, posY, posZ)

            if distance <= markerSize then -- Adjust distance as needed
                if PlayerInVehicle(player) then
                    showgarageNotification(player)
                else
                    showgarageNotification(player)
                end
                break -- Exit the loop once a marker is hit
            end
        end
    end
end
addEventHandler("onMarkerHit", root, onPlayerHitMarker)

function onPlayerLeaveMarker(leaveElement, matchingDimension)
	if leaveElement and matchingDimension and getElementType(leaveElement) == "player" then
        local player = leaveElement
        hidegarageNotification(player)
	end
end
addEventHandler("onMarkerLeave", root, onPlayerLeaveMarker)



-- Function to handle the command to delete the nearest marker
addCommandHandler("DeleteGarage",
    function (player)
        if not hasAdminPermission(player) then
            outputChatBox("You don't have permission to use this command!", player, 255, 0, 0)
            return
        end

        local posX, posY, posZ = getElementPosition(player)
        local minDistance = markerSize
        local markerIndex = nil
        
        -- Find the nearest marker to the player
        for i, location in ipairs(GarageLocations) do
            local markerX, markerY, markerZ = location.posX, location.posY, location.posZ
            local distance = getDistanceBetweenPoints3D(markerX, markerY, markerZ, posX, posY, posZ)
            
            if distance < minDistance then
                markerIndex = i
                garageName = location.name -- for detecting the blip associated
            end
        end

        for i, Blip in ipairs(Blips) do 
            if Blip.name == garageName then
                blipIndex = i
            end
        end
        -- Check if a marker within range was found
        if markerIndex then
            local markerName = GarageLocations[markerIndex].name
            -- Remove marker from the world
            destroyElement(GarageLocations[markerIndex].marker)
            destroyElement(Blips[blipIndex].blip)

            outputChatBox("Nearest Garage '" .. markerName .. "' deleted!", player)
            -- Remove marker from the table
            table.remove(GarageLocations, markerIndex)
            -- delete from database
            dbExec(db, "DELETE FROM Garages WHERE name = ?", garageName)
            for _, player in ipairs(getElementsByType("player")) do
                sendGarageLocationsToClient(player)
            end
        else
            outputChatBox("No Garage marker found within range to delete!", player)
        end
end, false, false)


-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-- VEHICLE SYSTEM, GARAGE STORE, TAKE, BLIP MARK FOR VEHICLE , ETC, ETX
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

local client

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-- Destroy all vehicles
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

-- Destroy All Vehicles in World Cooldown
-- 1000 = 1 second
local DestroyAllVehiclesCooldown = 10000

function DestroyAllVehicles()
    local players = getElementsByType("player")
    local vehicles = getElementsByType("vehicle")
    
    local DestroyAllVehiclesCooldownSeconds = DestroyAllVehiclesCooldown / 1000
    local halfCooldown = DestroyAllVehiclesCooldown / 2
    local oneFifthCooldown = DestroyAllVehiclesCooldown * 0.2

    -- Notify all players about the destruction cooldown
    for _, player in ipairs(players) do
        triggerClientEvent(player, "add:notification", player, "Destroying all vehicles (without driver) in: " .. DestroyAllVehiclesCooldownSeconds .. " seconds", "warn", true)
    end
    
    -- Set a timer to notify players at half cooldown
    setTimer(function()
        for _, player in ipairs(players) do
            triggerClientEvent(player, "add:notification", player, "Destroying all vehicles (without driver) in: " .. (DestroyAllVehiclesCooldownSeconds / 2) .. " seconds", "warn", true)
        end
    end, halfCooldown, 1)
    
    -- Set a timer to notify players at one fifth cooldown
    setTimer(function()
        for _, player in ipairs(players) do
            triggerClientEvent(player, "add:notification", player, "Destroying all vehicles (without driver) in: " .. (DestroyAllVehiclesCooldownSeconds * 0.2) .. " seconds", "warn", true)
        end
    end, DestroyAllVehiclesCooldown - oneFifthCooldown, 1)

    -- Set a timer to destroy all vehicles after the cooldown
    setTimer(function()
        for _, vehicle in ipairs(vehicles) do
            -- Check if the vehicle's owner is "kkrp3000", if so, ignore it
            local owner = getElementData(vehicle, "owner")
            if owner ~= "kkrp3000" then
                local occupants = getVehicleOccupants(vehicle) or {}  -- Ensure occupants is a table
                if type(occupants) == "table" and not next(occupants) then  -- Check if the occupants table is empty
                    local vehicleID = getElementData(vehicle, "id")
                    dbExec(db, 'UPDATE vehicles SET vehiclestored = ? WHERE id = ?', 1, vehicleID)
                    destroyElement(vehicle)
                end
            end
        end

        -- Notify all players that vehicles have been destroyed
        for _, player in ipairs(players) do
            triggerClientEvent(player, "add:notification", player, "Destroyed all the vehicles (without driver)", "success", true)
        end
    end, DestroyAllVehiclesCooldown, 1)
end

addCommandHandler('dav', DestroyAllVehicles, false, false)
addCommandHandler('DestroyAllVehicles', DestroyAllVehicles, false, false)


-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-- Create check point bLIP
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

local playerCheckpoints = {} -- Store player checkpoints

-- Function to create a checkpoint and marker for a player
function createCheckpointForPlayer(player, x, y, z)
    -- Check if the player already has a checkpoint, delete it
    if playerCheckpoints[player] then
        if isElement(playerCheckpoints[player].checkpoint) then
            destroyElement(playerCheckpoints[player].checkpoint)
        end
        if isElement(playerCheckpoints[player].blip) then
            destroyElement(playerCheckpoints[player].blip)
        end
        playerCheckpoints[player] = nil
    end

    -- Create a new checkpoint and blip
    local checkpoint = createMarker(x, y, z, "checkpoint", 3, 255, 255, 0, 150) -- Yellow checkpoint
    local blip = createBlipAttachedTo(checkpoint, 0, 2, 255, 255, 0, 150) -- Yellow blip

    -- Make the checkpoint and blip only visible to the specific player
    setElementVisibleTo(checkpoint, root, false) -- Hide from everyone
    setElementVisibleTo(checkpoint, player, true) -- Show only to the player

    setElementVisibleTo(blip, root, false)
    setElementVisibleTo(blip, player, true)

    -- Store checkpoint data
    playerCheckpoints[player] = {checkpoint = checkpoint, blip = blip}
end

-- Function to handle player reaching the checkpoint
function checkPlayerPosition(player)
    local checkpointData = playerCheckpoints[player]
    if checkpointData and isElement(checkpointData.checkpoint) then
        local x, y, z = getElementPosition(player)
        local checkpointX, checkpointY, checkpointZ = getElementPosition(checkpointData.checkpoint)
        local distance = getDistanceBetweenPoints3D(x, y, z, checkpointX, checkpointY, checkpointZ)

        if distance <= 5 then
            -- Player reached the checkpoint, delete it
            destroyElement(checkpointData.checkpoint)
            destroyElement(checkpointData.blip)
            playerCheckpoints[player] = nil -- Remove checkpoint data

            triggerClientEvent(player, "add:notification", player, "CHECKPOINT reached", "success", true)
        end
    end
end

-- Remove checkpoint when a player leaves
function onPlayerLeave()
    local player = source
    if playerCheckpoints[player] then
        if isElement(playerCheckpoints[player].checkpoint) then
            destroyElement(playerCheckpoints[player].checkpoint)
        end
        if isElement(playerCheckpoints[player].blip) then
            destroyElement(playerCheckpoints[player].blip)
        end
        playerCheckpoints[player] = nil
    end
end

-- Attach checkPlayerPosition function to onPlayerMarkerHit event
addEventHandler("onPlayerMarkerHit", root, function(marker, matchingDimension)
    if matchingDimension then
        checkPlayerPosition(source)
    end
end)

-- Attach event to remove checkpoint when player leaves
addEventHandler("onPlayerQuit", root, onPlayerLeave)


-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-- Check Vehicle Exist and Forcedestroy it [with ID]
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
function CheckVehicleByID(vehicleID)
    local vehicles = getElementsByType("vehicle")
    
    for _, vehicle in ipairs(vehicles) do
        local id = getElementData(vehicle, "id")
        if id and tonumber(id) == tonumber(vehicleID) then
            local Vx, Vy, Vz = getElementPosition(vehicle)
            createCheckpointForPlayer(client, Vx, Vy, Vz)
            triggerClientEvent(client, "add:notification", client, "Vehicle not Stored! (Follow the yellow blip to get to the vehicle)", "warn",true)
        end
    end
end

function destroyVehicleByID(vehicleID)
    local vehicles = getElementsByType("vehicle")
    for _, vehicle in ipairs(vehicles) do
        local id = getElementData(vehicle, "id")
        if id and tonumber(id) == tonumber(vehicleID) then
            -- REMOVE PLAYER MONEY SYSTEM SCRIPT TO BE ADDED !!!!!!!!!!!!!!!!!!!!!!
             -- destroy vehicle        
            destroyElement(vehicle)
            break
        end
    end
end

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-- STORE VEHICLE TO GARAGE
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
addEvent('vehicle:DestroyPlayerVehicle', true)
addEventHandler('vehicle:DestroyPlayerVehicle', root, function()
    client = source

    local posX, posY, posZ = getElementPosition(client)
    local minDistance = markerSize -- Set initial high value for comparison
    local markerIndex = nil

    -- Find the nearest marker to the player
    for i, location in ipairs(GarageLocations) do
        local markerX, markerY, markerZ = location.posX, location.posY, location.posZ
        local distance = getDistanceBetweenPoints3D(markerX, markerY, markerZ, posX, posY, posZ)

        if distance < minDistance then
            local vehicle = getPedOccupiedVehicle(client)
            if vehicle and getElementType(vehicle) == "vehicle" then
                local Owner = getElementData(vehicle, "owner")
                if getAccountName(getPlayerAccount(client)) == Owner then
                    local vehicleID = getElementData(vehicle, "id")
                    dbExec(db, 'UPDATE vehicles SET vehiclestored = ? WHERE id = ?', 1, vehicleID)
                    outputChatBox("vehicle with id"..vehicleID, client)
                    -- SAVE VEHICLE CONFIG
                    local x, y, z = getElementPosition(vehicle)
                    local rx, ry, rz = getElementRotation(vehicle)

                    -- Get the vehicle color
                    local colors = {getVehicleColor(vehicle, true)}
                    local vehicleColors = toJSON({
                        color1 = {r = colors[1], g = colors[2], b = colors[3]},
                        color2 = {r = colors[4], g = colors[5], b = colors[6]},
                        color3 = {r = colors[7], g = colors[8], b = colors[9]},
                        color4 = {r = colors[10], g = colors[11], b = colors[12]}
                    })

                    -- Get the paint job and vehicle upgrades
                    local paintJob = getVehiclePaintjob(vehicle)
                    local upgrades = toJSON(getVehicleUpgrades(vehicle))
                    local id = vehicleID

                    local currentFuel = getElementData(vehicle, "fuel")
                    local vehicleHealth = getElementHealth(vehicle)

                    -- Vehicle headlight color
                    local hr, hg, hb = getVehicleHeadLightColor(vehicle)
                    local headlightColor = toJSON({ r = hr, g = hg, b = hb })

                    -- Get vehicle handling
                    local handling = toJSON(getVehicleHandling(vehicle))

                    local numberPlate = getElementData(vehicle, "numberPlate")

                    -- Vehicle storage data 
                    local trunkCapacity = getElementData(vehicle, "trunk")
                    local gloveboxCapacity = getElementData(vehicle, "glovebox")

                    local interior = getElementData(vehicle, "interior")
                    local dimension = getElementData(vehicle, "dimension")

                    -- Get damaged parts (doors and panels)
                    local damagedParts = {
                        doors = {},
                        panels = {}
                    }

                    -- Check all doors (0-5: Hood, Trunk, and 4 car doors)
                    for i = 0, 5 do
                        damagedParts.doors[tostring(i)] = getVehicleDoorState(vehicle, i)
                    end

                    -- Check all panels (0-6)
                    for i = 0, 6 do
                        damagedParts.panels[tostring(i)] = getVehiclePanelState(vehicle, i)
                    end

                    local damagedPartsJSON = toJSON(damagedParts)

                    -- Prepare the SQL query to update the vehicle's data including damaged parts
                    local updateQuery = [[
                        UPDATE vehicles 
                        SET x = ?, y = ?, z = ?, rx = ?, ry = ?, rz = ?, color = ?, paintjob = ?, fuel = ?, health = ?, 
                            headlightColor = ?, upgrades = ?, handling = ?, numberPlate = ?, trunk = ?, glovebox = ?, 
                            interior = ?, dimension = ?, damage_states = ? 
                        WHERE id = ?
                    ]]

                    -- Update the database with the current vehicle details
                    dbExec(db, updateQuery, x, y, z, rx, ry, rz, vehicleColors, paintJob, currentFuel, vehicleHealth, 
                           headlightColor, upgrades, handling, numberPlate, trunkCapacity, gloveboxCapacity, interior, 
                           dimension, damagedPartsJSON, id)

                    triggerClientEvent(client, "add:notification", client, "Vehicle Stored Successfully", "success", true)

                    destroyElement(vehicle)
                else 
                    triggerClientEvent(client, "add:notification", client, "You can't store this vehicle", "error", true)
                    return
                end 
            else
                triggerClientEvent(client, "add:notification", client, "You Should be inside the vehicle to do that", "error", true)
            end
        end
    end
end)

-----------------------------------------------------------------------------
-- SPAWNING THE VEHICLE FROM GARAGE------------------------------------------
-----------------------------------------------------------------------------
--Function for the query-
function SpawnVehicleById(queryHandle)
    checkpointData = playerCheckpoints[client]
    if checkpointData and checkpointData.checkpoint and isElement(checkpointData.checkpoint) then
        destroyElement(checkpointData.checkpoint)
        destroyElement(checkpointData.blip)
        playerCheckpoints[client] = nil
    end
    local result = dbPoll(queryHandle, 0)
    
    if result and #result > 0 then
        local vehicle = result[1] -- Assuming only one vehicle will match the ID

        local x, y, z = getElementPosition(client)
        local rx, ry, rz = getElementRotation(client)
        local colors = fromJSON(vehicle.color)
        local paintJob = vehicle.paintjob
        local upgrades = fromJSON(vehicle.upgrades) 
        local headlightColor = fromJSON(vehicle.headlightColor)
        local handling = fromJSON(vehicle.handling)

        -- Check if the vehicle is already in the world
        CheckVehicleByID(vehicle.id)
        
        if vehicle.vehiclestored == 1 then
            local vehicleObject = createVehicle(vehicle.model, x, y, z, rx, ry, rz, vehicle.numberPlate)
            dbExec(db, 'UPDATE vehicles SET vehiclestored = ? WHERE id = ?', 0, vehicle.id)
            local fuel = vehicle.fuel
            local health = vehicle.health

            -- UPDATING VEHICLE DATA
            if not vehicleObject then
                return
            else
                if colors then
                    setVehicleColor(vehicleObject, colors.color1.r, colors.color1.g, colors.color1.b, colors.color2.r, colors.color2.g, colors.color2.b, colors.color3.r, colors.color3.g, colors.color3.b, colors.color4.r, colors.color4.g, colors.color4.b)
                end
                setVehicleLocked(vehicleObject, true)
                setVehicleEngineState(vehicleObject, false)
                setVehiclePaintjob(vehicleObject, paintJob)
                setVehicleVariant(vehicleObject, vehicle.varient1, vehicle.varient2)
                setElementData(vehicleObject, "fuel", fuel)
                setElementHealth(vehicleObject, health)

                if headlightColor then 
                    setVehicleHeadLightColor(vehicleObject, headlightColor.r, headlightColor.g, headlightColor.b)
                end

                setVehicleHandling(vehicleObject, handling)

                if upgrades then
                    for _, upgradeID in ipairs(upgrades) do
                        addVehicleUpgrade(vehicleObject, upgradeID)
                    end
                end
                setElementData(vehicleObject, 'id', vehicle.id)
                setElementData(vehicleObject, "owner", vehicle.owner)
                setElementData(vehicleObject, "numberPlate", vehicle.numberPlate)
                setElementData(vehicleObject, "displayName", vehicle.displayName)
                setElementData(vehicleObject, "price", vehicle.price)
                setElementData(vehicleObject, "brandname", vehicle.brandname)

                setElementData(vehicleObject, "trunk", vehicle.trunk)
                setElementData(vehicleObject, "glovebox", vehicle.glovebox)

                -- Restore vehicle damaged parts (doors and panels)
                local damagedParts = fromJSON(vehicle.damage_states)

                if damagedParts then
                    if damagedParts.doors then
                        for door, state in pairs(damagedParts.doors) do
                            setVehicleDoorState(vehicleObject, tonumber(door), state)
                        end
                    end
                    if damagedParts.panels then
                        for panel, state in pairs(damagedParts.panels) do
                            setVehiclePanelState(vehicleObject, tonumber(panel), state)
                        end
                    end
                end

                -- Save the vehicle to the garage
                triggerClientEvent(client, "add:notification", client, "Vehicle spawned successfully", "success", true)

                local interior = getElementInterior(client)
                local dimension = getElementDimension(client)
                warpPedIntoVehicle(client, vehicleObject)
                setElementInterior(vehicleObject, interior)
                setElementDimension(vehicleObject, dimension)
                setElementData(vehicleObject, "interior", interior)
                setElementData(vehicleObject, "dimension", dimension)
            end
        else
           
        end
    else
        outputServerLog("[Garage:V-SPAWN] No vehicle found with ID " .. vehicleID)
    end
end

-- Server event to spawn a player's vehicle by ID
addEvent('vehicle:SpawnPlayerVehicle', true)
addEventHandler('vehicle:SpawnPlayerVehicle', root, function(vehicleID)
    client = source
    dbQuery(SpawnVehicleById, db, "SELECT * FROM vehicles WHERE id=?", vehicleID) 
end)


-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
--FORCE SPAWN VEHICLE
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
local ForceSpawnAmount = 20000

-- Function for the query
function ForceSpawnVehicleById(queryHandle)
    -- Money check
    local account = getPlayerAccount(client)
    local accountName = getAccountName(account)

    local PlayerMoney = exports.money:getMoney(account)
    PlayerRemainingMoney = tonumber(PlayerMoney - ForceSpawnAmount)

    if PlayerRemainingMoney < 0 then 
        outputChatBox("You don't have enough money! Current balance: " .. PlayerMoney)
        return 
    end

    local PlayerMoney = exports.money:takeMoney(account, ForceSpawnAmount)

    checkpointData = playerCheckpoints[client]
    if checkpointData and checkpointData.checkpoint and isElement(checkpointData.checkpoint) then
        destroyElement(checkpointData.checkpoint)
        destroyElement(checkpointData.blip)
        playerCheckpoints[client] = nil
    end
    
    local result = dbPoll(queryHandle, 0)
    local vehicle = result[1] -- Assuming only one vehicle will match the ID

    if vehicle.vehiclestored == 2 then
        local x, y, z = getElementPosition(client)
        local rx, ry, rz = getElementRotation(client)
        local colors = fromJSON(vehicle.color)
        local paintJob = vehicle.paintjob
        local upgrades = fromJSON(vehicle.upgrades) 
        local headlightColor = fromJSON(vehicle.headlightColor)
        local handling = fromJSON(vehicle.handling)

        -- Check if the vehicle is already in the world
        CheckVehicleByID(vehicle.id)
        
        if vehicle.vehiclestored == 2 then
            local vehicleObject = createVehicle(vehicle.model, x, y, z, rx, ry, rz, vehicle.numberPlate)
            dbExec(db, 'UPDATE vehicles SET vehiclestored = ? WHERE id = ?', 0, vehicle.id)
            local fuel = vehicle.fuel
            local health = vehicle.health

            -- Updating vehicle data
            if not vehicleObject then
                return
            else
                if colors then
                    setVehicleColor(vehicleObject, colors.color1.r, colors.color1.g, colors.color1.b, colors.color2.r, colors.color2.g, colors.color2.b, colors.color3.r, colors.color3.g, colors.color3.b, colors.color4.r, colors.color4.g, colors.color4.b)
                end
                setVehicleLocked(vehicleObject, true)
                setVehicleEngineState(vehicleObject, false)
                setVehiclePaintjob(vehicleObject, paintJob)
                setVehicleVariant(vehicleObject, vehicle.varient1, vehicle.varient2)
                setElementData(vehicleObject, "fuel", fuel)
                setElementHealth(vehicleObject, health)

                if headlightColor then 
                    setVehicleHeadLightColor(vehicleObject, headlightColor.r, headlightColor.g, headlightColor.b)
                end

                setVehicleHandling(vehicleObject, handling)

                if upgrades then
                    for _, upgradeID in ipairs(upgrades) do
                        addVehicleUpgrade(vehicleObject, upgradeID)
                    end
                end
                setElementData(vehicleObject, 'id', vehicle.id)
                setElementData(vehicleObject, "owner", vehicle.owner)
                setElementData(vehicleObject, "numberPlate", vehicle.numberPlate)
                setElementData(vehicleObject, "displayName", vehicle.displayName)
                setElementData(vehicleObject, "price", vehicle.price)
                setElementData(vehicleObject, "brandname", vehicle.brandname)
                setElementData(vehicleObject, "trunk", vehicle.trunk)
                setElementData(vehicleObject, "glovebox", vehicle.glovebox)

                -- Restore vehicle damaged parts (doors and panels)
                local damagedParts = fromJSON(vehicle.damage_states)

                if damagedParts then
                    if damagedParts.doors then
                        for door, state in pairs(damagedParts.doors) do
                            setVehicleDoorState(vehicleObject, tonumber(door), state)
                        end
                    end
                    if damagedParts.panels then
                        for panel, state in pairs(damagedParts.panels) do
                            setVehiclePanelState(vehicleObject, tonumber(panel), state)
                        end
                    end
                end
            end
            
            triggerClientEvent(client, "add:notification", client, "Vehicle Spawned from IMPOUND", "success", true)
            triggerClientEvent(client, "add:notification", client, tostring(ForceSpawnAmount) .. " rs Fine Has been added to your account", "warn", true)

            local interior = getElementInterior(client)
            local dimension = getElementDimension(client)
            warpPedIntoVehicle(client, vehicleObject)
            setElementInterior(vehicleObject, interior)
            setElementDimension(vehicleObject, dimension)
            setElementData(vehicleObject, "interior", interior)
            setElementData(vehicleObject, "dimension", dimension)

            dbExec(db, 'UPDATE vehicles SET vehiclestored = ? WHERE id = ?', 0, vehicle.id)

        --    destroyVehicleByID(vehicleData.id)
        end
    else
        triggerClientEvent(client, "add:notification", client, "Vehicle is not IMPOUNDED", "error", true)
    end
end

-- Server event to spawn a player's vehicle by ID
addEvent('vehicle:ForceSpawnPlayerVehicle', true)
addEventHandler('vehicle:ForceSpawnPlayerVehicle', root, function(vehicleID)
    client = source
    dbQuery(ForceSpawnVehicleById, db, "SELECT * FROM vehicles WHERE id=?", vehicleID) 
end)


-----------------------------------------------------------------------------
-----------------------------------------------------------------------------
-- FETCHING DATA TO LOAD IN THE GARAGE MENU
-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

function fetchDataForPlayer(queryHandle)
    local data = dbPoll(queryHandle, 0)
    triggerClientEvent(client, "onDataReceived", client, data)
    return result
end

addEvent('onClientRequestData', true)
addEventHandler('onClientRequestData', root, function()
    client = source

    -- Do not open garage panel if player is inside a vehicle
    if PlayerInVehicle(client) then
        return
    end

    local posX, posY, posZ = getElementPosition(client)
    local minDistance = markerSize -- Set initial high value for comparison
    local markerIndex = nil
    -- Find the nearest marker to the player
    for i, location in ipairs(GarageLocations) do
        local markerX, markerY, markerZ = location.posX, location.posY, location.posZ
        local distance = getDistanceBetweenPoints3D(markerX, markerY, markerZ, posX, posY, posZ)
        if distance < minDistance then
            local accName = getAccountName(getPlayerAccount(client))
            dbQuery(function(queryHandle)
                local data = dbPoll(queryHandle, 0)
                triggerClientEvent(client, "onDataReceived", client, data)
            end, db, "SELECT * FROM vehicles WHERE owner=? AND vehiclestored IN (?, ?)", accName, 0, 1)
        end
    end
end)

-----------------------------------------------------------------------------
-----------------------------------------------------------------------------

function sendGarageLocationsToClient(player)
    if isElement(player) then
        triggerClientEvent(player, "receiveGarageLocations", player, GarageLocations)
    end
end

addEventHandler("onPlayerJoin", root, function()
    sendGarageLocationsToClient(source)
end)

