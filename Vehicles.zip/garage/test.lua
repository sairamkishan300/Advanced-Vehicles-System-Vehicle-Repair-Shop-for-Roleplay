local db = dbConnect("sqlite", "vehicles.db")
-- SQL statement to create the 'vehicle' table
local createTableQuery = [[
    CREATE TABLE IF NOT EXISTS vehicles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        model INTEGER NOT NULL,
        x REAL NOT NULL,
        y REAL NOT NULL,
        z REAL NOT NULL,
        rx REAL NOT NULL,
        ry REAL NOT NULL,
        rz REAL NOT NULL,
        owner TEXT NOT NULL,
        color TEXT NOT NULL,
        paintjob INTEGER NOT NULL,
        upgrades TEXT NOT NULL,
        varient1 INTEGER NOT NULL,
        varient2 INTEGER NOT NULL,
        fuel INTEGER DEFAULT 100 NOT NULL, 
        health REAL DEFAULT 1000 NOT NULL, 
        headlightR INTEGER DEFAULT 255 NOT NULL,
        headlightG INTEGER DEFAULT 255 NOT NULL,
        headlightB INTEGER DEFAULT 255 NOT NULL,
        vehiclestored INTEGER DEFAULT 0 NOT NULL
    )
]]



-- create the table
dbExec(db, createTableQuery)

---------------------------------------------------------
-- PLAYER BUY VEHICLE
---------------------------------------------------------

function PlayerVehicleBuy(player, command, model)
    local x, y, z = getElementPosition(player)
    local rx, ry, rz = getElementRotation(player)
    y = y + 3

    dbQuery(function(queryHandle)
        local account = getPlayerAccount(player)
        AccountName = tostring(getAccountName(account))
        numberPlate = AccountName
        local vehicleObject = createVehicle(model, x, y, z, rx, ry, rz, AccountName)
        -- get the vehicle colour
        local colors = {getVehicleColor(vehicleObject, true)}
        colors = {
            color1 = {r = colors[1], g = colors[2], b = colors[3]},
            color2 = {r = colors[4], g = colors[5], b = colors[6]},
            color3 = {r = colors[7], g = colors[8], b = colors[7]},
            color4 = {r = colors[10], g = colors[11], b = colors[12]},
        }
        -- get the paint job
        local paintJob = getVehiclePaintjob ( vehicleObject )
        --vehicle upgrades
        local Upgrades = getVehicleUpgrades(vehicleObject)
        --vehicle varient
        local Varient1, Varient2  = getVehicleVariant ( vehicleObject )

        if (vehicleObject == false) then
            outputChatBox("Failed to create vehicle.", player, 255, 0, 0, true) -- Red color (255, 0, 0) for error message
        else
            local InsertQuerry = 'INSERT INTO vehicles (model, x, y, z, rx, ry, rz, owner, color, paintjob, upgrades, varient1, varient2) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
            dbExec(db, InsertQuerry, model, x, y, z, rx, ry, rz, AccountName, toJSON(colors), paintJob, toJSON(Upgrades), Varient1, Varient2)
            -- Get the latest vehicle index
            local results = dbPoll(queryHandle, 0)
            local latestVehicleID = (results[1].id + 1) or 1 -- Access the ID from the first result

            -- SET ELEMENT DATA
            setElementData(vehicleObject, 'id', latestVehicleID)
            setElementData(vehicleObject, "owner", AccountName)

            outputChatBox("VEHICLE UNIQUE ID: " .. latestVehicleID .. ".", player, 0, 152, 152, true)

            local interior = getElementInterior(player)
            local dimension = getElementDimension(player)
            warpPedIntoVehicle(player, vehicleObject)
            setElementInterior(vehicleObject, interior)
            setElementDimension(vehicleObject, dimension)
            setVehicleEngineState ( vehicleObject, false )
            outputChatBox("Created Vehicle Successfully. You're inside the vehicle!", player, 0, 255, 0, true) -- Green color (0, 255, 0)
        end
    end, db, 'SELECT id FROM vehicles ORDER BY id DESC LIMIT 1')
end

addCommandHandler('buyVehicle', PlayerVehicleBuy, false, false)
addCommandHandler('bv', PlayerVehicleBuy, false, false)

---------------------------------------------------------
-- load vehicle on restart 
---------------------------------------------------------

function loadAllVehicles(queryHandle)
    local results = dbPoll(queryHandle, 0)
    for index, vehicle in pairs(results) do
        if vehicle.vehiclestored == 0 then 
            local colors = fromJSON(vehicle.color)
            local paintJob = vehicle.paintjob
            local upgrades = fromJSON(vehicle.upgrades) 
            local vehicleObject = createVehicle(vehicle.model, vehicle.x, vehicle.y, vehicle.z, vehicle.rx, vehicle.ry, vehicle.rz, tostring(vehicle.id))
            
            local fuel = vehicle.fuel
            local health = vehicle.health

            if not vehicleObject then
                return
            else
                if colors then
                    setVehicleColor(vehicleObject, colors.color1.r, colors.color1.g, colors.color1.b, colors.color2.r, colors.color2.g, colors.color2.b, colors.color3.r, colors.color3.g, colors.color3.b, colors.color4.r, colors.color4.g, colors.color4.b)
                end
                --Lock vehicle by default
                setVehicleLocked ( vehicleObject, true )
                setVehicleEngineState ( vehicleObject, false )
                -- Apply retrieved paint job
                setVehiclePaintjob(vehicleObject, paintJob)
                setVehicleVariant(vehicleObject, vehicle.varient1, vehicle.varient2)

                setElementData(vehicleObject, "fuel", fuel)
                setElementHealth(vehicleObject, health)
                setVehicleHeadLightColor(vehicleObject, vehicle.headlightR, vehicle.headlightG, vehicle.headlightB)

                -- Apply retrieved upgrades
                if upgrades then
                    for _, upgradeID in ipairs(upgrades) do
                        addVehicleUpgrade(vehicleObject, upgradeID)
                    end
                end
                setElementData(vehicleObject, 'id', vehicle.id)
                setElementData(vehicleObject, "owner", vehicle.owner)
            end 
        end
    end
end

addEventHandler('onResourceStart', resourceRoot, function()
    dbQuery(loadAllVehicles, db, 'SELECT * FROM vehicles')
    outputServerLog("[VEHICLES] Vehicles Resource started successfully")
end)

---------------------------------------------------------
-- TO UPDATE VEHICLE POSTION TO DATABASE
---------------------------------------------------------

-- Event for resource stop
addEventHandler('onResourceStop', resourceRoot, function()
    local vehicles = getElementsByType('vehicle')
    
    for index, vehicle in pairs(vehicles) do
        local id = getElementData(vehicle, 'id')
        if id then
            local x, y, z = getElementPosition(vehicle)
            local rx, ry, rz = getElementRotation(vehicle)
            
            -- Get the vehicle color
            local colors = {getVehicleColor(vehicle, true)}
            local vehicleColors = toJSON({
                color1 = {r = colors[1], g = colors[2], b = colors[3]},
                color2 = {r = colors[4], g = colors[5], b = colors[6]},
                color3 = {r = colors[7], g = colors[8], b = colors[9]},
                color4 = {r = colors[10], g = colors[11], b = colors[12]}
            })
            --get the vehicle fuel
            local currentFuel = getElementData(vehicle, "fuel")

            --get vehicle health
            local vehicleHealth = getElementHealth(vehicle)

            --vehicle headlight colour
            local headlightR, headlightG, headlightB = getVehicleHeadLightColor(vehicle)

            -- Get the paint job and vehicle upgrades
            local paintJob = getVehiclePaintjob(vehicle)
            local upgrades = toJSON(getVehicleUpgrades(vehicle))

            local updateQuery = 'UPDATE vehicles SET x = ?, y = ?, z = ?, rx = ?, ry = ?, rz = ?, color = ?, paintjob = ?,fuel = ?, health = ?, headlightR = ?, headlightG = ?, headlightB = ?, upgrades = ? WHERE id = ?'
            
            -- Update the database with the current vehicle location, rotation, color, paint job, and upgrades
            dbExec(db, updateQuery, x, y, z, rx, ry, rz, vehicleColors, paintJob, currentFuel, vehicleHealth, headlightR, headlightG, headlightB, upgrades, id)
        end
    end
end)

function VehicleSavetoDB(vehicle)
    local id = getElementData(vehicle, 'id')
    if id then
        local x, y, z = getElementPosition(vehicle)
        local rx, ry, rz = getElementRotation(vehicle)
        
        -- Get the vehicle color
        local colors = {getVehicleColor(vehicle, true)}
        local vehicleColors = toJSON({
            color1 = {r = colors[1], g = colors[2], b = colors[3]},
            color2 = {r = colors[4], g = colors[5], b = colors[6]},
            color3 = {r = colors[7], g = colors[8], b = colors[9]},
            color4 = {r = colors[10], g = colors[11], b = colors[12]}
        })
        --get the vehicle fuel
        local currentFuel = getElementData(vehicle, "fuel")

        --get vehicle health
        local vehicleHealth = getElementHealth(vehicle)

        --vehicle headlight colour
        local headlightR, headlightG, headlightB = getVehicleHeadLightColor(vehicle)

        -- Get the paint job and vehicle upgrades
        local paintJob = getVehiclePaintjob(vehicle)
        local upgrades = toJSON(getVehicleUpgrades(vehicle))

        local updateQuery = 'UPDATE vehicles SET x = ?, y = ?, z = ?, rx = ?, ry = ?, rz = ?, color = ?, paintjob = ?,fuel = ?, health = ?, headlightR = ?, headlightG = ?, headlightB = ?, upgrades = ? WHERE id = ?'
        
        -- Update the database with the current vehicle location, rotation, color, paint job, and upgrades
        dbExec(db, updateQuery, x, y, z, rx, ry, rz, vehicleColors, paintJob, currentFuel, vehicleHealth, headlightR, headlightG, headlightB, upgrades, id)
    end
end 

addEventHandler('onPlayerVehicleExit', root, VehicleSavetoDB)

---------------------------------------------------------
--To delete a Vehicle from the Database
---------------------------------------------------------

function deleteVehicleFromDB(vehicle)
    local id = getElementData(vehicle, 'id')

    -- Delete the vehicle from the world
    destroyElement(vehicle)

    -- Delete the vehicle from the database
    dbExec(db, 'DELETE FROM vehicles WHERE id = ?', id)
    outputServerLog("[DELETED] Vehicle with ID: " .. tostring(id) .. " has been deleted from the database.")
end

function onDeleteVehicleCommand(player, command)
    local vehicle = getPedOccupiedVehicle(player)
    if vehicle and getElementType(vehicle) == "vehicle" then
        deleteVehicleFromDB(vehicle)
        outputChatBox("Vehicle deleted.", player, 0, 255, 0, true)
    else
        outputChatBox("You are not inside a vehicle.", player, 255, 0, 0, true)
    end
end

addCommandHandler('deleteVehicle', onDeleteVehicleCommand, false, false)

---------------------------------------------------------
--TO GET THE VEHICLE ID :)
---------------------------------------------------------
function GetVehicleID(player, command)
    local vehicle = getPedOccupiedVehicle(player)
    if vehicle and getElementType(vehicle) == 'vehicle' then
        local id = getElementData(vehicle, 'id')
        outputChatBox("VEHICLE UNIQUE ID :" .. tostring(id) .. ".", player, 152, 152, 152, true)
    else
        outputChatBox("You are not inside a vehicle.", player, 255, 0, 0, true)
    end 
end 

addCommandHandler('GetVehicleId', GetVehicleID, false, false)
addCommandHandler('vid', GetVehicleID, false, false)

