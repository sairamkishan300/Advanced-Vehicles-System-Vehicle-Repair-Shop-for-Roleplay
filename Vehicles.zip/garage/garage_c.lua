-- Remove all outputChatBox debug messages and any other debug code from the client script. Only keep the core logic for the garage UI and data transfer.

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
--NOTIFICATION BAR SYSTEM
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------

function showgaragebar()
    local sound = playSound("[sounds]/bell.mp3")
    setSoundVolume(sound, 0.5)
    addEventHandler("onClientRender", root, Garagebar)
end 

function hidegaragebar()
    isSpeedoShown = false
    removeEventHandler("onClientRender", root, Garagebar)
end

local alpha = 1
function Garagebar()
    local screenW, screenH = guiGetScreenSize()
    if not isPedInVehicle ( localPlayer ) then
        dxDrawImage(screenW * 0.8625, screenH * 0.7657, screenW * 0.1375, screenH * 0.2435, ":Vehicles/[images]/garageopen.png", 0, 0, 0, tocolor(255, 254, 254, 206), false)
    else
        dxDrawImage(screenW * 0.8625, screenH * 0.7657, screenW * 0.1375, screenH * 0.2435, ":Vehicles/[images]/garageclose.png", 0, 0, 0, tocolor(255, 254, 254, 206), false)
    end
end

-- Event triggered from the server to display the notification
addEvent("garageNotification:show", true)
addEventHandler("garageNotification:show", resourceRoot, showgaragebar)

addEvent("garageNotification:hide", true)
addEventHandler("garageNotification:hide", resourceRoot, hidegaragebar)

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
--VEHICLE LOCK SYSTEM
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
local screenW, screenH = guiGetScreenSize()

function lockbar()
    dxDrawImage(screenW * 0.4802, screenH * 0.8991, screenW * 0.0339, screenH * 0.0481, ":Vehicles/[images]/lock.png", 0, 0, 0, tocolor(1, 0, 0, 254), false)
end

function unlockbar()
    dxDrawImage(screenW * 0.4802, screenH * 0.8991, screenW * 0.0339, screenH * 0.0481, ":Vehicles/[images]/unlock.png", 0, 0, 0, tocolor(1, 0, 0, 254), false)
end


function KeySound(text)
    local localPlayer = getLocalPlayer()
    setPedAnimation(localPlayer, "heist9", "use_swipecard", -1, false, false, false, false)
    local sound = playSound("[sounds]/key.mp3")
    setSoundVolume(sound, 0.1)
        if text == "lock" then 
            addEventHandler("onClientRender", root, lockbar)
            setTimer(function()
                removeEventHandler("onClientRender", root, lockbar)
            end, 2000, 1)
        else 
            addEventHandler("onClientRender", root, unlockbar)
            setTimer(function()
                removeEventHandler("onClientRender", root, unlockbar)
            end, 2000, 1)
    end
end

-- event for key sound
addEvent("Vehicle:keysound", true)
addEventHandler("Vehicle:keysound", resourceRoot, KeySound)


-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
--KEY PRESSING EVENTS
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
cooldowntime = 300
cooldowns = {}

function removeCooldown(thePlayer)
	if cooldowns[thePlayer] then
		cooldowns[thePlayer] = false
	end
end

function playerPressedKey(button, press)
    if isChatBoxInputActive() then
        return 
    end
    if press then
        if cooldowns[source] then
            cooldowns[source] = setTimer(removeCooldown, cooldowntime, 1, source)
            return
        end
        if button == "e" then
            cooldowns[source] = true
            local playerName = getPlayerName(localPlayer)
            triggerServerEvent('onClientRequestData', localPlayer)
            triggerServerEvent('clientImpoundRequestData', localPlayer)
            cooldowns[source] = setTimer(removeCooldown, cooldowntime, 1, source)
        end
        if button == "g" then
            triggerServerEvent("vehicle:DestroyPlayerVehicle", localPlayer)
            cooldowns[source] = setTimer(removeCooldown, cooldowntime, 1, source)
        end
        if button == "u" then
            cooldowns[source] = true
            triggerServerEvent("vehicle:locktoggle", localPlayer)
            cooldowns[source] = setTimer(removeCooldown, cooldowntime, 1, source)
        end
    end
end
addEventHandler("onClientKey", root, playerPressedKey)

-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
--VEHICLE GARAGE PANEL CREATION
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
local scrollPane
local vehicleWindow = nil
local vehicleID = nil

-- Modern HTML Garage UI integration
local garageBrowser = nil
local garageBrowserShowing = false

function showGarageHTML(data)
    if garageBrowserShowing then return end
    local screenW, screenH = guiGetScreenSize()
    garageBrowser = guiCreateBrowser(0, 0, screenW, screenH, true, true, false)
    local theBrowser = guiGetBrowser(garageBrowser)
    addEventHandler("onClientBrowserCreated", theBrowser, function()
        loadBrowserURL(theBrowser, "http://mta/local/garage/html/garage.html")
    end, false)
    addEventHandler("onClientBrowserDocumentReady", theBrowser, function()
        -- Manually build a JS array string from the data table
        local jsArray = "["
        if type(data) == "table" then
            for i, v in ipairs(data) do
                if i > 1 then jsArray = jsArray .. "," end
                jsArray = jsArray .. string.format("{\"id\":%s,\"numberPlate\":\"%s\",\"displayName\":\"%s\",\"health\":%s,\"fuel\":%s}",
                    tostring(v.id or 0),
                    tostring(v.numberPlate or ""),
                    tostring(v.displayName or ""),
                    tostring(v.health or 1000),
                    tostring(v.fuel or 100)
                )
            end
        end
        jsArray = jsArray .. "]"
        executeBrowserJavascript(theBrowser, "window.setGarageData(" .. jsArray .. ");")
    end, false)
    showCursor(true)
    guiSetInputMode("no_binds")
    garageBrowserShowing = true
end

function hideGarageHTML()
    if garageBrowser and isElement(garageBrowser) then
        destroyElement(garageBrowser)
        garageBrowser = nil
        garageBrowserShowing = false
        showCursor(false)
        guiSetInputMode("allow_binds")
    end
end

addEvent("garage:close", true)
addEventHandler("garage:close", root, function()
    hideGarageHTML()
end)

addEvent("garage:spawnVehicle", true)
addEventHandler("garage:spawnVehicle", root, function(vehicleId)
    triggerServerEvent('vehicle:SpawnPlayerVehicle', localPlayer, tonumber(vehicleId))
    hideGarageHTML()
end)

addEvent("onDataReceived", true)
addEventHandler("onDataReceived", root, function(data)
    _G.lastGarageData = data
    showGarageHTML(data)
end)

--[[ Old GUI code (commented out)
function createVehicleButtons(data)
    if isPedInVehicle(localPlayer) then return end 
    if isElement(vehicleWindow) then
        destroyElement(vehicleWindow)
        showCursor(false)
        guiSetInputMode('allow_binds')
        vehicleID = nil
        vehicleWindow = nil
        return
    end
    local screenWidth, screenHeight = guiGetScreenSize()

    -- Create the main window
    local windowWidth, windowHeight = screenWidth * 0.27, screenHeight* 0.52

    --vehicleWindow = guiCreateWindow(windowX, windowY, windowWidth, windowHeight, "Boologam Vehicle Garage", false)
    --guiSetAlpha(vehicleWindow, 0)

    vehicleWindow = guiCreateStaticImage(screenWidth * 0.6, screenHeight * 0.2, windowWidth - 100, windowHeight + 120, "[images]/box.png", false)
    guiSetAlpha(vehicleWindow, 0.75)

    guiWindowSetMovable(vehicleWindow, false)
    guiWindowSetSizable(vehicleWindow, false) -- Corrected function name
    showCursor(true)
    guiSetInputMode('no_binds')


--title text 
    local titleText = guiCreateLabel(47/1920 * screenWidth, 10/1080 * screenHeight, windowWidth - (100/1920 * screenWidth), windowHeight, '  GARAGE', false, vehicleWindow)
    guiLabelSetHorizontalAlign(titleText,"left")
    local titlefont = guiCreateFont("[font]/banner.ttf", 40)
        guiSetFont(titleText, titlefont)



--create scroll pane
    local scrollPane = guiCreateScrollPane(45/1920 * screenWidth, 70/1080 * screenHeight, windowWidth * 2, windowHeight * 0.72, false, vehicleWindow)




-- Create a close button at the bottom
    local closeButton = guiCreateButton(300/1920 * screenWidth, 10/1080 * screenHeight, 35/1920 * screenWidth, 35/1080 * screenHeight, "X", false, vehicleWindow)
    guiSetFont(closeButton, "default-bold-small")
    addEventHandler('onClientGUIClick', closeButton, function()
        destroyElement(vehicleWindow)
        showCursor(false)
        vehicleID = nil
        guiSetInputMode('allow_binds')
        vehicleWindow = nil
        return
    end, false)

-- Create a ForceSpawn button at the bottom
    addEventHandler('onClientGUIClick', ForceSpawn, function()
        local playerName = getPlayerName(localPlayer)
        if vehicleID then 
            triggerServerEvent('vehicle:ForceSpawnPlayerVehicle', localPlayer, vehicleID)
            destroyElement(vehicleWindow)
            showCursor(false)
            vehicleID = nil
            guiSetInputMode('allow_binds')
            vehicleWindow = nil
        else
            return 
        end

    end, false)  

-- CREATE BUTTONS FOR EACH VEHICLE
    if data and #data > 0 then
        for i, vehicleData in ipairs(data) do
            ButtonContent = "ID: " .. vehicleData.id .. " | " .. vehicleData.displayName
            local button = guiCreateButton(10/1920 * screenWidth, (i - 1) * (45/1080 * screenHeight), windowWidth * 0.553, 42/1080 * screenHeight, ButtonContent, false, scrollPane)
            local myFont = guiCreateFont("[font]/whale.otf", 20)
            guiSetFont(button, myFont)
            --guiSetProperty(button, "NormalTextColour", "FF0BC5F4")
            --guiSetProperty(button, "NormalTextColour", "FFFFFFFF") 
            addEventHandler("onClientGUIClick", button, function()
                vehicleID = vehicleData.id
                triggerServerEvent('vehicle:SpawnPlayerVehicle', localPlayer, vehicleID)
                destroyElement(vehicleWindow)
                showCursor(false)
                vehicleID = nil
                guiSetInputMode('allow_binds')
                vehicleWindow = nil
            end, false)
        end
    else
        destroyElement(vehicleWindow)
        showCursor(false)
        vehicleID = nil
        guiSetInputMode('allow_binds')
        vehicleWindow = nil
        notificationBar("Can't Open", "You don't own any vehicles, first earn, then buy :)")
    end

-- MOUSE SCROLL SYSTEM 
    addEventHandler( "onClientMouseWheel", root,
    function ( up_down )
        if vehicleWindow then 
            local currentScrollPos = guiScrollPaneGetVerticalScrollPosition( scrollPane )
            guiScrollPaneSetVerticalScrollPosition( scrollPane, currentScrollPos - (up_down * 7.5) )
        end
    end)
end
]]

-------------------------------------------------------------------------------------------------------
--IMAGE IN BLIP
-------------------------------------------------------------------------------------------------------
GarageLocations = {}

addEvent("receiveGarageLocations", true)
addEventHandler("receiveGarageLocations", root, function(data)
    if type(data) == "table" then
        GarageLocations = data
    end
end)



local garagemTxd = dxCreateTexture("[images]/garage.png")

tick9 = getTickCount()
addEventHandler('onClientRender', root, 
function()
    local Op1, Op2 = interpolateBetween(0.4, 1.4, 0, 0.7, 1.7, 0, ((getTickCount() - tick9) / 1500), "SineCurve")
    local x, y, z = getCameraMatrix()
    
    for _, marker in ipairs(GarageLocations) do
        local markerX, markerY, markerZ = marker.posX, marker.posY, marker.posZ
        local distance_1 = getDistanceBetweenPoints3D(x, y, z, markerX, markerY, markerZ)
        
        if distance_1 <= 30 then
            dxDrawMaterialLine3D(markerX, markerY, markerZ + Op1, markerX, markerY, markerZ + Op2, garagemTxd, 1, tocolor(configPontos.corImagem[1], configPontos.corImagem[2], configPontos.corImagem[3], 255))
        end
    end
end)




-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
--AUTHOR: SAI RAM KISHAN
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------