let vehicles = [];

function garageDebug(msg) {
    if (typeof mta !== 'undefined') mta.triggerEvent('garage:jsDebug', msg);
}
garageDebug('Garage JS loaded and running!');

window.setGarageData = function(data) {
    vehicles = data;
    const ids = vehicles.map(v => v.id).join(', ');
    garageDebug('Vehicle IDs received: [' + ids + '] (Total: ' + vehicles.length + ')');
    renderVehicleList();
};

function renderVehicleList() {
    const list = document.getElementById('vehicle-list');
    list.innerHTML = '';
    if (!vehicles.length) {
        list.innerHTML = '<div style="color:#f45b0b;text-align:center;">No vehicles found.</div>';
        return;
    }
    vehicles.forEach(vehicle => {
        const health = typeof vehicle.health === 'number' ? vehicle.health : 1000;
        const fuel = typeof vehicle.fuel === 'number' ? vehicle.fuel : 100;
        const card = document.createElement('div');
        card.className = 'vehicle-card';
        card.innerHTML = `
            <div class="vehicle-main">
                <span class="vehicle-id">ID: ${vehicle.id}</span>
                <span class="vehicle-plate">${vehicle.numberPlate ? ' | Plate: ' + vehicle.numberPlate : ''}</span>
                <span class="vehicle-name">${vehicle.displayName ? ' | ' + vehicle.displayName : ''}</span>
            </div>
            <div class="vehicle-details">
                <div class="bar-label">Health</div>
                <div class="bar"><div class="bar-inner health-bar" style="width: ${Math.max(0, Math.min(100, health / 10))}%;"></div></div>
                <div class="bar-label">Fuel</div>
                <div class="bar"><div class="bar-inner fuel-bar" style="width: ${Math.max(0, Math.min(100, fuel))}%;"></div></div>
            </div>
        `;
        card.onclick = function() {
            if (typeof mta !== 'undefined') mta.triggerEvent('garage:spawnVehicle', vehicle.id);
        };
        list.appendChild(card);
    });
}

document.getElementById('close-btn').onclick = function() {
    if (typeof mta !== 'undefined') mta.triggerEvent('garage:close');
}; 