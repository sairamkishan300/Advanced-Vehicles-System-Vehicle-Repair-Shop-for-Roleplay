-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
--VEHICLE GARAGE PANEL CREATION
-------------------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------------------
local scrollPane
local vehicleWindow = nil
local vehicleID = nil

function ImpoundPanel(data)
    if isPedInVehicle(localPlayer) then return end 
    if isElement(vehicleWindow) then
        destroyElement(vehicleWindow)
        showCursor(false)
        guiSetInputMode('allow_binds')
        vehicleID = nil
        vehicleWindow = nil
        return
    end
    local screenWidth, screenHeight = guiGetScreenSize()

    -- Create the main window
    local windowWidth, windowHeight = screenWidth * 0.27, screenHeight* 0.52

    --vehicleWindow = guiCreateWindow(windowX, windowY, windowWidth, windowHeight, "Boologam Vehicle Garage", false)
    --guiSetAlpha(vehicleWindow, 0)

    vehicleWindow = guiCreateStaticImage(screenWidth * 0.6, screenHeight * 0.2, windowWidth - (100 /1920 * screenWidth), windowHeight + (120/1080 * screenHeight ), "[images]/box.png", false)
    guiSetAlpha(vehicleWindow, 0.75)

    guiWindowSetMovable(vehicleWindow, false)
    guiWindowSetSizable(vehicleWindow, false) -- Corrected function name
    showCursor(true)
    guiSetInputMode('no_binds')


--title text 
    local titleText = guiCreateLabel(47/1920 * screenWidth, 10/1080 * screenHeight, windowWidth - (100/1920 * screenWidth), windowHeight/1080 * screenHeight, ' IMPOUND', false, vehicleWindow)
    guiLabelSetHorizontalAlign(titleText,"left")
    local titlefont = guiCreateFont("[font]/banner.ttf", 40)
        guiSetFont(titleText, titlefont)



--create scroll pane
    local scrollPane = guiCreateScrollPane(45/1920 * screenWidth, 70/1080 * screenHeight, windowWidth * 2, windowHeight * 0.72, false, vehicleWindow)




-- Create a close button at the bottom
    local closeButton = guiCreateButton(300/1920 * screenWidth, 10/1080 * screenHeight, 35/1920 * screenWidth, 35/1080 * screenHeight, "X", false, vehicleWindow)
    guiSetFont(closeButton, "default-bold-small")
    addEventHandler('onClientGUIClick', closeButton, function()
        destroyElement(vehicleWindow)
        showCursor(false)
        vehicleID = nil
        guiSetInputMode('allow_binds')
        vehicleWindow = nil
        return
    end, false)

-- CREATE BUTTONS FOR EACH VEHICLE
    if data and #data > 0 then
        for i, vehicleData in ipairs(data) do
            ButtonContent = "ID: " .. vehicleData.id .. " | Vehicle: " .. getVehicleNameFromModel(vehicleData.model)
            local button = guiCreateButton(10/1920 * screenWidth, (i - 1) * (45/1080 * screenHeight), windowWidth * 0.553, 42, ButtonContent, false, scrollPane)
            local myFont = guiCreateFont("[font]/whale.otf", 20)
            guiSetFont(button, myFont)
            --guiSetProperty(button, "NormalTextColour", "FF0BC5F4")
            --guiSetProperty(button, "NormalTextColour", "FFFFFFFF") 
            addEventHandler("onClientGUIClick", button, function()
                vehicleID = vehicleData.id
                triggerServerEvent('vehicle:ForceSpawnPlayerVehicle', localPlayer, vehicleID)
                destroyElement(vehicleWindow)
                showCursor(false)
                vehicleID = nil
                guiSetInputMode('allow_binds')
                vehicleWindow = nil
                end, false)
                
        end
    else
        destroyElement(vehicleWindow)
        showCursor(false)
        vehicleID = nil
        guiSetInputMode('allow_binds')
        vehicleWindow = nil
        notificationBar("Can't Open", "You don't own any vehicles, first earn, then buy :)")
    end

-- MOUSE SCROLL SYSTEM 
    addEventHandler( "onClientMouseWheel", root,
    function ( up_down )
        if vehicleWindow then 
            local currentScrollPos = guiScrollPaneGetVerticalScrollPosition( scrollPane )
            guiScrollPaneSetVerticalScrollPosition( scrollPane, currentScrollPos - (up_down * 7.5) )
        end
    end)

end


addEvent("ImpoundOpenWithData", true)
addEventHandler("ImpoundOpenWithData", root, function(data)
    -- Create GUI with the received data
    ImpoundPanel(data)
end)



-------------------------------------------------------------------------------------------------------
--IMAGE IN BLIP
-------------------------------------------------------------------------------------------------------
ImpoundLocations = {}

addEvent("receiveImpoundLocations", true)
addEventHandler("receiveImpoundLocations", root, function(data)
    if type(data) == "table" then
        ImpoundLocations = data
    end
end)



local garagemTxd = dxCreateTexture("[images]/impound.png")

tick9 = getTickCount()
addEventHandler('onClientRender', root, 
function()
    local Op1, Op2 = interpolateBetween(0.4, 1.4, 0, 0.7, 1.7, 0, ((getTickCount() - tick9) / 1500), "SineCurve")
    local x, y, z = getCameraMatrix()
    
    for _, marker in ipairs(ImpoundLocations) do
        local markerX, markerY, markerZ = marker.posX, marker.posY, marker.posZ
        local distance_1 = getDistanceBetweenPoints3D(x, y, z, markerX, markerY, markerZ)
        
        if distance_1 <= 30 then
            dxDrawMaterialLine3D(markerX, markerY, markerZ + Op1, markerX, markerY, markerZ + Op2, garagemTxd, 1, tocolor(configPontos.corImagem[1], configPontos.corImagem[2], configPontos.corImagem[3], 255))
        end
    end
end)