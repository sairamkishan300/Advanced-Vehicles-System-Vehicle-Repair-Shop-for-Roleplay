function checkFuel(vehicle)
    local currentFuel = getElementData(vehicle, "fuel")
		if ( currentFuel == false ) then
            setElementData(vehicle, "fuel", 100)
            setVehicleEngineState ( vehicle, true )
        else
            if currentFuel <= 1 then
                setVehicleEngineState ( vehicle, false )
            else
                setVehicleEngineState ( vehicle, true )
            end 
        end 
    end

-----------------------------------------------------------------------------
addCommandHandler('rotate', function(player)
    setVehicleRotation180(player)
end, false, false)

function setVehicleRotation180(player)
    local vehicle = getPedOccupiedVehicle(player)
    if vehicle then
        setElementRotation(vehicle, 0, 180, 0) -- Set rotation to 180 degrees
        outputServerLog("Vehicle rotation set to 180 degrees!", player)
    else
        outputServerLog("You are not in a vehicle!", player)
    end
end

addCommandHandler("rot", setVehicleRotation180, true)

-----------------------------------------------------------------------------
MinDamageHealth = 255
-----------------------------------------------------------------------------
function cancelDamage()
    setTimer(function(veh)
    if isElement(veh) and getElementHealth(veh) <= MinDamageHealth then
        setElementHealth(veh, MinDamageHealth + 0.5)
        setVehicleDamageProof(veh, true)
        setVehicleEngineState(veh, false)
        end
    end, 50, 0, source)
end
addEventHandler("onVehicleDamage", root, cancelDamage)

-----------------------------------------------------------------------------

function checkDamage(vehicle)
    local vehicleHealth = getElementHealth(vehicle) 
    if vehicleHealth <= MinDamageHealth + 1 then
        setVehicleEngineState(vehicle, false)
        cancelEvent()
    else
        checkFuel(vehicle)
    end
end

addEventHandler("onPlayerVehicleEnter", root, checkDamage)

function turnEngineOff ( theVehicle, leftSeat, jackerPlayer )
    if leftSeat == 0 and not jackerPlayer then
        setVehicleEngineState ( theVehicle, false )
    end
end
addEventHandler ( "onPlayerVehicleExit", root, turnEngineOff )


-----------------------------------------------------------------------------
-- CANCEL VEHICLE ENTER
-----------------------------------------------------------------------------

function checkVehicleEnter(player)
    if isElementFrozen ( player ) then
        outputChatBox("sorry", player)
        cancelEvent()
        return
    end
end
addEventHandler ( "onVehicleEnter", getRootElement(), checkVehicleEnter )
-----------------------------------------------------------------------------
--REPAIR VEHICLE
-----------------------------------------------------------------------------
addEvent('RepairVeh:done', true)
addEventHandler('RepairVeh:done', root, function(nearestVehicle)
    local player = source
    local currentHealth = getElementHealth(nearestVehicle)
    
    -- Calculate new health
    local newHealth = currentHealth + 200
    
    -- If new health exceeds 1000, fully repair the vehicle
    if newHealth > 1000 then
        fixVehicle(nearestVehicle)
    else
        setElementHealth(nearestVehicle, newHealth)
    end

    -- Ensure vehicle is not damage-proof and unfreeze player
    setVehicleDamageProof(nearestVehicle, false)
    setElementFrozen(player, false)
end)


function RepairVehicle(player)
    if isPedInVehicle(player) then
        outputChatBox("You can't repair a vehicle from inside a vehicle")
        return
    end
    local x, y, z = getElementPosition(player) 
    local vehicles = getElementsByType("vehicle") 
    local nearestDist = 5
    local nearestVehicle = nil 
    
    for _, vehicle in ipairs(vehicles) do
        local vx, vy, vz = getElementPosition(vehicle) 
        local distance = getDistanceBetweenPoints3D(x, y, z, vx, vy, vz) 
        
        if distance < nearestDist then
            nearestDist = distance 
            nearestVehicle = vehicle 
        end
    end
    if isElement(nearestVehicle) then
        setElementFrozen(player, true)
        triggerClientEvent(player, "repairVeh:start", player, nearestVehicle)
    else
        setElementFrozen(player, false)
        outputChatBox("No vehicle near you to repair")
    end
end 

-----------------------------------------------------------------------------
-- FUEL VEHICLE
-----------------------------------------------------------------------------


addCommandHandler('getfuel', function(player, command)

    --GIVE PLAYER GAS CAN FROM INVENTORY
    local next = exports.Reswininv
    next:giveItem(player, "Gasolina", 1)

end, false, false )



addEvent('fuelVehicle:done', true)
addEventHandler('fuelVehicle:done', root, function(nearestVehicle, amount)
    local player = source

    -- Update the vehicle's fuel data
    setElementData(nearestVehicle, "fuel", amount)
    
    -- Additional logic
    setVehicleDamageProof(nearestVehicle, false)
    setElementFrozen(player, false)

end)


local FuelPricePerLitre = 10

function FuelVehicle(player, amount)
    if isPedInVehicle(player) then
        outputChatBox("You can't fuel a vehicle from inside a vehicle")
        return
    end
    if not amount then 
        amount = 100
    end
    local x, y, z = getElementPosition(player)
    local vehicles = getElementsByType("vehicle") 
    local nearestDist = 5
    local nearestVehicle = nil
    
    for _, vehicle in ipairs(vehicles) do
        local vx, vy, vz = getElementPosition(vehicle)
        local distance = getDistanceBetweenPoints3D(x, y, z, vx, vy, vz)
        
        if distance < nearestDist then
            nearestDist = distance
            nearestVehicle = vehicle 
        end
    end
    if isElement(nearestVehicle) then


        local currentFuel = getElementData(nearestVehicle, "fuel")
    
        -- Calculate the new fuel amount and cap it at 100 if necessary
        local fuelAmount = tonumber(currentFuel + amount)
        if fuelAmount > 100 then
            fuelAmount = 100
        end

        fuelFinalPrice = tonumber(amount*FuelPricePerLitre)
        
        local account = getPlayerAccount(player)
        local accountName = getAccountName(account)

        setElementFrozen(player, true)
        triggerClientEvent(player, "fuelveh:start", player, nearestVehicle, fuelAmount)
    else
        setElementFrozen(player, false)
        outputChatBox("No vehicle near you to fuel")
    end
        
end

----------------------------------------------------------------

addCommandHandler('vseat', function(player, command)
    if isPedInVehicle(player) then
        local vehicle = getPedOccupiedVehicle(player)
        numseats = getVehicleMaxPassengers ( vehicle ) -- get the passenger seat count
        outputChatBox ( "This vehicle supports " .. numseats .. " passengers." , player)
    end
    end, false, false )

---------------------------------------------------------------

---------------------------------------------------------
--Vehicle lock system
---------------------------------------------------------
function triggerKeySound(player, message)
    triggerClientEvent(player, "Vehicle:keysound", resourceRoot, message)
end

addEvent('vehicle:locktoggle', true)
addEventHandler('vehicle:locktoggle', root, 
function ()
    local player = source
    local x, y, z = getElementPosition(player) -- Get player's position
    local vehicles = getElementsByType("vehicle") -- Get all vehicle elements
    local nearestDist = 4 -- Set initial distance to a very high value
    local nearestVehicle = nil -- Variable to store the nearest vehicle
    
    for _, vehicle in ipairs(vehicles) do
        local vx, vy, vz = getElementPosition(vehicle) -- Get vehicle's position
        local distance = getDistanceBetweenPoints3D(x, y, z, vx, vy, vz) -- Calculate distance
        
        if distance < nearestDist then
            nearestDist = distance -- Update nearest distance
            nearestVehicle = vehicle -- Set nearest vehicle
        end
    end
    
    if nearestVehicle then
        local owner = getElementData(nearestVehicle, "owner")
        if owner then
            local playerName = getAccountName(getPlayerAccount(player))
            if playerName == owner or owner == "kkrp3000" then
                if isVehicleLocked(nearestVehicle) then
                    setVehicleLocked(nearestVehicle, false)
                    triggerKeySound(player, "unlock")
                else
                    -- Close all doors
                    for door = 0, 5 do
                        setVehicleDoorOpenRatio(nearestVehicle, door, 0)
                    end
                    setVehicleLocked(nearestVehicle, true)
                    triggerKeySound(player, "lock")
                end
            else
                triggerClientEvent(player, "add:notification", client, "You don't have the key", "You need to be the owner of the vehicle to lock or unlock it", "error",true)
            end
        else
            triggerClientEvent(player, "add:notification", client, "The vehicle has no keys", "This is a public vehicle and no one can lock or unlock it", "error",true)
        end
    end
end)

-- Event handler to prevent player from exiting a locked vehicle
function preventPlayerExitIfLocked(player, seat, jacked)
    local vehicle = getPedOccupiedVehicle(player)
    if vehicle and isVehicleLocked(vehicle) then
        cancelEvent()
    end
end

addEventHandler("onVehicleStartExit", getRootElement(), preventPlayerExitIfLocked)

---------------------------------------------------------
---------------------------------------------------------

addCommandHandler('hl', function(player, command, r, g, b)
    local vehicle = getPedOccupiedVehicle(player)
    if vehicle then
        setVehicleHeadLightColor(vehicle, r, g, b)
    end
end)

----------------------------------------------------------
----------------------------------------------------------
--ANIMATION HANDLE IN SERVER SIDE
----------------------------------------------------------
----------------------------------------------------------
addEvent("startFuelingAnimation", true)
addEvent("startRepairAnimation", true)
addEvent("stopAnimation", true)

function playFuelingAnimation(player)
    if isElement(player) then
        setPedAnimation(player, "BOMBER", "BOM_Plant", -1, false, false, false, false)
    end
end
addEventHandler("startFuelingAnimation", root, playFuelingAnimation)

function playRepairAnimation(player)
    if isElement(player) then
        setPedAnimation(player, "CAR", "Fixn_Car_Loop", -1, true, false, false, false)

    end
end
addEventHandler("startRepairAnimation", root, playRepairAnimation)

function stopPlayerAnimation(player)
    if isElement(player) then
        setPedAnimation(player) -- Stops the animation
    end
end
addEventHandler("stopAnimation", root, stopPlayerAnimation)

