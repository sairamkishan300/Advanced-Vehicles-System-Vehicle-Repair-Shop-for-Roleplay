--FUEL SYSTEM AND DAMAGE SYSTEM

local screenW, screenH = guiGetScreenSize()

GUIEditor = {
    staticimage = {}
}
function CreateImages()
    GUIEditor.staticimage[1] = guiCreateStaticImage(859, 983, 34, 30, ":Vehicles/[images]/fuel.png", false)
    GUIEditor.staticimage[2] = guiCreateStaticImage(960, 983, 29, 30, ":Vehicles/[images]/health.png", false) 
end

function destroyImages()
    destroyElement(GUIEditor.staticimage[1])
    destroyElement(GUIEditor.staticimage[2])
end


-- Function to update fuel level based on vehicle speed
function updateFuel(vehicle)
    if getVehicleEngineState(vehicle) == true then
        -- Get vehicle model and determine fuel consumption
        local vehicleModel = getElementModel(vehicle)
        local fuelConsumption = fuelConsumptionRates[vehicleModel] or defaultFuelConsumption

        -- Get current fuel level
        local currentFuel = getElementData(vehicle, "fuel") or 0 

        -- Decrease fuel based on vehicle model consumption rate
        currentFuel = currentFuel - fuelConsumption

        -- Ensure fuel level doesn't go below zero
        if currentFuel < 0 then
            currentFuel = 0
            setVehicleEngineState(vehicle, false)
        end

        -- Update the fuel level for the vehicle
        setElementData(vehicle, "fuel", currentFuel)

        -- Call the function again after a delay to continue updating the fuel
        setTimer(updateFuel, 1000, 1, vehicle) -- Pass 'vehicle' to the function in the timer
    end
end

addEventHandler("onClientPlayerVehicleEnter", root, function(vehicle, seat)
    if source == localPlayer then
        updateFuel(vehicle)
    end
end)

addEventHandler("onClientPlayerVehicleExit", root, function(vehicle, seat)
    if source == localPlayer then
        updateFuel(vehicle)
    end
end)

-----------------------------------------------------------------------------------

-- FUEL BAR LOADING ..
local cooldown = false
local progress = 0
local endValue = 0.1422--0.2682
local progress2 = 0.4135--0.3589
local endValue2 = 0.5557--0.6297
local startTime = getTickCount()
function updateProgress()
    local elapsedTime = getTickCount() - startTime
    if elapsedTime <= duration then
        progress = (endValue / duration) * elapsedTime

        local timeRatio = elapsedTime / duration
        progress2 = 0.4135 + (endValue2 - 0.4135) * timeRatio

    else
        progress = endValue
        removeEventHandler("onClientRender", root, updateProgress)

        progress2 = endValue2
        removeEventHandler("onClientRender", root, updateProgress)
        removeEventHandler("onClientRender", root, fuelbar)

    end
end
function fuelbar()
    dxDrawRectangle(screenW * 0.4135, screenH * 0.8454, screenW * 0.1526, screenH * 0.0250, tocolor(0, 0, 0, 180), false)
    dxDrawRectangle(screenW * 0.4188, screenH * 0.8546, screenW * 0.1422, screenH * 0.0065, tocolor(154, 154, 154, 180), false)
    dxDrawRectangle(screenW * 0.4188, screenH * 0.8546, screenW * progress, screenH * 0.0065, tocolor(254, 254, 254, 180), false)
    dxDrawImage(screenW * progress2, screenH * 0.8444, screenW * 0.0172, screenH * 0.0259, ":Vehicles/[images]/fuel.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
end

function fuelvehicle(nearestVehicle, amount)
    triggerServerEvent('fuelVehicle:done', localPlayer, nearestVehicle, amount)
end


addEvent("fuelveh:start", true)
addEventHandler("fuelveh:start", root, function(nearestVehicle, amount)
    if cooldown then 
        return 
    end
    
    local currentFuel = getElementData(nearestVehicle, "fuel")

    duration = tonumber(100 *  math.abs(amount - currentFuel))
    startTime = getTickCount()

    outputChatBox("FUEL FILLED : " ..tonumber(amount - currentFuel).. " Litres", 0, 255, 100)

    cooldown = true

    addEventHandler("onClientRender", root, updateProgress)
    addEventHandler("onClientRender", root, fuelbar)
    triggerServerEvent("startFuelingAnimation", localPlayer, localPlayer)

    setTimer(function()
        fuelvehicle(nearestVehicle, amount)
        triggerServerEvent("stopAnimation", localPlayer, localPlayer)
        cooldown = false
    end, duration, 1)
end)
-----------------------------------------------------------------------------------

-----------------------------------------------------------------------------------
--REPAIR VEHICLE CLIENT
-----------------------------------------------------------------------------------
local cooldown = false
local duration = 10000 
local progress = 0
local endValue = 0.1422--0.2682
local progress2 = 0.4120--0.3589
local endValue2 = 0.5557--0.6297
local startTime = getTickCount()
function repupdateProgress()
    local elapsedTime = getTickCount() - startTime
    if elapsedTime <= duration then
        progress = (endValue / duration) * elapsedTime

        local timeRatio = elapsedTime / duration
        progress2 = 0.4120 + (endValue2 - 0.4120) * timeRatio

    else
        progress = endValue
        removeEventHandler("onClientRender", root, updateProgress)

        progress2 = endValue2
        removeEventHandler("onClientRender", root, repupdateProgress)
        removeEventHandler("onClientRender", root, repairBar)

    end
end
function repairBar()
    dxDrawRectangle(screenW * 0.4135, screenH * 0.8454, screenW * 0.1526, screenH * 0.0250, tocolor(0, 0, 0, 180), false)
    dxDrawRectangle(screenW * 0.4188, screenH * 0.8546, screenW * 0.1422, screenH * 0.0065, tocolor(154, 154, 154, 180), false)
    dxDrawRectangle(screenW * 0.4188, screenH * 0.8546, screenW * progress, screenH * 0.0065, tocolor(254, 254, 254, 180), false)
    dxDrawImage(screenW * progress2, screenH * 0.8444, screenW * 0.0172, screenH * 0.0259, ":Vehicles/[images]/health.png", -25, 0, 0, tocolor(255, 255, 255, 255), false)
end

function repairVeh(nearestVehicle)
    triggerServerEvent('RepairVeh:done', localPlayer, nearestVehicle)
end


addEvent("repairVeh:start", true)
addEventHandler("repairVeh:start", root, function(nearestVehicle)
    if cooldown then 
        return 
    end
    startTime = getTickCount()
    addEventHandler("onClientRender", root, repupdateProgress)
    addEventHandler("onClientRender", root, repairBar)
    triggerServerEvent("startRepairAnimation", localPlayer, localPlayer)
    cooldown = true 

    setTimer(function() 
        repairVeh(nearestVehicle)
        triggerServerEvent("stopAnimation", localPlayer, localPlayer)
        cooldown = false
    end, duration, 1)
end)
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------