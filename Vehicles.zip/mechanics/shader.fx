// shader.fx

texture gTexture;

sampler Sampler0 = sampler_state
{
    Texture   = (gTexture);
    MipFilter = LINEAR;
    MinFilter = LINEAR;
    MagFilter = LINEAR;
};

float4 gColor = float4(1.0, 0.0, 0.0, 1.0); // Default red color

struct VS_OUTPUT
{
    float4 Pos  : POSITION;
    float2 Tex0 : TEXCOORD0;
};

VS_OUTPUT vs_main(float4 Pos : POSITION, float2 Tex0 : TEXCOORD0)
{
    VS_OUTPUT Out;
    Out.Pos = Pos;
    Out.Tex0 = Tex0;
    return Out;
}

float4 ps_main(float2 Tex0 : TEXCOORD0) : COLOR0
{
    float4 color = tex2D(Sampler0, Tex0);
    return color * gColor;
}

technique Tec1
{
    pass P0
    {
        VertexShader = compile vs_3_0 vs_main();
        PixelShader  = compile ps_3_0 ps_main();
    }
}
