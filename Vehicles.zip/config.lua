--KEYBINDS
lockVehicleKEY = "u"
openGarageKEY = "e"
storeToGarageKEY = "g"

--GARAGE AND IMPOUND
PermissionGroup = "Admin" --PERMISSION (default: Admin)

ForcespawnAmount = 2000 -- Force spawn vehicle fine amount

--garage marker size
markerSize = 15


--VEHICLE STORAGE 
vehicleStorage = {
    [400] = { trunk = 1500, glovebox = 300 }, -- Landstalker
    [401] = { trunk = 1300, glovebox = 280 }, -- Bravura
    [402] = { trunk = 1000, glovebox = 250 }, -- Buffalo
    [411] = { trunk = 800, glovebox = 200 },  -- Infernus
    [415] = { trunk = 700, glovebox = 200 },  -- Cheetah
    [429] = { trunk = 600, glovebox = 180 },  -- Banshee
    [451] = { trunk = 900, glovebox = 220 },  -- Turismo
    [561] = { trunk = 1100, glovebox = 250 }, -- Stratum
    [579] = { trunk = 1600, glovebox = 320 }, -- Huntley
    [580] = { trunk = 1400, glovebox = 290 }, -- Stafford
}

-- Default values
defaultStorage = { trunk = 1000, glovebox = 250 }


-- Define fuel consumption per vehicle model
fuelConsumptionRates = {
    [400] = 0.04,  -- Example: Landstalker
    [401] = 0.04,  -- Example: Bravura
    [411] = 0.04,  -- Example: Infernus
    [415] = 0.04, -- Example: Cheetah
    [500] = 0.04, -- Example: Mesa
}

-- Default fuel consumption if model is not listed
defaultFuelConsumption = 0.04

-- CAR DEALER PERMISSION (default: Admin)
dealerPermissionGroup = "Admin" -- script not completed yet for dealership


configPontos = {
	corMarker = {137, 40, 212}, -- Cor RGB marcação
	tamanhoMarker = 1.5, -- Tamanho marcação
	idBlip = 35, -- Icone da marcação
	corImagem = {255, 255, 255}, -- Cor da imagem acima da marcação
}


--CAR SHOPS
CarShopData = {
    {
        model = 415,
        displayName = "Mercedes Benz",
        price = 30000,
        brandname = "Benz",
        vehicleType = "Race Car",
        image = "[carimages]/mr_benz.png"
    },

    {
        model = 411,
        displayName = "infernus",
        price = 30000,
        brandname = "Grotti",
        vehicleType = "Race Car",
        image = "[carimages]/infernus.png"
    },
    -- Add more car entries here
}

-- VEHICLE BUY WILL WORK ON THE NEAREST LOCATION HERE
vehicleSpawnLocations = {
    { x = 370, y = -1812, z = 8.3, rx = 0, ry = 0, rz = 90 },
    { x = 7890.12, y = 3456.78, z = 45.67, rx = 0, ry = 0, rz = 90 },
    { x = 9012.34, y = 4567.89, z = 56.78, rx = 0, ry = 0, rz = 90 },
    { x = 1479, y = -1708, z = 14, rx = 0, ry = 0, rz = 0},
    -- Add more spawn locations as needed
}